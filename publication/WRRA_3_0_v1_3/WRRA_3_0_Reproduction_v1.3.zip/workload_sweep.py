"""Reusable state-cache audit; build + changing-query cost against grouped pure states."""
from pathlib import Path
import os,json,time,platform,subprocess
# Set deterministic thread policy before importing numerical libraries.
for key in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:os.environ[key]='1'
import numpy as np
R=Path(__file__).parent
rng=np.random.default_rng(4321098);rows=[]
for d in [32,64,128]:
 for G in [8,32,128]:
  v=rng.normal(size=(G,d))+1j*rng.normal(size=(G,d));v/=np.linalg.norm(v,axis=1)[:,None]
  B=rng.random((3,G));B/=B.sum(axis=1)[:,None]
  qs=[]
  for _ in range(300):
   q=rng.normal(size=(d,d))+1j*rng.normal(size=(d,d));qs.append((q+q.conj().T)/(2*d))
  build=[]
  for _ in range(5):
   t=time.perf_counter();sigma=np.einsum('sk,ki,kj->sij',B,v,v.conj(),optimize=True);build.append(time.perf_counter()-t)
  for m in [10,90,300]:
   ts={};answers={}
   for name in ['grouped','cache']:
    runs=[]
    for _ in range(5):
     t=time.perf_counter();out=[]
     for q in qs[:m]:
      if name=='grouped':out.append(B@np.einsum('ki,ij,kj->k',v.conj(),q,v,optimize=True).real)
      else:out.append(np.einsum('sij,ji->s',sigma,q).real)
     runs.append(time.perf_counter()-t)
    ts[name]=runs;answers[name]=np.array(out)
   error=float(np.max(np.abs(answers['grouped']-answers['cache'])));assert error<1e-12
   bt=float(np.median(build));group=float(np.median(ts['grouped']));cache=float(np.median(ts['cache']));per=(group-cache)/m
   rows.append({'d':d,'groups':G,'queries':m,'group_bytes':int(v.nbytes+B.nbytes),'cache_bytes':int(sigma.nbytes),'build_seconds':build,'query_seconds':ts,'build_median':bt,'group_median':group,'cache_query_median':cache,'cache_total_median':cache+bt,'estimated_break_even_queries':max(1,int(np.ceil(bt/per))) if per>0 else None,'max_error':error})
info={'status':'PASS','seed':4321098,'cpu':platform.processor(),'platform':platform.platform(),'threads':{k:os.environ[k] for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']},'numpy':np.__version__,'numpy_build':str(np.show_config(mode='dicts')),'repetitions':5,'scope':'Local comparative workload, not a universal operation metric or physical minimum. Three scalar loads cannot serve changing queries. Shared query generation/storage and address coefficient compilation excluded equally; weighted cache construction included. Grouped and cache methods use the same complex pure vectors and positive weights.','rows':rows}
try:info['cpu_model']=next(x.split(':',1)[1].strip() for x in Path('/proc/cpuinfo').read_text().splitlines() if x.startswith('model name'))
except Exception:pass
(R/'workload_sweep_results.json').write_text(json.dumps(info,indent=2));print(json.dumps({'status':info['status'],'cases':len(rows),'max_error':max(x['max_error'] for x in rows),'cpu':info.get('cpu_model'),'fast_cache_total_cases':sum(x['cache_total_median']<x['group_median'] for x in rows),'break_even_range':[min(x['estimated_break_even_queries'] for x in rows if x['estimated_break_even_queries']),max(x['estimated_break_even_queries'] for x in rows if x['estimated_break_even_queries'])]}))
