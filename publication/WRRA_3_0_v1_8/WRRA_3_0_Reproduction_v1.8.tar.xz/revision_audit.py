"""v1.7: coefficient provenance, scale sensitivity and shared-ledger constraint."""
from pathlib import Path
import json, math, hashlib
import numpy as np
R=Path(__file__).resolve().parent
cal=json.loads((R/'snapshots/source_step2/dependencies/original/m10_results.json').read_text())['calibration']
sectors=['phenotype','resident_nonphenotype','return']
eta=np.array([cal['eta_J_m3'][s] for s in sectors]);mu=np.array([cal['reference_address_moments'][s] for s in sectors]);frac=np.array([cal['target_energy_fractions'][s] for s in sectors]);uc=cal['ucrit_J_m3']
assert np.max(abs(eta*mu/uc-frac))<1e-14
rows=[]
for line in (R/'RAR.mrt').read_text().splitlines():
 try:v=list(map(float,line.split()))
 except ValueError:continue
 if len(v)==4:rows.append(v)
x,ex,y,ey=np.array(rows).T
base=1.191787531397112e-10
sweep=[]
for k in (1/16,1/8,1/4):
 scale=base*math.sqrt(k/(1/8));pred=x-np.log10(-np.expm1(-np.sqrt(10**x/scale)))
 sweep.append({'kappa':k,'scale_m_s2':scale,'rms_dex':float(np.sqrt(np.mean((y-pred)**2)))})
shared=json.loads((R/'snapshots/source_step6/shared_gravity_results.json').read_text())['cases']
errs=[]
for c in shared:
 rp=c['sector_density_J_m3'][0]/uc;rhs=1.5*(rp+8*(c['aT_m_s2']/(299792458*cal['H0_s_minus1']))**2)
 lhs=(1+c['q'])*c['H_over_H0']**2;errs.append(abs(lhs-rhs))
assert max(errs)<1e-12
out={'status':'PASS','reference_calibration':cal,'calibration_max_error':float(np.max(abs(eta*mu/uc-frac))),'coefficient_sensitivity':sweep,'H0_plusminus_0_5_fractional_scale_shift':0.5/67.4,'density_fraction_plusminus_1_percent_scale_ratios':[math.sqrt(.99),math.sqrt(1.01)],'shared_constraint_max_error':max(errs),'shared_cases':len(errs),'interpretation':'Sensitivity scenarios, not fitted coefficients or observational confidence intervals. H0 variation holds rho_D/ucrit fixed. Kappa provenance is inherited, not a first-principles derivation.'}
(R/'revision_audit_results.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
