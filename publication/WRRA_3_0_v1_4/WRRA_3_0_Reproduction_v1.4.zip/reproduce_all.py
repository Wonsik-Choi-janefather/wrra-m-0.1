"""Run the inherited WRRA checks in an isolated copy; stdout is recorded per script."""
from pathlib import Path
import subprocess,sys,shutil,json,hashlib,time,argparse
ROOT=Path(__file__).resolve().parent
def main():
 p=argparse.ArgumentParser();p.add_argument('--output',default='rerun');args=p.parse_args()
 target=ROOT/args.output;target.mkdir(exist_ok=True)
 source=ROOT/'snapshots'
 order={
 1:['frozen_source_replay.py','capacity_transport.py','phase_bridge.py','audit.py'],
 2:['address_structure.py','readout_ledger.py','channel_bridge.py','connection_replay.py'],
 3:['structure_comparison.py','minimum_phase_state.py','mode_comparison.py','phase_kernel.py','streaming_selection.py','integration_review.py','review_scope.py'],
 4:['carrier_selection.py','phenotype_transform.py','channel_record.py','mass_mixing_join.py','final_review.py'],
 5:['state_load.py','record_load_join.py','final_review.py'],
 6:['shared_gravity.py','macro_boundary.py','final_review.py'],
 7:['overall_audit.py']}
 results=[]
 for stage,names in order.items():
  folder=target/f'source_step{stage}';shutil.copytree(source/f'source_step{stage}',folder,dirs_exist_ok=True)
  for name in names:
   start=time.perf_counter();r=subprocess.run([sys.executable,str(folder/name)],cwd=folder,text=True,capture_output=True)
   (folder/(name+'.stdout.txt')).write_text(r.stdout);(folder/(name+'.stderr.txt')).write_text(r.stderr)
   row={'stage':stage,'script':name,'returncode':r.returncode,'seconds':time.perf_counter()-start};results.append(row)
   print(json.dumps(row),flush=True)
   if r.returncode:raise RuntimeError(r.stderr[-4000:])
 out={'status':'PASS','scripts':results,'meaning':'Executable checks rerun; not independent physical observations','python':sys.version}
 (target/'FULL_RERUN.json').write_text(json.dumps(out,indent=2));print('FULL_RERUN PASS',flush=True)
if __name__=='__main__':main()
