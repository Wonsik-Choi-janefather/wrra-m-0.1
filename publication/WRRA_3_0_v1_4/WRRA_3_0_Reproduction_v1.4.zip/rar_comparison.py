"""Frozen-scale comparison to the official 2693-row SPARC RAR release.
This is descriptive reuse of an already published dataset and empirical kernel,
not a claim of independent discovery or a covariance-aware statistical test.
"""
from pathlib import Path
import numpy as np,json,hashlib
ROOT=Path(__file__).resolve().parent
rows=[]
for line in (ROOT/'RAR.mrt').read_text().splitlines():
 try:r=list(map(float,line.split()))
 except ValueError:continue
 if len(r)==4:rows.append(r)
d=np.array(rows);assert d.shape==(2693,4)
x,ex,y,ey=d.T;aT=1.191787531397112e-10;empirical=1.20e-10
def predict(a):return x-np.log10(-np.expm1(-np.sqrt(10.**x/a)))
models={}
for name,scale in [('WRRA_frozen',aT),('published_RAR_scale',empirical),('baryons_only',0.)]:
 pred=predict(scale) if scale else x;r=y-pred
 models[name]={'scale_m_s2':scale,'count':len(r),'median_residual_dex':float(np.median(r)),'mean_residual_dex':float(r.mean()),'rms_residual_dex':float(np.sqrt(np.mean(r*r))),'p90_abs_residual_dex':float(np.quantile(abs(r),.9))}
diff=predict(aT)-predict(empirical)
out={'data_url':'https://astroweb.case.edu/SPARC/RAR.mrt','data_sha256':hashlib.sha256((ROOT/'RAR.mrt').read_bytes()).hexdigest(),'data_description':'Published Figure 2 RAR points; log accelerations and marginal errors in dex; no galaxy IDs or joint covariance','models':models,'max_abs_WRRA_vs_published_prediction_dex':float(np.max(abs(diff))),'parameters_refitted':0,'model_selection_claim':False,'uncertainty_note':'Rounded published data, shared galaxy nuisance parameters and correlations; residual metrics are descriptive, not independent likelihood terms or uncertainty intervals.'}
(ROOT/'rar_results.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
fig,axs=plt.subplots(1,2,figsize=(9.4,3.7),layout='constrained')
axs[0].hexbin(x,y,gridsize=45,mincnt=1,cmap='Greys',bins='log');xx=np.linspace(x.min(),x.max(),500)
axs[0].plot(xx,xx-np.log10(-np.expm1(-np.sqrt(10.**xx/aT))),color='#215A91',label='WRRA frozen scale')
axs[0].plot(xx,xx,'--',color='#A94332',label='Baryons only');axs[0].set(xlabel='log10 g_bar [m/s²]',ylabel='log10 g_obs [m/s²]');axs[0].legend(fontsize=8)
axs[1].scatter(x,y-predict(aT),s=3,alpha=.2,color='#215A91');axs[1].axhline(0,color='black',lw=.8);axs[1].set(xlabel='log10 g_bar [m/s²]',ylabel='Observed − frozen WRRA [dex]')
fig.savefig(ROOT/'RAR_frozen_comparison.png',dpi=210);fig.savefig(ROOT/'RAR_frozen_comparison.pdf')
