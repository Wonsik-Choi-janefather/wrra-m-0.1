"""Exact sector-operator compression, marginal ablation, and a closure counterexample.
No fit is performed. Run from this folder; snapshots contain all inherited inputs.
"""
from pathlib import Path
import ast,json,math,time,sys
import numpy as np
from scipy.sparse import csr_matrix
ROOT=Path(__file__).resolve().parent
def setup():
 path=ROOT/'snapshots/source_step5/state_load.py';nodes=[]
 for node in ast.parse(path.read_text()).body:
  if isinstance(node,ast.For) and isinstance(node.target,ast.Name) and node.target.id=='eps':break
  nodes.append(node)
 d={'__file__':str(path),'__name__':'benchmark_setup'}
 exec(compile(ast.Module(body=nodes,type_ignores=[]),str(path),'exec'),d)
 return d
def render(loads,d,a=1.):
 eta=d['eta'];V0=d['V0'];rho=eta*a**d['exponents']*loads/a**3;P=-np.dot(d['exponents'],rho)/3
 out=d['s']['adapter']['macro'](loads)
 # Its stored baseline sample is at a=1. Computed quantities for our benchmark
 # use its common constitutive renderer, without fitting its coefficients.
 ref=next(x for x in out['rows'] if x['a']==a)
 return {'rho_J_m3':rho.tolist(),'pressure_Pa':float(P),'q':ref['q'],'rotation_km_s':ref['rotation_km_s'],'lensing_arcsec':ref['lensing_arcsec']}
def main():
 d=setup();s=d['s'];w=d['w'];e=d['e'];g=d['g'];a=e*g;count=len(w);N=d['N'];rng=np.random.default_rng(20261008)
 results={'N_active':count,'carrier_dimension':N,'seed':20261008,'experiments':{}}
 # Dense conditional blocks are used only by the small reference test.
 # Full N uses streamed group reductions: do not allocate N*d*d matrices.
 small=256;dim=8;ws=w[:small]/w[:small].sum();coef=a[:,:small]
 X=rng.normal(size=(small,dim))+1j*rng.normal(size=(small,dim));X/=np.linalg.norm(X,axis=1)[:,None]
 rho=X[:,:,None]*X[:,None,:].conj();ops=[]
 for _ in range(3):
  q=rng.normal(size=(dim,dim))+1j*rng.normal(size=(dim,dim));op=q.conj().T@q;ops.append(op/np.linalg.norm(op,2))
 direct=np.array([sum(ws[n]*coef[j,n]*np.trace(rho[n]@ops[j]).real for n in range(small)) for j in range(3)])
 sigma=np.einsum('sn,n,nij->sij',coef,ws,rho);compact=np.array([np.trace(sigma[j]@ops[j]).real for j in range(3)])
 err=float(np.max(np.abs(direct-compact)));assert err<1e-13
 # Exact operator contract extends to arbitrary carrier observables.
 errors=[]
 for _ in range(30):
  Q=rng.normal(size=(dim,dim))+1j*rng.normal(size=(dim,dim));A=Q.conj().T@Q;A/=np.linalg.norm(A,2)
  for j in range(3):errors.append(abs(np.trace(sigma[j]@A).real-np.einsum('n,n,nij,ji->',ws,coef[j],rho,A).real))
 assert max(errors)<1e-13
 M=float(coef.sum(axis=0).max())
 failure=np.einsum('n,n,nij->ij',ws,1-coef.sum(axis=0)/M,rho)
 channel_trace=float(sum(np.trace(x).real for x in sigma/M)+np.trace(failure).real)
 assert abs(channel_trace-1)<1e-13 and np.linalg.eigvalsh(failure).min()>-1e-13
 results['experiments']['flagged_channel']={'trace':channel_trace,'M':M,'failure_min_eigenvalue':float(np.linalg.eigvalsh(failure).min())}
 results['experiments']['dense_reference']={'addresses':small,'d':dim,'max_load_error':err,'max_error_90_positive_queries':float(max(errors))}
 # Full finite SOURCE: G=32 known diagnostic classes, complex pure states.
 G=32;groups=s['base']['n']%G;B=np.array([[np.dot(w[groups==k],a[j,groups==k]) for k in range(G)] for j in range(3)])
 vectors=rng.normal(size=(G,N))+1j*rng.normal(size=(G,N));vectors/=np.linalg.norm(vectors,axis=1)[:,None]
 car=d['c']['Carrier'](N,8.);full_ops=[np.eye(N),car.Kc/2,car.Kb/2]
 t0=time.perf_counter();expected=np.array([np.einsum('ki,ij,kj->k',vectors.conj(),op,vectors).real for op in full_ops]);direct_full=np.array([np.dot(w*a[j],expected[j,groups]) for j in range(3)]);t1=time.perf_counter()
 sigmas=np.einsum('sk,ki,kj->sij',B,vectors,vectors.conj());compressed=np.array([np.trace(sigmas[j]@full_ops[j]).real for j in range(3)]);t2=time.perf_counter()
 assert np.max(np.abs(direct_full-compressed))<1e-12
 results['experiments']['full_SOURCE']={'groups':G,'max_load_error':float(np.max(np.abs(direct_full-compressed))),'loads':direct_full.tolist(),'direct_query_seconds':t1-t0,'group_compile_and_query_seconds':t2-t1,'conceptual_dense_bytes_complex128':count*N*N*16,'three_operators_bytes_complex128':3*N*N*16,'memory_reduction_factor':count/3,'note':'Group construction cost excluded from both timings; no end-to-end speedup claim.'}
 # Same address marginal and exactly the same carrier marginal. Correlation
 # differs. Use extremal Kc eigenvectors to amplify a legitimate diagnostic.
 vals,vecs=np.linalg.eigh(car.Kc/2);P0=np.outer(vecs[:,0],vecs[:,0]);P1=np.outer(vecs[:,-1],vecs[:,-1]);center=(P0+P1)/2;diff=(P0-P1)/2
 mask=s['base']['n']%3==0;p=float(w[mask].sum());t=min(1.,(1-p)/p);rhos=[center+t*diff,center-p/(1-p)*t*diff]
 assert all(np.linalg.eigvalsh(x).min()>-1e-12 and abs(np.trace(x).real-1)<1e-12 for x in rhos)
 marginal=p*rhos[0]+(1-p)*rhos[1];assert np.max(np.abs(marginal-center))<1e-13
 mu=(w*a).sum(axis=1);joint=np.array([sum(d['B'][j,k]*np.trace(rhos[k]@full_ops[j]).real for k in range(2)) for j in range(3)])
 product=mu*np.array([np.trace(center@op).real for op in full_ops]);contrast=joint-product
 cov=np.array([np.dot(w*a[j],np.where(mask,t,-p/(1-p)*t))*np.trace(diff@full_ops[j]).real for j in range(3)])
 assert np.max(np.abs(cov-contrast))<1e-12;assert max(abs(contrast))>1e-5
 results['experiments']['same_marginals']={'group_probability':p,'amplitude':t,'carrier_marginal_max_error':float(np.max(np.abs(marginal-center))),'joint_loads':joint.tolist(),'product_loads':product.tolist(),'difference':contrast.tolist(),'covariance_identity_error':float(np.max(np.abs(cov-contrast))),'joint_outputs':render(joint,d),'product_outputs':render(product,d)}
 # Any microstate with identical scalar loads has identical declared outputs.
 rows=json.loads((ROOT/'snapshots/source_step6/shared_gravity_results.json').read_text())['cases']
 cases=json.loads((ROOT/'snapshots/source_step5/state_load_results.json').read_text())['cases']
 macro_errors=[]
 for c in cases:
  q=render(np.array(c['joint_loads']),d,c['a']);old=next(x for x in rows if x['carrier_state']==c['state'] and x['epsilon']==c['epsilon'] and x['a']==c['a'])
  macro_errors.append(max(abs(q[k]-old[k]) for k in ('q','rotation_km_s','lensing_arcsec')))
 assert max(macro_errors)<1e-9
 results['experiments']['scalar_equivalence']={'cases':len(cases),'max_output_error':float(max(macro_errors)),'interpretation':'Same loads imply same supplied macro renderer, independently of address details.'}
 # Exact covariance bound with A scaled into [0,1]: |Cov|<=sigma(f)/2.
 bounds=[]
 for j,op in enumerate(full_ops):
  f=a[j];var=np.dot(w,(f-mu[j])**2);spect=np.linalg.eigvalsh(op);width=spect[-1]-spect[0];bound=math.sqrt(var)*width/2
  assert abs(contrast[j])<=bound+1e-12
  bounds.append({'sector':j,'abs_error':float(abs(contrast[j])),'bound':float(bound),'spectral_width':float(width)})
 results['experiments']['covariance_bounds']=bounds
 # Counterexample to replaying arbitrary address-controlled unitaries after
 # scalar-load compression. Two states share initial I and Z totals but a
 # controlled X reveals their opposing address correlations.
 I=np.eye(2);Z=np.diag([1.,-1.]);Pa=np.diag([1.,0.]);Pb=np.diag([0.,1.]);flip=np.array([[0.,1.],[1.,0.]])
 A=[Pa,Pb];Bq=[Pb,Pa];before=[sum(np.trace(x@Z).real for x in r)/2 for r in [A,Bq]]
 after=[(np.trace(r[0]@Z).real+np.trace(flip@r[1]@flip@Z).real)/2 for r in [A,Bq]]
 assert before==[0.,0.] and after==[1.,-1.]
 results['experiments']['controlled_update_counterexample']={'before_Z':before,'after_Z':after,'implication':'Compression sufficient for declared snapshot readout need not be dynamically closed.'}
 # Fair repeated-query baselines: shared immutable query inputs excluded.
 queries=[]
 qrng=np.random.default_rng(8675309)
 for _ in range(90):
  z=qrng.normal(size=(N,N))+1j*qrng.normal(size=(N,N));queries.append((z+z.conj().T)/(2*N))
 times={};answers={}
 for method in ('grouped','weighted'):
  elapsed=[]
  for repeat in range(5):
   start=time.perf_counter();rr=[]
   for Q in queries:
    if method=='grouped':rr.append(B@np.sum((vectors.conj()@Q)*vectors,axis=1).real)
    else:rr.append(np.einsum('sij,ji->s',sigmas,Q).real)
   elapsed.append(time.perf_counter()-start)
  times[method]=float(np.median(elapsed));answers[method]=np.array(rr)
 query_error=float(np.max(np.abs(answers['grouped']-answers['weighted'])));assert query_error<1e-12
 results['experiments']['repeated_queries']={'queries':90,'repetitions':5,'grouped_state_and_weights_bytes':int(vectors.nbytes+B.nbytes),'weighted_operator_bytes':int(sigmas.nbytes),'three_scalar_load_bytes':24,'median_seconds':times,'max_absolute_difference':query_error,'scope':'Scalar loads serve only the fixed three queries; changing queries require carrier information. Group states preserve controlled dynamics; weighted operators are a snapshot query cache.'}
 # Actual WRRA counterexample: all three weighted operators equal initially.
 # A class-controlled X on a carrier qubit separates them after one update.
 subset=256;Aw=a[:,:subset]*w[:subset];sign=np.where(mask[:subset],1.,-1.)
 target=Aw[2]*sign
 residual=target-Aw.T@np.linalg.solve(Aw@Aw.T,Aw@target)
 delta=residual/np.max(np.abs(residual));before=Aw@delta;after=Aw@(sign*delta)
 assert np.max(np.abs(before))<1e-12 and np.max(np.abs(after))>1e-5
 lifted=np.concatenate([a[:,:subset]*mask[:subset],a[:,:subset]*(~mask[:subset])],axis=0)
 rank=int(np.linalg.matrix_rank(lifted));assert rank>3
 center2=np.eye(2)/2;Z2=np.diag([1.,-1.]);X2=np.array([[0.,1.],[1.,0.]])
 class_diff=np.array([Aw[:,sign==z]@delta[sign==z] for z in [1.,-1.]])
 repaired=2*(class_diff[0]-class_diff[1]);repair_error=float(np.max(np.abs(repaired-2*after)));assert repair_error<1e-12
 results['experiments']['WRRA_operator_closure']={'addresses_perturbed':subset,'initial_all_sector_Z_difference':(2*before).tolist(),'after_controlled_all_sector_Z_difference':(2*after).tolist(),'lifted_replay_max_error':repair_error,'base_rank':int(np.linalg.matrix_rank(a[:,:subset])),'lifted_rank':rank,'minimum_conditional_state_eigenvalue':float((1-np.max(abs(delta)))/2),'construction':'rho_n^plus/minus=(I plus/minus delta_n Z)/2 on first 256 active addresses; I/2 elsewhere. Apply I on n%3==0 and X elsewhere; equal initial traces and all weighted operators. Carrier qubit embeds in d=128.'}
 assert np.max(a[1]*a[2])==0 # D and R address supports are disjoint.
 ranges=[[float(mu[j]*np.linalg.eigvalsh(op).min()),float(mu[j]*np.linalg.eigvalsh(op).max())] for j,op in enumerate(full_ops)]
 for loads in [direct_full,product,joint]:
  assert abs(loads[0]-mu[0])<1e-12
  assert all(ranges[j][0]-1e-12<=loads[j]<=ranges[j][1]+1e-12 for j in [1,2])
 results['experiments']['fixed_SOURCE_attainable_domain']={'phenotype_load':float(mu[0]),'independent_D_R_load_intervals':ranges[1:],'reason':'D and R address supports are disjoint; their conditional states can be selected independently. Extremal carrier states attain endpoints and convex mixtures attain all intermediate values. Fixed w,f and scale a leave two variable macro loads.'}
 results['status']='PASS';results['meaning']='Reproducible mathematical and numerical contract tests, not observations.'
 (ROOT/'benchmark_results.json').write_text(json.dumps(results,indent=2));print(json.dumps(results,indent=2))
if __name__=='__main__':main()
