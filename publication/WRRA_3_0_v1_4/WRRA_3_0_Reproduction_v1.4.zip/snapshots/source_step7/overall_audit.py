"""Overall evidence consistency audit, not additional independent observations."""
from pathlib import Path
import json,hashlib,math
ROOT=Path(__file__).resolve().parent
if not __debug__:raise RuntimeError('Run without -O')
m=json.loads((ROOT/'EVIDENCE_MANIFEST.json').read_text());r={}
for name,item in m.items():
 b=(ROOT/item['local']).read_bytes();assert hashlib.sha256(b).hexdigest()==item['sha256'];r[name]=json.loads(b)
checks={}
checks['six_stage_evidence_reports_PASS']=all(r['step'+str(i)]['status']=='PASS' for i in range(1,7))
checks['all_record_branch_budgets_have_explicit_admission']=r['step4']['branches'][1]['baseline_status']=='insufficient_supplier' and r['step4']['branches'][1]['admitted_supplier_status']=='admitted'
checks['minimum_state_scope_explicitly_limited']=r['step3']['total_checks']==38 and 'entire fixed spectral continuation' in r['step3']['correction']
checks['positive_load_and_macro_results_linked']=r['step5']['total_checks']==23 and r['step6']['cases_shared_state']==12 and r['step6']['cases_record_boundary']==36
ref=next(x for x in r['macro']['cases'] if x['carrier_state']=='product' and x['epsilon']==0 and x['a']==1)
checks['same_reference_macro_outputs_preserved']=math.isclose(ref['q'],-.5285585894376319,abs_tol=1e-12) and math.isclose(ref['rotation_km_s'],207.5102418659153,abs_tol=1e-9) and math.isclose(ref['lensing_arcsec'],.5355822400088303,abs_tol=1e-10)
checks['joint_internal_calibration_reproduces_known_axial']=math.isclose(r['internal']['joint_calibrated_observables']['axial'],1.2753,abs_tol=1e-12)
assert all(checks.values())
out={'status':'PASS','checks':checks,'audit_checks':6,'audit_scope':'cross-stage evidence consistency, not full rerun of all stages or independent empirical tests','decision':'six-stage agreed improvement campaign complete; explicit conditional executable WRRA model assembled; unrestricted all-phenomena theory completion not established','do_not_add_as_completion_requirements':['independent novelty predictions','physical uniqueness of every constitutive rule','new mandatory observation sets'],'remaining_model_specs':['four-mode/eight-frame rule','channel/family assignment','internal Delta and current response calibration','load operators and SI response','local source and conditional gravity renderer'],'reference_macro':ref}
(ROOT/'FINAL_DECISION.json').write_text(json.dumps(out,indent=2));print(json.dumps({'status':'PASS','audit_checks':6,'decision':out['decision']}))
