"""SOURCE selection contract + replay of authoritative 0.9 arithmetic functions.
No physical 15-channel carrier evolution or SI/gravity module is replayed here.
"""
from pathlib import Path
from fractions import Fraction as F
from math import lcm
import ast,copy,json,hashlib
import numpy as np

ROOT=Path(__file__).resolve().parent
source=ROOT/'original/compute.py'
parameter_file=ROOT/'original/parameters.json'
# Isolate pure upstream functions without fabricating absent 0.8 dependencies.
selected={'normalized','address_base','phase_drive','effects','shares'}
tree=ast.parse(source.read_text())
nodes=[x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name in selected]
assert {x.name for x in nodes}==selected
ns={'np':np,'SECTORS':('phenotype','resident_nonphenotype','return')}
exec(compile(ast.Module(body=nodes,type_ignores=[]),str(source),'exec'),ns)
cfg=json.loads(parameter_file.read_text())
contract={'version':'source-resolution-candidate/1',
 'calibrated_address_fractions':['0.05','0.268','0.682'],
 'H':29,'C':70,
 'rules':['least exact common denominator of frozen calibrated fractions',
          'all triples in L x H x C admitted',
          'existing serialization n=1+l+L*(h+H*z)',
          'new observations do not automatically replace calibrated parameters'],
 'scope':'calibrated finite SOURCE branch, not necessary universal physical capacity'}

def source_size(contract):
    f=list(map(F,contract['calibrated_address_fractions']))
    assert all(x>=0 for x in f) and sum(f)==1
    L=lcm(*(x.denominator for x in f))
    return L,L*contract['H']*contract['C']

L,N=source_size(contract)
assert (L,N)==(500,1015000)
checks=[]
for observations in [('0.05','0.268','0.682'),('0.0500','0.2680','0.6820'),
                     ('0.0501','0.2680','0.6819'),('0.05001','0.26800','0.68199')]:
    # An observation is test data. It is not a mutation of the calibrated contract.
    before=copy.deepcopy(contract)
    residuals=[str(F(o)-F(f)) for o,f in zip(observations,contract['calibrated_address_fractions'])]
    checks.append({'observations':observations,'L':source_size(contract)[0],
                   'N':source_size(contract)[1],'residuals':residuals})
    assert contract==before
new=copy.deepcopy(contract)
new['calibrated_address_fractions']=['0.0501','0.2680','0.6819']
assert source_size(new)==(10000,20300000)

results=[]
for cutoff in (1000000,N):
    branch=copy.deepcopy(cfg)
    branch['upstream']['address_cutoff_N']=cutoff
    base=ns['address_base'](branch)
    effect=ns['effects'](branch,base)
    assert np.all(effect>=0) and np.allclose(effect.sum(axis=0),1,atol=1e-14)
    shares=ns['shares'](effect,base['w'])
    assert abs(sum(shares.values())-1)<1e-12
    phi=base['w']*effect[0]
    kernel=np.asarray(branch['channel_coupling']['default_origin_weights'])
    assert not branch['channel_coupling']['odd_smallest_prime_overrides']
    origin=phi.sum()*kernel
    assert abs(origin.sum()-shares['phenotype'])<1e-12
    # Every address uses the same conditional origin kernel in this reference.
    # Its readout rank is 1; this does not set the rank of the common carrier.
    kernel_matrix=np.tile(kernel[:,None],(1,500))
    rank=int(np.linalg.matrix_rank(kernel_matrix))
    assert rank==1
    results.append({'N':cutoff,'address_shares':shares,
       'counts':{k:int(base[k].sum()) for k in ('prime','even','odd')},
       'origin_weight_sum':float(origin.sum()),'conditional_origin_kernel_rank':rank})
expected=[0.05000002538983289,0.26800001828881304,0.6819999563213559]
actual=list(results[1]['address_shares'].values())
assert np.allclose(actual,expected,rtol=0,atol=5e-12)
output={'contract':contract,'source_resolution':L,'source_code_count':N,
        'observation_updates':checks,'explicit_recalibration_source':source_size(new),
        'unretuned_upstream_replay':results,
        'original_function_source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
        'input_parameters_sha256':hashlib.sha256(parameter_file.read_bytes()).hexdigest(),
        'unchanged_parameters':['alpha','sigmoid_threshold_h','phase spectrum','conditional channel kernel'],
        'not_replayed':['full common-carrier Hamiltonian','0.8 family permutation','SI energy','gravity'],
        'phase_bridge_candidate_required':False,
        'failure_conditions':['frozen calibration silently replaced by observations',
                              'hidden change to alpha or threshold',
                              'source-address count identified with carrier rank',
                              'conditional readout duplicates phenotype weight']}
(ROOT/'frozen_source_replay_results.json').write_text(json.dumps(output,ensure_ascii=False,indent=2))
print(json.dumps(output,ensure_ascii=False,indent=2))
