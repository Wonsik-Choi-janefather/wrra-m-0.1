from pathlib import Path
import json, copy, math
from fractions import Fraction
import numpy as np
src=Path(__file__).with_name('compute.py').read_text()
src=src.replace("m08 = module('wrra08_common_ledger', ROOT.parent/'wrra_m_0_8/compute.py')",'m08 = None')
ns={'__file__':str(Path(__file__).with_name('compute.py'))};exec(compile(src,'compute.py','exec'),ns)
cfg=json.loads(Path(__file__).with_name('parameters.json').read_text())
rows=[]
for N in [10000,100000,500000,1000000,1015000,2000000]:
 c=copy.deepcopy(cfg);c['upstream']['address_cutoff_N']=N
 b=ns['address_base'](c);e=ns['effects'](c,b);s=ns['shares'](e,b['w'])
 rows.append({'N':N,**s})
 if N==1015000:
  permutation=np.arange(N-1);permutation[0],permutation[2]=permutation[2],permutation[0]
  transported=ns['shares'](e[:,permutation],b['w'][permutation])
  reassigned=ns['shares'](e[:,permutation],b['w'])
  relabel={'original':s,'passive_transport':transported,'classifier_reassignment_swap_2_4':reassigned}
fractions=[]
for f in [('0.05','0.268','0.682'),('0.0501','0.2680','0.6819'),('0.05001','0.26800','0.68199')]:
 L=math.lcm(*(Fraction(x).denominator for x in f));fractions.append({'fractions':f,'L':L,'N':L*29*70})
result={'method':'Published phase-aware WRRA_M 0.9 address_base/effects/shares; original parameters frozen. Imported module dependency removed only because these functions do not use it. No calibration or observations used in controls.','cutoffs':rows,'relabel':relabel,'rational_resolution':fractions,'tail_upper_bound_1e6_to_1015000':((1000000**(1-cfg['upstream']['state']['alpha'])-1015000**(1-cfg['upstream']['state']['alpha']))/(cfg['upstream']['state']['alpha']-1))/(sum(n**(-cfg['upstream']['state']['alpha']) for n in range(2,1000001)))}
Path(__file__).with_name('robustness_results.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2))
