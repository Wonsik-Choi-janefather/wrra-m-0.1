Run: python3 calibration/sensitivity.py
Reference folder contains inherited v0.1 code and inputs.
This package adds synthetic sensitivity calculations and a measurement plan, not new measurements.
