#!/usr/bin/env python3
"""Prime-symmetric dimension sectors and a shared bounded readout.

Only arithmetic and analytic questions are studied. Dimension is the user's
declared classification, not a proved geometric embedding dimension. Finite
address sums and analytic continuations are kept separate throughout.
"""
import csv
import json
import math
from pathlib import Path
import platform

import numpy as np
import scipy
from scipy.optimize import root
from scipy.special import expit

from reference_math import zeta_em, PHI, HEIGHT_GUESSES

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'results'
N=1015000
TERMS=160


def mobius(limit):
    mu=np.ones(limit+1,dtype=int);mu[0]=0
    mark=np.ones(limit+1,dtype=bool);mark[:2]=False
    for p in range(2,limit+1):
        if mark[p]:
            mark[p*p::p]=False
            mu[p::p]*=-1
            if p*p<=limit:mu[p*p::p*p]=0
    return mu


MU=mobius(256)


def canonical_log_zeta(s,min_n=400):
    if s.real>12:
        n=np.arange(2,129,dtype=float)
        return complex(np.log1p(np.sum(np.exp(-s*np.log(n)))))
    return complex(np.log(zeta_em(s,min_n=min_n)))


def tails(s,terms=TERMS,min_n=400):
    phi=0j;mu=0j
    for k in range(3,terms+1):
        log=canonical_log_zeta(k*s,min_n)
        phi+=float(PHI[k])/k*log
        if MU[k]:mu+=int(MU[k])/k*log
    return phi,mu


def sectors(s,terms=TERMS,min_n=400):
    z=zeta_em(s,min_n=min_n)
    l2=canonical_log_zeta(2*s,min_n)
    phi,mu=tails(s,terms,min_n)
    P=np.log(z)-.5*l2+mu
    Q=l2+phi-mu
    M=z-1-np.log(z)-.5*l2-phi
    return P,Q,M


def bounded_readout(s,terms=TERMS,min_n=400):
    # q_d=expit(Re(C_d)). Re log is branch-independent.
    if s==.5:
        # Limit from Re(s)>.5: Q diverges +infinity, P and M -infinity.
        return [0.,1.,0.]
    return [float(expit(c.real)) for c in sectors(s,terms,min_n)]


def residual3(s,terms=TERMS,min_n=400):
    # R3=sqrt(2s-1)*exp(-M), with its removable value evaluated directly.
    # M=zeta-1-B, and B=log(zeta)+.5log(zeta(2s))+H_phi.
    z=zeta_em(s,min_n=min_n)
    D=1.+0j if s==.5 else (2*s-1)*zeta_em(2*s,min_n=min_n)
    phi,_=tails(s,terms,min_n)
    return z*np.sqrt(D)*np.exp(1-z+phi)


def tail_bound(terms,sigma):
    a=(terms+1)*sigma
    return (1+2/(a-1))*2**(-a)/(1-2**(-sigma))


def csvwrite(name,rows):
    with (OUT/name).open('w',encoding='utf-8-sig',newline='') as f:
        writer=csv.DictWriter(f,list(rows[0]));writer.writeheader();writer.writerows(rows)


def main():
    OUT.mkdir(exist_ok=True)
    n=np.arange(N+1)
    spf=np.zeros(N+1,dtype=np.int64)
    for p in range(2,math.isqrt(N)+1):
        if spf[p]==0:
            v=spf[p*p::p];v[v==0]=p
    prime=(spf==0)&(n>=2)
    distinct=np.zeros(N+1,dtype=np.int8)
    for p in n[prime]:distinct[p::p]+=1
    masks=[prime,(distinct==1)&~prime&(n>=2),distinct>=2]
    counts=[int(m.sum()) for m in masks]
    examples=[dict(n=k,dimension=1 if prime[k] else 2 if distinct[k]==1 else 3,
                   distinct_prime_count=int(distinct[k]))
              for k in [2,3,4,6,8,9,10,12,15,25,27,45,49,81,105]]
    csvwrite('dimension_examples.csv',examples)

    convergent=[]
    for s in [2.+0j,3.+0j,3.+1j]:
        infinite=sectors(s)
        vals=[]
        for m in masks:
            vals.append(complex(np.sum(np.exp(-s*np.log(n[m].astype(float))))))
        bound=N**(1-s.real)/(s.real-1)
        errors=[float(abs(a-b)) for a,b in zip(vals,infinite)]
        convergent.append(dict(s=str(s),errors=errors,integer_tail_bound=bound,
            decomposition_error=float(abs(1+sum(infinite)-zeta_em(s,min_n=400)))))

    roots=[]
    for guess in HEIGHT_GUESSES:
        def f(v):
            z=zeta_em(complex(v[0],v[1]),min_n=400)
            return [z.real,z.imag]
        sol=root(f,[.5,guess],tol=1e-11)
        roots.append(complex(.5,sol.x[1]))
    positive=[]
    for j,s in enumerate(roots,1):
        cs=sectors(s)
        phi,_=tails(s)
        phi128,_=tails(s,128)
        residual=residual3(s)
        q=bounded_readout(s)
        positive.append(dict(reference_zero=j,t=s.imag,abs_zeta=float(abs(zeta_em(s,min_n=400))),
            q1=q[0],q2=q[1],q3=q[2],
            q3_deficit_stable=float(expit(-cs[2].real)),
            abs_residual3=float(abs(residual)),
            EM200_400_error=float(abs(residual3(s,min_n=200)-residual)),
            tail128_160_difference=float(abs(phi-phi128))))
    csvwrite('zero_readouts.csv',positive)

    controls=[(f'near_zero_{j}_{delta}',s+delta*1j) for j,s in enumerate(roots,1) for delta in [-.1,.1]]
    controls += [(f'line_t_{t}',.5+1j*t) for t in [0,.1,1,10,15,20,30,40,50]]
    controls += [(f'offline_zeroheight_{j}',s+.05) for j,s in enumerate(roots,1)]
    negative=[]
    for label,s in controls:
        q=bounded_readout(s)
        negative.append(dict(case=label,sigma=s.real,t=s.imag,q1=q[0],q2=q[1],q3=q[2],
            abs_residual3=float(abs(residual3(s))),abs_zeta=float(abs(zeta_em(s,min_n=400)))))
    csvwrite('nonzero_controls.csv',negative)

    approach=[]
    for delta in [1e-2,1e-3,1e-4,1e-5,1e-6,1e-7,1e-8]:
        s=roots[0]+delta;cs=sectors(s);q=bounded_readout(s)
        naive=np.sqrt(2*s-1)*np.exp(-cs[2])
        approach.append(dict(delta=delta,Re_P=cs[0].real,Re_Q=cs[1].real,Re_M=cs[2].real,
            abs_exp_minus_P=float(abs(np.exp(-cs[0]))),abs_exp_minus_Q=float(abs(np.exp(-cs[1]))),
            abs_exp_minus_M=float(abs(np.exp(-cs[2]))),q1=q[0],q2=q[1],q3=q[2],
            q3_deficit=float(expit(-cs[2].real)),abs_residual3=float(abs(residual3(s))),
            residual_reconstruction_error=float(abs(naive-residual3(s))),
            sector_sum_error=float(abs(1+sum(cs)-zeta_em(s,min_n=400)))))
    csvwrite('approach_first_zero.csv',approach)

    real_boundary=[]
    for delta in [1e-2,1e-4,1e-6,1e-8]:
        s=.5+delta;cs=sectors(s)
        real_boundary.append(dict(delta=delta,Re_Q=cs[1].real,
            Q_plus_log_2delta=cs[1].real+np.log(2*delta),
            abs_residual3=float(abs(residual3(s))),q2=bounded_readout(s)[1]))
    csvwrite('prime_power_half_boundary.csv',real_boundary)

    finite=[]
    for cap in [10000,100000,N]:
        vals=[]
        for m in masks:
            pick=m&(n<=cap)
            vals.append(complex(np.sum(np.exp(-roots[0]*np.log(n[pick].astype(float))))))
        finite.append(dict(N=cap,abs_C1=float(abs(vals[0])),abs_C2=float(abs(vals[1])),
            abs_C3=float(abs(vals[2])),
            finite_q1=float(expit(vals[0].real)),finite_q2=float(expit(vals[1].real)),
            finite_q3=float(expit(vals[2].real)),
            finite_q3_deficit_stable=float(expit(-vals[2].real)),
            finite_log_abs_exp_minus_C3=float(-vals[2].real),
            any_exact_zero_of_finite_exponential=False))
    csvwrite('finite_cutoff_controls.csv',finite)

    finite_false_controls=[]
    mixed_log=np.log(n[masks[2]].astype(float))
    for label,s in controls:
        C=complex(np.sum(np.exp(-s*mixed_log)))
        deficit=float(expit(-C.real))
        finite_false_controls.append(dict(case=label,sigma=s.real,t=s.imag,
            Re_finite_M=C.real,q3_deficit_stable=deficit,
            finite_approximate_pass=deficit<1e-8))
    csvwrite('finite_false_pass_controls.csv',finite_false_controls)

    # Small finite prime relabeling preserves only the exponent pattern.
    relabel={2:5,3:7,5:2,7:3}
    relabel_checks=[]
    for raw in [4,6,8,9,10,12,15,25,27,35,49,105]:
        x=raw;factors={}
        for p in [2,3,5,7]:
            while x%p==0:factors[p]=factors.get(p,0)+1;x//=p
        assert x==1
        transformed=math.prod(relabel[p]**a for p,a in factors.items())
        before=1 if len(factors)==1 and sum(factors.values())==1 else 2 if len(factors)==1 else 3
        after=1 if prime[transformed] else 2 if distinct[transformed]==1 else 3
        relabel_checks.append(dict(n=raw,relabelled=transformed,dimension=before,preserved=before==after))

    checks=dict(
        all_active_addresses_partitioned=sum(counts)==N-1,
        composite_prime_power_count_236=counts[1]==236,
        mixed_composite_count_935155=counts[2]==935155,
        convergent_sector_series_match=all(max(x['errors'])<x['integer_tail_bound']+1e-13 for x in convergent),
        analytic_sector_sum_identity=max(x['decomposition_error'] for x in convergent)<1e-12,
        all_reference_residuals_zero_numerically=max(x['abs_residual3'] for x in positive)<1e-9,
        all_reference_dimension1_readouts_small=max(x['q1'] for x in positive)<1e-10,
        all_reference_dimension2_readouts_strictly_interior=all(0<x['q2']<1 for x in positive),
        all_reference_dimension3_readouts_one=max(x['q3_deficit_stable'] for x in positive)<1e-10,
        all_nonzero_controls_have_nonzero_residual=min(x['abs_residual3'] for x in negative)>1e-6,
        all_nonzero_controls_have_q3_below_one=all(x['q3']<1-1e-6 for x in negative),
        no_fake_zero_at_half_real=abs(residual3(.5))>1,
        inverse_exponential_sector1_grows=all(approach[i+1]['abs_exp_minus_P']>approach[i]['abs_exp_minus_P'] for i in range(len(approach)-1)),
        inverse_exponential_sector2_stays_finite=all(.1<x['abs_exp_minus_Q']<2 for x in approach),
        inverse_exponential_sector3_decreases=all(approach[i+1]['abs_exp_minus_M']<approach[i]['abs_exp_minus_M'] for i in range(len(approach)-1)),
        bounded_readout_sector3_increases=all(approach[i+1]['q3']>approach[i]['q3'] for i in range(len(approach)-1)),
        stable_and_naive_residual_agree=max(x['residual_reconstruction_error'] for x in approach)<1e-11,
        local_sector_sum_identity=max(x['sector_sum_error'] for x in approach)<1e-11,
        EM200_400_agree=max(x['EM200_400_error'] for x in positive)<1e-9,
        higher_log_tail128_160_agrees=max(x['tail128_160_difference'] for x in positive)<1e-14,
        prime_power_divergence_at_half=all(real_boundary[i+1]['Re_Q']>real_boundary[i]['Re_Q'] for i in range(len(real_boundary)-1)),
        prime_relabeling_preserves_dimensions=all(x['preserved'] for x in relabel_checks),
        no_raw_finite_mixed_sum_zero=all(x['abs_C3']>1e-3 for x in finite),
        raw_finite_gate_has_declared_false_pass=any(x['finite_approximate_pass'] for x in finite_false_controls),
    )
    checks={k:bool(v) for k,v in checks.items()}
    assert all(checks.values()),checks
    result=dict(study='Prime-symmetric zeta dimension study v0.1',date='2026-10-16',
        validation_inputs=dict(N=N,unit_reference=1,dimension_rule='prime1; composite prime power2; mixed prime composite3',known_zero_count=len(roots),nonzero_controls=len(negative),no_fit=True,composition_calculation_excluded=True),
        WRRA_transformation=dict(
            C1='P(s)=sum_p p^-s',C2='Q(s)=sum_p sum_(k>=2) p^(-ks)',C3='M(s)=zeta(s)-1-P(s)-Q(s)',
            single_prime_support='B=P+Q=sum_p 1/(p^s-1)=sum_(m>=1) phi(m)/m*log zeta(ms)',
            common_bounded_map='q_d(s)=expit(Re(C_d(s))); all three sectors use the same map',
            half_origin='The prime-square part of Q has abscissa of absolute convergence1/2',
            residual='R3=sqrt(2s-1)*exp(-M)=zeta(s)*sqrt((2s-1)*zeta(2s))*exp(1-zeta(s)+H_phi(s))',
            higher_factor='H_phi=sum_(m>=3) phi(m)/m*log zeta(ms)',
            square_pole_normalization='Multiplication by sqrt(2s-1), NOT division: B has positive .5*log zeta(2s)',
            branch_scope='Local logarithms; real-part bounded readouts are branch-independent. R3 square-root branch does not alter zero set.'),
        outputs=dict(dimension_counts=counts,convergent_controls=convergent,positive_cases=positive,negative_cases=negative,near_first_zero=approach,half_boundary=real_boundary,finite_controls=finite,finite_false_pass_controls=finite_false_controls,finite_false_pass_count=sum(x['finite_approximate_pass'] for x in finite_false_controls),prime_relabeling=relabel_checks,log_tail_bound_at160_sigma_half=tail_bound(160,.5),max_positive_residual=max(x['abs_residual3'] for x in positive),min_negative_residual=min(x['abs_residual3'] for x in negative),max_positive_q3_deficit=max(x['q3_deficit_stable'] for x in positive)),
        refutation_conditions=[
            'The declared dimension sectors fail to partition the active finite natural numbers.',
            'The continued sector formulas disagree with direct sums in Re(s)>1 outside the stated tail bound.',
            'A critical-line zeta nonzero is declared an exact R3 zero, or a reference zero is missed beyond numerical uncertainty.',
            'A finite uncorrected exponential readout is claimed to have an exact zero.',
            'The shared logistic map is claimed to follow uniquely from arithmetic classification alone.',
            'The half convergence boundary is claimed to prove all nontrivial zeta zeros lie on the critical line.'],
        conclusions=dict(prime_symmetric_dimension_classification=True,half_boundary_from_prime_power_sector=True,shared_bounded_map_separates_sector_limits_at_zeta_zero=True,critical_line_q3_one_iff_zeta_zero_in_local_limit=True,critical_line_residual_zero_equivalence=True,common_map_is_explicit_additional_choice=True,finite_N_implements_exact_analytic_gate=False,all_zeros_forced_to_half=False,physical_spatial_dimensions_derived=False,RH_proven=False),checks=checks,versions=dict(python=platform.python_version(),numpy=np.__version__,scipy=scipy.__version__))
    (OUT/'results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
    print(json.dumps(dict(checks_passed=sum(checks.values()),dimension_counts=counts,max_zero_residual=result['outputs']['max_positive_residual'],min_nonzero_residual=result['outputs']['min_negative_residual'],max_zero_q3_deficit=result['outputs']['max_positive_q3_deficit'],first_zero=positive[0],approach_first=approach[0],approach_last=approach[-1],half_boundary=real_boundary,finite_controls=finite),indent=2))


if __name__=='__main__':
    main()
