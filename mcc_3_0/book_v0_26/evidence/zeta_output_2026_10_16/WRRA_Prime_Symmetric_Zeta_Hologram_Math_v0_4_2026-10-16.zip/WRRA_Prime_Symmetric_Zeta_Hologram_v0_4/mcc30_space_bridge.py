#!/usr/bin/env python3
"""Execute a conditional attachment to MCC3.0 ch4,7.3,12,114-117.
CRT geometry is a distinct realization, not a reindexing of the old graph.
"""
from pathlib import Path
import json,math
import numpy as np
from relation_preserving_bridge import selected_mask
ROOT=Path(__file__).resolve().parent
N=1015000;shape=(213,65,77);M=math.prod(shape)
c=299792458.;dt=1.481301966415863e-21;spacing=c*dt

def main():
    rng=np.random.default_rng(20261016)
    k=np.arange(M,dtype=np.int64);flat=np.ravel_multi_index(tuple(k%m for m in shape),shape)
    inverse=np.empty(M,dtype=np.int64);inverse[flat]=k
    def J(v):
        out=np.empty(M,dtype=v.dtype);out[flat]=v;return out.reshape(shape)
    def Ji(v):return v.ravel()[flat]
    steps=[(M//m)*pow(M//m,-1,m)%M for m in shape]
    coords=np.stack(np.unravel_index(np.arange(M),shape),axis=-1)
    # Physical distance Renderer from ch114: one local edge gets c*dt.
    edge_errors=[]
    for a,delta in enumerate(steps):
        x=np.stack(tuple(k%m for m in shape),axis=-1)
        y=np.stack(tuple(((k+delta)%M)%m for m in shape),axis=-1)
        diff=abs(x-y);diff=np.minimum(diff,np.array(shape)-diff)
        dist=spacing*np.sqrt(np.sum(diff**2,axis=1))
        edge_errors.append(float(np.max(abs(dist/spacing-1))))
    # Euclidean product geodesic distance on the declared flat torus.
    def dist(a,b):
        d=abs(a-b);d=np.minimum(d,np.array(shape)-d)
        return spacing*np.sqrt(np.sum(d*d,axis=-1))
    a=rng.integers(np.array(shape),size=(20000,3));b=rng.integers(np.array(shape),size=(20000,3));z=rng.integers(np.array(shape),size=(20000,3))
    violation=float(np.max(dist(a,z)-dist(a,b)-dist(b,z)))
    # Old row-major graph edges generally differ from the new CRT edges.
    n=np.arange(1,N+1,dtype=np.int64);old=n-1
    i=old%500;j=(old//500)%29;h=old//14500
    oldnext=1+(i+1)%500+500*(j+29*h)
    ca=np.stack(tuple(n%m for m in shape),axis=-1)
    cb=np.stack(tuple(oldnext%m for m in shape),axis=-1)
    dif=abs(ca-cb);dif=np.minimum(dif,np.array(shape)-dif)
    old_edges_not_new_nearest=int(np.count_nonzero(np.sum(dif,axis=1)!=1))
    # Native ch115 kernels retained as address-owned observables, NOT invented 3D fields.
    u=np.arange(1024)/1024
    kernels=np.ones((30,1024))
    for r in range(30):
        for p in (2,3,5):
            theta=(r%p)/p-u
            D=np.mean(np.exp(2j*np.pi*np.arange(p)[:,None]*theta),axis=0)
            kernels[r]*=abs(1-D)**2
        kernels[r]/=np.mean(kernels[r])
    # Test payload: explicitly uniform selected-address population; not book B_s,r,j.
    mask=np.zeros(M,dtype=bool);mask[2:N+1]=selected_mask(N)[2:]
    payload=mask.astype(float)/mask.sum()
    source_residue_mass=np.bincount(k%30,weights=payload,minlength=30)
    local_payload=J(payload);origin_residue=J(k%30)
    grid_residue_mass=np.bincount(origin_residue.ravel(),weights=local_payload.ravel(),minlength=30)
    source_profile=source_residue_mass@kernels;grid_profile=grid_residue_mass@kernels
    profile_error=float(np.max(abs(source_profile-grid_profile)))
    # Transport observable ownership too: Tr(U rho U* U A U*)=Tr(rho A).
    ownership_errors=[];frozen_observable_changes=[]
    obs=J(k%30==0)
    for axis in range(3):
        moved=np.roll(local_payload,1,axis);moved_obs=np.roll(obs,1,axis)
        ownership_errors.append(abs(float(np.sum(moved*moved_obs)-np.sum(local_payload*obs))))
        frozen_observable_changes.append(float(np.sum(moved*obs)-np.sum(local_payload*obs)))
    # ch117 adopted physical dispersion; no substitution of exp(-i L) for photons.
    wave_axes=[2*np.pi*np.fft.fftfreq(m,d=spacing) for m in shape]
    K2=np.zeros(shape)
    for axis,q in enumerate(wave_axes):
        sh=[1,1,1];sh[axis]=len(q);K2+=q.reshape(sh)**2
    K=np.sqrt(K2);theta=c*dt*K
    photon_phase=np.exp(-1j*theta)
    # Fixed declared low-pass support avoids temporal aliasing for this tick.
    spectral=rng.normal(size=shape)+1j*rng.normal(size=shape)
    low=(theta<.8*np.pi)&(theta>0)
    spectral*=low;spectral/=np.linalg.norm(spectral)
    advanced=photon_phase*spectral
    photon_norm_error=abs(float(np.vdot(advanced,advanced).real-1))
    e0=float(np.sum(K*abs(spectral)**2));e1=float(np.sum(K*abs(advanced)**2))
    seven=[(1,0,0),(0,1,0),(0,0,1),(1,1,0),(1,0,1),(0,1,1),(1,1,1)]
    speed_errors=[]
    for mode in seven:
        kv=np.array([wave_axes[a][m] for a,m in enumerate(mode)])
        omega=c*np.linalg.norm(kv)
        recovered=-np.angle(np.exp(-1j*omega*dt))/dt
        speed_errors.append(abs(recovered/(np.linalg.norm(kv)*c)-1))
    # Principal Nyquist corners exceed temporal pi at dt=d/c: reject before propagation.
    aliased=int(np.count_nonzero(theta>=np.pi))
    # Ch7.3 conditional minimality applies given local propagating spin-2 admissibility.
    cost=[]
    for dim in range(3,9):
        dof=(dim+1)*(dim-2)//2
        cost.append(dict(d=dim,graviton_dof=dof,cost_cE1_cT1=dim+dof))
    checks=dict(all_CRT_axis_edges_have_inherited_physical_length=max(edge_errors)<1e-13,
        metric_triangle_inequality=violation<spacing*1e-12,
        metric_positive_test=np.all(dist(a,b)[np.any(a!=b,axis=1)]>0),
        original_graph_not_silently_identified=old_edges_not_new_nearest>0,
        original_tap_kernels_normalized=float(np.max(abs(kernels.mean(axis=1)-1)))<1e-12,
        address_owned_profile_survives_CRT=profile_error<1e-12,
        local_ownership_transported=max(ownership_errors)<1e-12,
        physical_photon_norm_preserved=photon_norm_error<1e-12,
        physical_photon_energy_preserved=abs(e1/e0-1)<1e-12,
        seven_directions_preserve_fixed_c=max(speed_errors)<1e-12,
        temporal_alias_sector_explicitly_detected=aliased>0,
        spin2_conditional_cost_minimizes_at_three=cost[0]['cost_cE1_cT1']==min(q['cost_cE1_cT1'] for q in cost))
    checks={a:bool(b) for a,b in checks.items()};assert all(checks.values()),checks
    result=dict(study='MCC3.0 existing spatial renderer attached to prime CRT SOURCE v0.4',
      validation_inputs=dict(book='MCC_3_0_Full_Book_KO_v0.20.md',book_library_id='libfile_c87d6e336cb88191aff11b4e987a21c3',book_version=18,
        chapters=[4,'7.3',12,114,115,116,117],shape=shape,source_capacity=M,N=N,c=c,dt=dt,
        kernel_payload='uniform on new selected addresses; test payload, not original sector coefficients',seed=20261016),
      WRRA_transformation=dict(metric='flat periodic metric with edge spacing c*dt, inherited calibration',
        kernels='original 2,3,5 tap formula retained as address-owned profile observables under CRT',
        photons='H=hbar*c*|k|, inherited physical dispersion; distinct from dimensionless combinatorial Laplacian evolution',
        low_pass='keep 0<c*dt*|k|<0.8*pi; unused high-k modes explicitly excluded',
        ownership='transport state and observables together; freezing an observable asks a different physical question',
        conditional_minimality='local propagating spin2 admissibility d>=3 plus nonnegative increasing C(d); not inferred from Pi3'),
      outputs=dict(spacing_m=spacing,period_lengths_m=[m*spacing for m in shape],edge_relative_errors=edge_errors,
        maximum_metric_triangle_defect_m=violation,old_first_axis_edges_not_new_neighbors=old_edges_not_new_nearest,
        address_profile_error=profile_error,ownership_transport_errors=ownership_errors,
        fixed_observable_changes=frozen_observable_changes,photon_norm_error=photon_norm_error,
        photon_energy_relative_error=abs(e1/e0-1),seven_direction_speed_errors=speed_errors,
        excluded_temporal_alias_modes=aliased,total_modes=M,selected_low_pass_modes=int(low.sum()),conditional_cost=cost),
      refutation_conditions=['Inherited spacing no longer equals c*dt on declared nearest-neighbor moves.',
        'Address profile ownership is lost during the mapping.',
        'Seven-direction fixed-c or norm/energy checks fail in the declared low-pass band.',
        'The changed CRT graph is described as the same old row-major physical graph.',
        'This spectral propagation is called strictly local causal Maxwell evolution without further checks.'],
      conclusions=dict(existing_MCC30_spatial_rules_reused=True,new_CRT_geometry_physically_calibrated=True,
        address_profile_interface_executed=True,original_sector_payloads_and_GR_CMB_rerun=False,
        metric_unique_from_arithmetic=False,strict_lightcone_locality_proven=False,Maxwell_Lorentz_complete=False,
        macroscopic_length_scale_derived=False,three_axis_selection_unconditional=False),checks=checks)
    (ROOT/'results/mcc30_space_bridge.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(dict(checks_passed=sum(checks.values()),outputs=result['outputs']),indent=2))
if __name__=='__main__':main()
