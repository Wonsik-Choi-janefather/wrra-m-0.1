#!/usr/bin/env python3
"""Audit compact packing and an explicit CRT relation-preserving replacement.
No physical time, composition fit, or selection of three axes is inferred.
"""
import json, math
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parent
N=1015000

def selected_mask(limit):
    omega=np.zeros(limit+1,dtype=np.int8)
    for p in range(2,limit+1):
        if omega[p]==0: omega[p::p]+=1
    return omega>=2

def main():
    selected=selected_mask(N)
    addresses=np.flatnonzero(selected)
    # Prior embedding: rank in selected addresses, row-major SOURCE position.
    old_shape=(201,65,77);old_size=math.prod(old_shape)
    ranks=np.full(N+1,-1,dtype=np.int64);ranks[addresses]=np.arange(len(addresses))
    old_rows=[]
    for p in (2,3,5,7,11,13,67):
        a=addresses[addresses<=N//p];b=p*a
        good=selected[b];a=a[good];b=b[good]
        ca=np.array(np.unravel_index(ranks[a],old_shape)).T
        cb=np.array(np.unravel_index(ranks[b],old_shape)).T
        # Necessary condition for a multiplicative residue representation.
        mismatch=np.any(cb!=(p*ca)%np.array(old_shape),axis=1)
        old_rows.append(dict(prime=p,edges=int(len(a)),CRT_multiplication_violations=int(mismatch.sum())))
    counts=np.bincount(addresses%old_size,minlength=old_size)
    old_collisions=int(np.sum(np.maximum(counts-1,0)))

    # Extend a declared finite resource choice, keeping the same three-block form.
    # This is a changed SOURCE capacity, not a proof of unique/minimal resources.
    primes=(3,5,7,11,13,71);shape=(213,65,77);M=math.prod(shape)
    assert M>N
    k=np.arange(M,dtype=np.int64)
    coords=tuple(k%m for m in shape)
    flat=np.ravel_multi_index(coords,shape)
    inv=np.empty(M,dtype=np.int64);inv[flat]=k
    crt_steps=[(M//m)*pow(M//m,-1,m)%M for m in shape]
    prime_steps={p:(M//p)*pow(M//p,-1,p)%M for p in primes}
    rng=np.random.default_rng(20261016)
    v=rng.normal(size=M)+1j*rng.normal(size=M);v/=np.linalg.norm(v)
    def J(x):
        out=np.empty(M,dtype=complex);out[flat]=x;return out.reshape(shape)
    def Ji(x): return x.ravel()[flat]
    errors=[]
    for axis,delta in enumerate(crt_steps):
        errors.append(float(np.max(abs(J(np.roll(v,delta))-np.roll(J(v),1,axis)))))
    prime_errors=[]
    for p,delta in prime_steps.items():
        axis=next(a for a,m in enumerate(shape) if m%p==0)
        local_step=delta%shape[axis]
        prime_errors.append(float(np.max(abs(J(np.roll(v,delta))-np.roll(J(v),local_step,axis)))))
    L1=np.zeros(M,dtype=complex);Lv=np.zeros(shape,dtype=complex)
    for axis,delta in enumerate(crt_steps):
        L1+=2*v-np.roll(v,delta)-np.roll(v,-delta)
        Lv+=2*J(v)-np.roll(J(v),1,axis)-np.roll(J(v),-1,axis)
    lap_error=float(np.max(abs(J(L1)-Lv)))
    # Every residue, for all primes tested: multiplication relation preserved.
    mult_rows=[]
    for p in (2,3,5,7,11,13,71):
        target=(p*k)%M
        mismatch=sum(int(np.count_nonzero(target%m!=(p*(k%m))%m)) for m in shape)
        mult_rows.append(dict(prime=p,relation_violations=mismatch,kernel_size=math.gcd(p,M),
            invertible=math.gcd(p,M)==1))
    # Full translation+selection cannot remain inside the selected output sector.
    active=np.zeros(M,dtype=bool);active[2:N+1]=True
    mask=np.zeros(M,dtype=bool);mask[2:N+1]=selected[2:]
    nonclosure=[]
    split_errors=[]
    for axis,delta in enumerate(crt_steps):
        Uv=np.roll(v,delta);s=np.roll(mask*v,delta);h=np.roll((~mask)*v,delta)
        split_errors.append(float(np.max(abs(Uv-s-h))))
        nonclosure.append(dict(axis=axis,selected_to_other=int(np.count_nonzero(mask&~mask[(k+delta)%M])),
            active_to_padding=int(np.count_nonzero(active&~active[(k+delta)%M]))))
    energy_error=abs(float(np.vdot(mask*v,mask*v).real+np.vdot((~mask)*v,(~mask)*v).real-np.vdot(v,v).real))
    # Prime multiplication with nontrivial kernel needs an auxiliary record.
    dilation=[]
    for p in (3,5,7,11,13,71):
        y=(p*k)%M;c=k//(M//p)
        pairs=y.astype(np.int64)*p+c
        dilation.append(dict(prime=p,unique_recorded_images=int(np.unique(pairs).size),source_states=M))
    from prime_generator_bridge import heat_dimension
    from study import residual3
    heat=[dict(scale=t,dimension=heat_dimension(shape,t)) for t in (16.,32.,64.)]
    gates=[int(abs(residual3(s))<=1e-9) for s in (.5+14.134725141734695j,.5+14.234725141734695j)]
    eig=np.zeros(shape)
    for axis,m in enumerate(shape):
        lens=[1,1,1];lens[axis]=m
        eig+=(4*np.sin(np.pi*np.arange(m)/m)**2).reshape(lens)
    initial=J(mask*v)
    field=np.fft.ifftn(np.exp(-1j*eig)*np.fft.fftn(initial,norm='ortho'),norm='ortho')
    restored=Ji(np.fft.ifftn(np.exp(1j*eig)*np.fft.fftn(field,norm='ortho'),norm='ortho'))
    evolution_error=float(np.max(abs(restored-mask*v)))
    output_norm_error=abs(float(np.vdot(field,field).real-np.vdot(mask*v,mask*v).real))
    checks=dict(new_shape_retains_three_axis_plateau=all(abs(h['dimension']-3)<.05 for h in heat),
        unchanged_zeta_gate_accepts_zero_rejects_control=gates==[1,0],
        new_CRT_output_evolution_inverts=evolution_error<1e-13,
        new_output_preserves_selected_norm=output_norm_error<1e-12,
        old_compact_order_packing_fails_multiplication=all(r['CRT_multiplication_violations']>0 for r in old_rows),
        original_CRT_capacity_has_selected_collisions=old_collisions>0,
        new_CRT_capacity_covers_full_address_domain=M>N,
        CRT_bijection=np.unique(flat).size==M,
        CRT_inverse=np.array_equal(inv[flat],k),
        axis_intertwining=max(errors)<1e-13,
        all_original_prime_shifts_intertwine=max(prime_errors)<1e-13,
        paired_prime_steps_equal_axis_steps=all((prime_steps[a]+prime_steps[b])%M==d for (a,b),d in zip(((3,71),(5,13),(7,11)),crt_steps)),
        laplacian_intertwining=lap_error<1e-13,
        full_modular_multiplication_relations_preserved=all(r['relation_violations']==0 for r in mult_rows),
        two_is_invertible_for_this_odd_SOURCE=math.gcd(2,M)==1,
        resource_prime_multiplications_are_not_unitary=all(math.gcd(p,M)>1 for p in primes),
        selected_sector_not_invariant=all(r['selected_to_other']>0 for r in nonclosure),
        finite_active_domain_not_invariant=all(r['active_to_padding']>0 for r in nonclosure),
        output_plus_hold_transport_equals_full_transport=max(split_errors)<1e-13,
        selection_split_preserves_norm=energy_error<1e-12,
        kernel_record_restores_injectivity=all(r['unique_recorded_images']==M for r in dilation))
    checks={a:bool(b) for a,b in checks.items()};assert all(checks.values()),checks
    result=dict(study='CRT relation-preserving prime SOURCE interface v0.3',
        validation_inputs=dict(N=N,selected_count=int(mask.sum()),old_shape=old_shape,old_capacity=old_size,new_primes=primes,new_shape=shape,new_capacity=M,seed=20261016),
        WRRA_transformation=dict(J='|n mod M> -> |n mod 213,n mod 65,n mod 77>',
            address_embedding='Natural addresses 2..N use their distinct residues; all other slots are retained as auxiliary capacity.',
            axis='delta_a=(M/m_a)*inverse(M/m_a mod m_a) mod M; J S_delta_a=U_a J',
            multiplication='J|pn mod M> equals coordinatewise multiplication of J|n>; this is modular multiplication, not a unitary prime shift.',
            kernel_record='For resource prime p, retain c=floor(n/(M/p)); (pn mod M,c) is injective.',
            interface_choice='CRT residue interpretation is explicit new interface structure; three blocks are inherited, not derived.',
            selection='Keep Pi3 and I-Pi3 branches, with padding; do not assert the selected sector is invariant.'),
        outputs=dict(old_packing=old_rows,old_selected_CRT_collisions=old_collisions,axis_steps=crt_steps,
            axis_intertwining_errors=errors,prime_intertwining_errors=prime_errors,laplacian_error=lap_error,
            heat_dimensions=heat,zeta_gate_values=gates,evolution_inverse_error=evolution_error,output_norm_error=output_norm_error,multiplication=mult_rows,sector_boundary=nonclosure,split_transport_error=max(split_errors),norm_error=energy_error,kernel_records=dilation),
        refutation_conditions=['CRT intertwining or multiplication fails at any declared residue.',
            'Two distinct active natural addresses collide in the new embedding.',
            'Unrecorded multiplication by a resource prime is claimed unitary.',
            'Closed transport is claimed on the selected sector despite the reported escape edges.',
            'Modular residue operations are claimed to preserve ordinary unbounded integer multiplication or metric locality without an additional proof.'],
        conclusions=dict(original_sorted_packing_relation_preserving=False,
            new_CRT_interface_preserves_declared_SOURCE_shifts_and_modular_arithmetic=True,
            physical_arithmetic_locality_proven=False,three_axes_uniquely_derived=False,
            arithmetic_class_3_equals_spatial_dimension_by_theorem=False,
            all_natural_multiplication_relations_globally_preserved=False,
            composition_fitted=False,autonomous_physical_zeta_gate_proven=False),checks=checks)
    (ROOT/'results/relation_preserving_bridge.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(dict(checks_passed=sum(checks.values()),inputs=result['validation_inputs'],outputs=result['outputs']),indent=2))
if __name__=='__main__':main()
