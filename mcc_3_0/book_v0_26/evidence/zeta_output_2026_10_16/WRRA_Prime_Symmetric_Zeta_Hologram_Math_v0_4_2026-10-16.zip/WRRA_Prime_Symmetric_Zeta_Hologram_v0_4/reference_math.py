#!/usr/bin/env python3
"""Reproduce the fold-relation AND/XOR study.

This is a numerical study and an algebraic reformulation, not an RH proof.
The downstream analytic candidate signs each term by its parity. It is an
explicit extension of, not an identification with, XOR of a finite input set.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import platform
from pathlib import Path

import numpy as np
import scipy
from scipy.optimize import brentq, root
from scipy.special import bernoulli


BERNOULLI = bernoulli(24)
TOL = 1e-7
HEIGHT_GUESSES = [14.13, 21.02, 25.01, 30.42, 32.94,
                  37.59, 40.92, 43.33, 48.01, 49.77]


def omega_sieve(limit: int) -> np.ndarray:
    spf = np.arange(limit + 1, dtype=np.int64)
    for p in range(2, math.isqrt(limit) + 1):
        if spf[p] == p:
            for n in range(p * p, limit + 1, p):
                if spf[n] == n:
                    spf[n] = p
    out = np.zeros(limit + 1, dtype=np.int16)
    for n in range(2, limit + 1):
        out[n] = out[n // spf[n]] + 1
    return out


def totients(limit: int) -> np.ndarray:
    phi = np.arange(limit + 1, dtype=np.int64)
    for p in range(2, limit + 1):
        if phi[p] == p:
            phi[p::p] -= phi[p::p] // p
    return phi


PHI = totients(1024)


def zeta_em(s: complex, min_n: int = 200, order: int = 12) -> complex:
    """Euler--Maclaurin evaluation, away from the pole s=1.

    Double precision only. Independent N=400 evaluations are compared in
    the output. The study uses s in a compact domain with Re(s)>0.
    """
    s = complex(s)
    if s == 1:
        raise ValueError("s=1 is the excluded zeta pole")
    count = max(min_n, int(abs(s.imag) / 3) + 100)
    n = np.arange(1, count, dtype=float)
    value = np.sum(np.exp(-s * np.log(n)))
    value += count ** (1 - s) / (s - 1) + .5 * count ** (-s)
    rising = s
    for k in range(1, order + 1):
        if k > 1:
            rising *= (s + 2*k - 3) * (s + 2*k - 2)
        value += (BERNOULLI[2*k] / math.factorial(2*k)
                  * rising * count ** (-s - 2*k + 1))
    return complex(value)


def log_zeta(s: complex) -> complex:
    """Principal log; a local branch convention, not a global holomorphic log.

    For large real part use log1p of a short absolutely convergent sum.
    Singular scaled points are excluded. Zeta zeros are approached by
    limits and are not evaluated as literal 0*log(0).
    """
    s = complex(s)
    if s.real > 12:
        n = np.arange(2, 65, dtype=float)
        return complex(np.log1p(np.sum(np.exp(-s * np.log(n)))))
    value = zeta_em(s)
    if value == 0:
        # Numerical guard for finite floating-point evaluations only.
        # The mathematical interpretation at a zero uses a local limit.
        return complex(math.log(np.finfo(float).tiny), 0.)
    return complex(np.log(value))


def prime_relation_sum(s: complex, terms: int | None = None) -> complex:
    """B(s)=sum_p 1/(p**s-1) for Re(s)>1, continued by log zeta.

    B(s)=sum_{m>=1} phi(m)/m * log(zeta(m*s)). This identity is first
    derived in the absolutely convergent half-plane. Continuation uses
    the displayed principal-log prescription; local logarithmic
    singularities and branch cuts remain part of the definition.
    """
    s = complex(s)
    if s.real <= 0:
        raise ValueError("This implementation requires Re(s)>0")
    count = terms or max(32, math.ceil(50 / s.real))
    if count >= len(PHI):
        raise ValueError("Requested continuation exceeds totient table")
    return sum(float(PHI[m]) / m * log_zeta(m*s)
               for m in range(1, count + 1))


def residues(s: complex, terms: int | None = None) -> tuple[complex, complex, complex]:
    """U=Z*(B-1), V=Z*((1-2**(1-s))*B-1).

    These formulas evaluate continued candidates; they use zeta as a
    computational ingredient. Benchmark success is therefore an identity
    check, not independent numerical discovery of zeta zeros.
    """
    z = zeta_em(s)
    b = prime_relation_sum(s, terms)
    a = 1 - 2 ** (1-s)
    return z * (b-1), z * (a*b-1), z


def classify(u: complex, v: complex) -> dict:
    upstream = abs(u) <= TOL
    downstream = abs(v) <= TOL
    residual = abs(u)**2 + abs(v)**2
    return {
        "upstream_pass": bool(upstream),
        "downstream_pass": bool(downstream),
        "AND": bool(upstream and downstream),
        "XOR": bool(upstream != downstream),
        "OR": bool(upstream or downstream),
        "combined_residual": float(residual),
        "influence_product": float((1+abs(u)**2)*(1+abs(v)**2)),
    }


def benchmark(label: str, s: complex, expected_zero: bool) -> dict:
    u, v, z = residues(s)
    reconstructed = 2 ** (s-1) * ((1-2 ** (1-s))*u-v)
    info = {
        "label": label, "sigma": float(s.real), "t": float(s.imag),
        "expected_zeta_zero": expected_zero,
        "abs_zeta": float(abs(z)), "abs_U": float(abs(u)),
        "abs_V": float(abs(v)),
        "reconstruction_error": float(abs(reconstructed-z)),
        "zeta_N200_N400_difference": float(abs(z-zeta_em(s, min_n=400))),
    }
    info.update(classify(u, v))
    return info


def write_csv(path: Path, rows: list[dict]) -> None:
    with path.open("w", newline="", encoding="utf-8-sig") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=Path("results"))
    parser.add_argument("--skip-grid", action="store_true")
    args = parser.parse_args()
    out = args.output
    out.mkdir(parents=True, exist_ok=True)
    omega = omega_sieve(200000)

    # Exact finite identities: addition parity is XOR; product parity AND.
    arithmetic = {
        "omega_doubling": all(int(omega[2*m]) == int(omega[m])+1
                               for m in range(1, 100001)),
        "parity_addition_XOR": all(((a+b) % 2) == ((a % 2) ^ (b % 2))
                                    for a in range(101) for b in range(101)),
        "parity_product_AND": all(((a*b) % 2) == ((a % 2) & (b % 2))
                                    for a in range(101) for b in range(101)),
        "literal_prime_AND_even_passes": [n for n in range(2, 10001)
                                          if omega[n] == 1 and n % 2 == 0],
    }
    truth = [{"upstream": a, "downstream": b,
              "AND": a & b, "XOR": a ^ b, "OR": a | b}
             for a in (0,1) for b in (0,1)]
    write_csv(out/"logic_truth_table.csv", truth)

    prefix = []
    total = 0
    for p in np.flatnonzero(omega == 1)[:12]:
        total += int(p)
        prefix.append({"last_prime": int(p), "sum_of_primes": total,
                       "sum_parity_XOR": total % 2})
    write_csv(out/"raw_parity_prefix.csv", prefix)

    # Check the continued formulas against direct convergent sums.
    direct_checks = []
    n = np.arange(1, len(omega), dtype=float)
    d = omega[1:].astype(float)-1
    eps = np.where(n % 2 == 1, 1., -1.)
    for s in (3.,4.):
        direct_u = float(np.sum(d*n**(-s)))
        direct_v = float(np.sum(eps*d*n**(-s)))
        u,v,_ = residues(complex(s))
        limit = len(omega)-1
        bound = (limit**(1-s)/math.log(2)
                 * (math.log(limit)/(s-1)+1/(s-1)**2))
        direct_checks.append({"s":s, "N":limit,
                              "U_difference":float(abs(direct_u-u)),
                              "V_difference":float(abs(direct_v-v)),
                              "absolute_tail_bound":bound,
                              "pass":bool(max(abs(direct_u-u), abs(direct_v-v))
                                          <= bound+1e-12)})

    roots = []
    rows = []
    for i,height in enumerate(HEIGHT_GUESSES, 1):
        guess_sigma = .4 if i % 2 else .6
        def objective(x):
            value = zeta_em(x[0]+1j*x[1])
            return [value.real, value.imag]
        found = root(objective, [guess_sigma, height], tol=1e-11)
        s = complex(*found.x)
        if abs(zeta_em(s)) > 1e-10:
            raise RuntimeError(f"Reference root failed: {i}: {s}")
        roots.append(s)
        rows.append(benchmark(f"reference_zero_{i}", s, True))
        for label,offset in [("t_plus_0.1",.1j), ("sigma_plus_0.05",.05),
                             ("sigma_minus_0.05",-.05)]:
            rows.append(benchmark(f"zero_{i}_{label}",s+offset,False))

    extra = brentq(lambda x: prime_relation_sum(complex(x)).real-1,
                   1.1,2.,xtol=1e-13)
    for label,s in [("upstream_extra_real_root",complex(extra)),
                    ("real_2",2+0j),("real_3",3+0j),
                    ("eta_prefactor_zero_1",1+2j*math.pi/math.log(2)),
                    ("eta_prefactor_zero_2",1+4j*math.pi/math.log(2))]:
        rows.append(benchmark(label,s,False))
    write_csv(out/"benchmarks.csv", rows)

    approach = []
    for delta in (1e-2,1e-4,1e-6,1e-8):
        u,v,z = residues(roots[0]+delta)
        approach.append({"delta":delta, "abs_zeta":abs(z),
                         "abs_U":abs(u),"abs_V":abs(v)})
    write_csv(out/"zero_approach.csv",approach)

    grid_rows = []
    sigmas = np.linspace(.25,.75,21)
    heights = np.unique(np.concatenate([np.arange(5.,50.01,.5),
                                       np.array([s.imag for s in roots])]))
    surface = np.empty((len(heights),len(sigmas)))
    if not args.skip_grid:
        for ti,t in enumerate(heights):
            for si,sigma in enumerate(sigmas):
                s = complex(sigma,t)
                u,v,z = residues(s)
                flags = classify(u,v)
                expected = min(abs(s-r) for r in roots) < 1e-7
                grid_rows.append({"sigma":float(sigma),"t":float(t),
                                  "reference_zero_point":expected,
                                  "abs_zeta":float(abs(z)),"abs_U":float(abs(u)),
                                  "abs_V":float(abs(v)),**flags})
                surface[ti,si] = math.log10(max(flags["combined_residual"],1e-24))
            if ti % 25 == 0:
                print(f"grid: {ti+1}/{len(heights)} height slices",flush=True)
        write_csv(out/"grid.csv",grid_rows)
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        fig,ax = plt.subplots(figsize=(7,8),constrained_layout=True)
        picture=ax.pcolormesh(sigmas,heights,surface,shading="nearest",
                              cmap="viridis",vmin=-12,vmax=2)
        ax.scatter([s.real for s in roots],[s.imag for s in roots],
                   marker="x",color="red",s=24,label="Reference zeta zeros")
        ax.axvline(.5,color="white",alpha=.4,lw=.8)
        ax.set(xlabel="Real part sigma",ylabel="Imaginary part t",
               title="Combined fold-relation residual\nlog10(|U|^2 + |V|^2)")
        ax.legend(loc="lower left",fontsize=8)
        fig.colorbar(picture,ax=ax,label="log10 residual (floor 1e-24)")
        fig.savefig(out/"combined_residual.png",dpi=160)
        plt.close(fig)

    positives = [row for row in rows if row["expected_zeta_zero"]]
    negatives = [row for row in rows if not row["expected_zeta_zero"]]
    extra_row = next(row for row in rows if row["label"] == "upstream_extra_real_root")
    summary = {
        "date":"2026-10-16", "version":"0.1", "threshold":TOL,
        "environment":{"python":platform.python_version(),
                       "numpy":np.__version__,"scipy":scipy.__version__},
        "definitions":{
            "D(n)":"Omega(n)-1, n>=1, hence D(1)=-1 as an added baseline convention",
            "U":"sum D(n)*n**(-s), initially Re(s)>1",
            "V":"sum (-1)**(n-1)*D(n)*n**(-s), initially Re(s)>1",
            "parity_extension":"Each term's parity is mapped to +/-1. This is not a direct XOR of complex amplitudes.",
            "reconstruction":"zeta(s)=2**(s-1)*((1-2**(1-s))*U(s)-V(s))",
            "influence_product":"(1+abs(U)**2)*(1+abs(V)**2); continuous score, not the original integer length product",
        },
        "arithmetic_checks":arithmetic,
        "direct_series_checks":direct_checks,
        "reference_root_count":len(positives),
        "benchmark_negative_count":len(negatives),
        "AND_reference_passes":sum(row["AND"] for row in positives),
        "AND_negative_false_passes":sum(row["AND"] for row in negatives),
        "XOR_reference_passes":sum(row["XOR"] for row in positives),
        "XOR_negative_false_passes":sum(row["XOR"] for row in negatives),
        "extra_real_root":extra_row,
        "max_reconstruction_error":max(row["reconstruction_error"] for row in rows),
        "max_zeta_N200_N400_difference":max(row["zeta_N200_N400_difference"] for row in rows),
        "grid_point_count":len(grid_rows),
        "grid_reference_points":sum(row["reference_zero_point"] for row in grid_rows),
        "grid_AND_false_passes":sum(row["AND"] and not row["reference_zero_point"] for row in grid_rows),
        "grid_AND_reference_passes":sum(row["AND"] and row["reference_zero_point"] for row in grid_rows),
        "critical_line_derived":False,
        "zero_finding_independent_of_zeta":False,
        "global_single_valued_analytic_continuation_established":False,
        "branch_convention":"Principal logs in B; zeta-zero values interpreted through fixed local branch limits.",
        "sources":["https://dlmf.nist.gov/25.2","https://dlmf.nist.gov/27.4",
                   "https://dlmf.nist.gov/25.10","https://dlmf.nist.gov/25.4"],
    }
    (out/"results.json").write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding="utf-8")
    assert all(arithmetic[key] for key in ["omega_doubling","parity_addition_XOR","parity_product_AND"])
    assert arithmetic["literal_prime_AND_even_passes"] == [2]
    assert all(check["pass"] for check in direct_checks)
    assert summary["AND_reference_passes"] == len(positives)
    assert summary["AND_negative_false_passes"] == 0
    assert summary["XOR_reference_passes"] == 0
    assert summary["max_reconstruction_error"] < 1e-10
    print(json.dumps({key:summary[key] for key in [
        "reference_root_count","benchmark_negative_count","AND_reference_passes",
        "AND_negative_false_passes","XOR_reference_passes","XOR_negative_false_passes",
        "max_reconstruction_error","grid_point_count","grid_AND_false_passes",
        "grid_AND_reference_passes"]},indent=2),flush=True)


if __name__ == "__main__":
    main()
