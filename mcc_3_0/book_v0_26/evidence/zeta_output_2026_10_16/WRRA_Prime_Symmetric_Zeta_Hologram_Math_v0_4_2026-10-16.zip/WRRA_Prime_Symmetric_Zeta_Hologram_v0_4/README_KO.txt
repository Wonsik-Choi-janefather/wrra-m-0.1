소수 대칭 차원 분류와 제타 홀로그램 출력기 — 수학 검증 v0.2

물질/암흑물질 구성비는 포함하지 않는다.
REPORT_KO.txt: 정의, 유도, 계산 결과와 적용 한계.
study.py: 세 부류와 공통 판독, 영점10개/비영점39개, 유한 주소 대조.
renderer_demo.py: 명시적 차원 선택자와 보류 통로를 갖춘3D 역FFT 출력기.
reference_math.py: Euler-Maclaurin 수치 평가 참조 구현.
results/: 전체 수치 및33개 검산.

실행:
python -m pip install -r requirements.txt
python study.py
python renderer_demo.py

분류의3은 정보 부류 표지다. 실제 공간의 세 축을 도출했다는 주장은 아니다.
영점은 출력 허가조건, 출력 내용은 별도로 유지한3차원 부류의 주소 상태다.

v0.2: 기존 소수 연산자 구현을 확인하고 실제 출력기에 연결했다.
PRIME_OPERATOR_BRIDGE_KO.txt와 prime_generator_bridge.py를 추가했다.
추가 실행: python prime_generator_bridge.py
새 연결은 전체50개 검산 중17개다. 임시 역FFT 예시는 비교용으로 남긴다.
산술 부류의3과 생성자 축 수3이 자동으로 같은 개념이라고 주장하지 않는다.

 v0.3: RELATION_PRESERVATION_KO.txt를 먼저 읽으십시오.
python relation_preserving_bridge.py
기존 v0.2 코드는 비교용으로 보존하며 신규 CRT 연결과 혼동하지 않습니다.
신규 21개 검산을 실행했고 기존 50개 기록은 보존했습니다.

v0.4: MCC30_SPACE_CONNECTION_KO.txt에서3.0 실제공간 규칙 연결을 확인하십시오.
python mcc30_space_bridge.py
이번 신규12개 검산 통과. 원래 책은 수정하지 않았습니다.
