#!/usr/bin/env python3
"""Conditional arithmetic hologram: selector plus a declared unitary kernel.

The 3D array layout and inverse FFT are chosen rendering rules, not deductions
of physical space. The spectral zero gate is calculated from the analytic
readout. Dimension1/2 information is retained in a separate holding channel.
"""
import json
import math
from pathlib import Path
import numpy as np
from study import residual3,bounded_readout

ROOT=Path(__file__).resolve().parent
N=1015000
SHAPE=(500,29,70)
TOL=1e-9


def main():
    n=np.arange(1,N+1)
    prime=np.ones(N+1,dtype=bool);prime[:2]=False
    for p in range(2,math.isqrt(N)+1):
        if prime[p]:prime[p*p::p]=False
    distinct=np.zeros(N+1,dtype=np.int8)
    for p in np.flatnonzero(prime):distinct[p::p]+=1
    d=np.zeros(N,dtype=np.int8)
    d[prime[n]]=1
    d[(distinct[n]==1)&~prime[n]&(n>=2)]=2
    d[distinct[n]>=2]=3
    projected=d==3
    rho=.5+14.134725141734695j
    cases=[('all_classes_at_reference_zero',rho,n>=2),
           ('all_classes_at_nonzero',rho+.1j,n>=2),
           ('prime_input_at_zero',rho,d==1),
           ('prime_power_input_at_zero',rho,d==2),
           ('mixed_input_at_zero',rho,d==3)]
    rows=[]
    for label,s,mask in cases:
        amplitude=np.zeros(N,dtype=complex)
        amplitude[mask]=np.exp(-1j*s.imag*np.log(n[mask]))/np.sqrt(mask.sum())
        q=int(abs(residual3(s))<=TOL)
        output=np.sqrt(q)*projected*amplitude
        held=((~projected)+np.sqrt(1-q)*projected)*amplitude
        field=np.fft.ifftn(output.reshape(SHAPE),norm='ortho')
        reconstructed=np.fft.fftn(field,norm='ortho').ravel()
        source_norm=float(np.vdot(amplitude,amplitude).real)
        out_norm=float(np.vdot(field,field).real)
        held_norm=float(np.vdot(held,held).real)
        rows.append(dict(case=label,sigma=s.real,t=s.imag,hard_zero_gate=q,
            soft_3D_readout=bounded_readout(s)[2],source_norm=source_norm,
            output_norm=out_norm,held_norm=held_norm,
            conservation_error=abs(out_norm+held_norm-source_norm),
            kernel_inversion_error=float(np.max(abs(reconstructed-output))),
            dimension1_2_leakage_max=float(np.max(abs(reconstructed[~projected])))))
    checks=dict(grid_has_N_slots=math.prod(SHAPE)==N,
        all_channels_conserved=all(r['conservation_error']<1e-12 for r in rows),
        only_dimension3_in_output=all(r['dimension1_2_leakage_max']<1e-14 for r in rows),
        kernel_is_invertible=all(r['kernel_inversion_error']<1e-14 for r in rows),
        reference_zero_outputs_mixed_information=rows[0]['output_norm']>0,
        nonzero_is_held=rows[1]['output_norm']==0,
        dimension1_input_is_held=rows[2]['output_norm']==0,
        dimension2_input_is_held=rows[3]['output_norm']==0,
        pure_dimension3_input_outputs_fully=abs(rows[4]['output_norm']-1)<1e-12)
    checks={k:bool(v) for k,v in checks.items()}
    assert all(checks.values()),checks
    r=dict(study='Conditional prime-symmetric hologram renderer v0.1',
        validation_inputs=dict(N=N,grid_shape=SHAPE,zero_tolerance=TOL,source_amplitudes='equal magnitude on the prepared input support, phase -t*log(n)',no_composition_model=True),
        WRRA_transformation=dict(projector='Pi3=diag(indicator(d(n)=3))',ideal_event='L(s)=indicator(R3(s)=0), computed with the stated finite tolerance',output='sqrt(L)*Pi3*psi',held='[(I-Pi3)+sqrt(1-L)*Pi3]*psi',kernel='Chosen unitary 3D inverse FFT, grid500x29x70; NOT derived physical propagation',soft_alternative='q3(s) can replace L but then nonzero modes have partial output; it is not a strict zero-only event'),
        outputs=rows,checks=checks,
        conclusions=dict(conditional_3D_information_only_renderer_executed=True,information_retained_in_hold_channel=True,physical_holographic_kernel_derived=False,spatial_dimension_derived=False,finite_N_autonomous_zero_gate_proven=False))
    (ROOT/'results/hologram_demo.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(dict(checks_passed=sum(checks.values()),cases=rows),indent=2))


if __name__=='__main__':
    main()
