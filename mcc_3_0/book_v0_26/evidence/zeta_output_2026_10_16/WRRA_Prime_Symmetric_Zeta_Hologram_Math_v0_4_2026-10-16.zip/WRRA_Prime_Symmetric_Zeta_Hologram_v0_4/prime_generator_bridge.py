#!/usr/bin/env python3
"""Connect the existing prime-partition SOURCE to the new zeta outlet.

The source operator is reconstructed from Choi's 2026-08-25 v1.0 paper,
Sections 3-12, whose current Library text is included as an excerpt. This
executes a conditional module connection; it does not derive the partition
or identify graph spectral dimension with observed physical space.
"""
import itertools
import json
import math
from pathlib import Path
import numpy as np
from study import residual3

ROOT=Path(__file__).resolve().parent
N=1015000
PRIMES=(3,5,7,11,13,67)
BLOCKS=((3,67),(5,13),(7,11))
SHAPE=tuple(math.prod(b) for b in BLOCKS)
SIZE=math.prod(SHAPE)
SCALES=(16.,32.,64.)
DIMENSION_TOLERANCE=.05


def perfect_pairings(items):
    if not items:
        yield ()
        return
    p=items[0]
    for i in range(1,len(items)):
        q=items[i]
        remainder=items[1:i]+items[i+1:]
        for rest in perfect_pairings(remainder):
            yield ((p,q),)+rest


def heat_dimension(shape,t):
    value=0.
    for m in shape:
        lam=4*np.sin(np.pi*np.arange(m)/m)**2
        e=np.exp(-t*lam)
        value+=2*t*float(np.sum(lam*e)/np.sum(e))
    return value


def main():
    n=np.arange(1,N+1)
    prime=np.ones(N+1,dtype=bool);prime[:2]=False
    for p in range(2,math.isqrt(N)+1):
        if prime[p]:prime[p*p::p]=False
    distinct=np.zeros(N+1,dtype=np.int8)
    for p in np.flatnonzero(prime):distinct[p::p]+=1
    dimension=np.zeros(N,dtype=np.int8)
    dimension[prime[n]]=1
    dimension[(distinct[n]==1)&~prime[n]&(n>=2)]=2
    dimension[distinct[n]>=2]=3
    selected=dimension==3
    R=int(selected.sum())
    assert R<=SIZE

    # CRT prime shifts inside each block: T_p T_q is the diagonal +1 update.
    crt=[]
    for axis,(p,q) in enumerate(BLOCKS):
        size=p*q
        step_p=q*pow(q,-1,p)
        step_q=p*pow(p,-1,q)
        crt.append(dict(axis=axis,p=p,q=q,period=size,step_p=step_p,step_q=step_q,
            combined_step=(step_p+step_q)%size))
    rng=np.random.default_rng(20261016)
    probe=rng.normal(size=SHAPE)+1j*rng.normal(size=SHAPE)
    probe/=np.linalg.norm(probe.ravel())
    paired_errors=[]
    L=np.zeros(SHAPE,dtype=complex)
    for c in crt:
        axis=c['axis']
        paired=np.roll(np.roll(probe,c['step_p'],axis),c['step_q'],axis)
        direct=np.roll(probe,1,axis)
        paired_errors.append(float(np.max(abs(paired-direct))))
        L+=2*probe-np.roll(probe,1,axis)-np.roll(probe,-1,axis)
    eigenvalues=np.zeros(SHAPE)
    for axis,m in enumerate(SHAPE):
        lens=[1,1,1];lens[axis]=m
        eigenvalues+=(4*np.sin(np.pi*np.arange(m)/m)**2).reshape(lens)
    spectral_L=np.fft.ifftn(eigenvalues*np.fft.fftn(probe,norm='ortho'),norm='ortho')
    laplacian_error=float(np.max(abs(L-spectral_L)))
    rayleigh=complex(np.vdot(probe,L))

    # Same prime resources, three source partitions; filter settings are frozen.
    dimension_rows=[]
    shapes=[(SIZE,),(math.prod(PRIMES[:-2]),math.prod(PRIMES[-2:])),SHAPE]
    for shape in shapes:
        for t in SCALES:
            D=heat_dimension(shape,t)
            dimension_rows.append(dict(periods=list(shape),declared_axes=len(shape),
                diffusion_scale=t,measured_spectral_dimension=D,error_from_integer=abs(D-len(shape))))

    # The explicit packing J is an isometry for the selected addresses only.
    # It is a new interface contract, not an arithmetic-adjacency theorem.
    phase=np.exp(-1j*14.134725141734695*np.log(n))
    cases=[('all_classes_at_zero',.5+14.134725141734695j,n>=2),
           ('all_classes_at_nonzero',.5+14.234725141734695j,n>=2),
           ('prime_input_at_zero',.5+14.134725141734695j,dimension==1),
           ('prime_power_input_at_zero',.5+14.134725141734695j,dimension==2),
           ('mixed_input_at_zero',.5+14.134725141734695j,dimension==3)]
    propagation=np.exp(-1j*eigenvalues)
    rows=[]
    for name,s,support in cases:
        a=np.zeros(N,dtype=complex)
        a[support]=np.exp(-1j*s.imag*np.log(n[support]))/np.sqrt(support.sum())
        gate=int(abs(residual3(s))<=1e-9)
        packed=np.zeros(SIZE,dtype=complex)
        packed[:R]=np.sqrt(gate)*a[selected]
        initial=packed.reshape(SHAPE)
        if np.any(packed):
            field=np.fft.ifftn(propagation*np.fft.fftn(initial,norm='ortho'),norm='ortho')
            restored=np.fft.ifftn(np.conj(propagation)*np.fft.fftn(field,norm='ortho'),norm='ortho').ravel()
        else:
            field=initial.copy();restored=packed.copy()
        held=((~selected)+np.sqrt(1-gate)*selected)*a
        recovered=np.zeros(N,dtype=complex)
        recovered[selected]=restored[:R]
        source_norm=float(np.vdot(a,a).real)
        output_norm=float(np.vdot(field,field).real)
        held_norm=float(np.vdot(held,held).real)
        rows.append(dict(case=name,gate=gate,source_norm=source_norm,output_norm=output_norm,
            held_norm=held_norm,conservation_error=abs(output_norm+held_norm-source_norm),
            inverse_operator_error=float(np.max(abs(restored-packed))),
            packing_reconstruction_error=float(np.max(abs(recovered-np.sqrt(gate)*selected*a))),
            dimension1_2_leakage=float(np.max(abs(recovered[~selected])))))

    pairing_ratios=[]
    for pairing in perfect_pairings(PRIMES):
        periods=[math.prod(b) for b in pairing]
        pairing_ratios.append(max(periods)/min(periods))
    checks=dict(
        source_capacity_covers_all_selected_addresses=SIZE>=R,
        one_previous_prime_61_would_not_cover_capacity=15015*61<R,
        old_paper_small_example_does_not_cover_current_capacity=30030<R,
        pairing_minimizes_anisotropy_in_fixed_six_prime_set=abs(max(SHAPE)/min(SHAPE)-min(pairing_ratios))<1e-12,
        CRT_steps_generate_simultaneous_update=all(c['combined_step']==1 for c in crt),
        paired_prime_operator_equals_axis_shift=max(paired_errors)==0,
        original_laplacian_equals_exact_spectrum=laplacian_error<1e-13,
        laplacian_is_positive_on_probe=rayleigh.real>=0 and abs(rayleigh.imag)<1e-12,
        frozen_heat_filter_recovers_1_2_3_on_declared_window=all(x['error_from_integer']<DIMENSION_TOLERANCE for x in dimension_rows),
        same_state_count_for_control_partitions=all(math.prod(s)==SIZE for s in shapes),
        fixed_finite_graph_has_no_IR_dimension3=heat_dimension(SHAPE,1e8)<1e-10,
        all_norms_preserved=all(r['conservation_error']<1e-12 for r in rows),
        original_operator_evolution_inverts=all(r['inverse_operator_error']<1e-13 for r in rows),
        packing_interface_is_isometric=all(r['packing_reconstruction_error']<1e-13 for r in rows),
        zero_and_nonzero_outlets_differ=rows[0]['output_norm']>0 and rows[1]['output_norm']==0,
        prime_and_prime_power_inputs_retained=rows[2]['output_norm']==0 and rows[3]['output_norm']==0,
        pure_mixed_input_outputs_completely=abs(rows[4]['output_norm']-1)<1e-12)
    checks={k:bool(v) for k,v in checks.items()}
    assert all(checks.values()),checks
    result=dict(study='Existing prime-partition operator to zeta outlet bridge v0.1',
        validation_inputs=dict(source_paper_library_id='libfile_b2f3c192a7e08191af9df221aab4da77',source_paper='Prime-Partition Generation of Macroscopic Dimension, v1.0, 2026-08-25, Sections3-12',address_count=N,selected_address_count=R,source_primes=PRIMES,source_blocks=BLOCKS,source_periods=SHAPE,source_capacity=SIZE,spectral_filter_scales=SCALES,spectral_filter_tolerance=DIMENSION_TOLERANCE,no_composition_model=True),
        WRRA_transformation=dict(prime_operator='T_p shifts the p-residue coordinate; represented by its CRT shift inside one block',axis_operator='U_alpha=product_(p in block_alpha) T_p',laplacian='L=sum_alpha(2I-U_alpha-U_alpha^*)',spectrum='lambda=4 sum_alpha sin^2(pi*k_alpha/N_alpha)',evolution='V=exp(-i L), evaluated by diagonalizing the original operator; FFT is a numerical algorithm, not an independently invented spatial kernel',packing='J maps selected natural-address coefficients in increasing order to the first R SOURCE positions; this is an explicit additional isometric interface',output='V J sqrt(gate) Pi3 psi',held='[(I-Pi3)+sqrt(1-gate)Pi3]psi',gate='abs(new analytic R3(s))<=1e-9'),
        outputs=dict(CRT_operator_steps=crt,paired_operator_errors=paired_errors,laplacian_spectral_error=laplacian_error,heat_dimensions=dimension_rows,renderer_cases=rows,unused_source_positions=SIZE-R,
            arithmetic_source_dimension_witness=dict(address=15,new_arithmetic_dimension=3,prime_resources=[3,5],
                one_block=dict(partition=[[3,5]],graph='C15',source_dimension=1),
                two_blocks=dict(partition=[[3],[5]],graph='C3 Cartesian C5',source_dimension=2),
                consequence='The arithmetic category3 is not automatically identical to source-axis count3. The connected implementation is a collective three-axis SOURCE with an explicit address interface.')),
        refutation_conditions=['The paired prime shifts fail to equal the declared simultaneous-update generator.','The frozen heat filter fails on the declared mesoscopic window.','The selected-address capacity exceeds SOURCE capacity without an explicit auxiliary channel.','The explicit packing loses norm or is claimed to preserve arithmetic adjacency without a proof.','The old three-block construction is claimed to force nature to choose three blocks, or to derive the new arithmetic d(n) rule.'],
        conclusions=dict(existing_three_axis_operator_confirmed=True,original_operator_executed=True,old_temporary_kernel_replaced_by_prime_source_operator=True,source_filter_and_outlet_connected_numerically=True,new_packing_contract_explicit=True,packing_preserves_arithmetic_relations_proven=False,arithmetic_dimension_equals_graph_dimension_by_theorem=False,three_block_choice_derived_from_zeta=False,observed_physical_space_derived=False),checks=checks)
    (ROOT/'results/prime_generator_bridge.json').write_text(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
    print(json.dumps(dict(checks_passed=sum(checks.values()),source_periods=SHAPE,source_capacity=SIZE,selected=R,heat_dimensions=dimension_rows,max_norm_error=max(x['conservation_error'] for x in rows),laplacian_spectral_error=laplacian_error),indent=2))


if __name__=='__main__':
    main()
