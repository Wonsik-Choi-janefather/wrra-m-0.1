WRRA 소수 관계와 양성 v0.4

DEDUCTIVE_PROOF_KO.txt: 전역 두 양성 조건과 RH의 동치, 조건부 연산자 구성, 정확 반례.
exact_check.py: 반례의 유리수 산술 검산.
prior_v0_3.zip: 이전 연구 원본 보존.

실제 xi의 전 차수 양성은 미증명. 새 수치 스캔이나 물리적 동일시, 출판 반영 없음.
