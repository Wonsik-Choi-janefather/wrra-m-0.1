"""Exact algebra audit only; not a numerical test or a proof of RH."""
from fractions import Fraction as F
from math import factorial
import json

moments = [F(1), F(2)]
for k in range(3):
    moments.append(F(42,5)*moments[-1]-F(54,5)*moments[-2])
b = [moments[k]/factorial(2*k) for k in range(5)]
c = []
for n in range(4):
    c.append((-1)**n*(n+1)*b[n+1]
             -sum((-1)**j*b[j]*c[n-j] for j in range(1,n+1)))
det0 = c[0]*c[2]-c[1]**2
det1 = c[1]*c[3]-c[2]**2
assert b == [F(1),F(1),F(1,4),F(1,25),F(123,28000)]
assert c == [F(1),F(1,2),F(37,100),F(234,875)]
assert det0 == F(3,25) and det1 == -F(223,70000)
print(json.dumps({'b':list(map(str,b)), 'c':list(map(str,c)),
                  'det_H0_1':str(det0),'det_H1_1':str(det1)},indent=2))
