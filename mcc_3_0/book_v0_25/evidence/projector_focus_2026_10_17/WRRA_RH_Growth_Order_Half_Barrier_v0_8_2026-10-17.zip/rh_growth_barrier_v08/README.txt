WRRA RH Growth Barrier v0.8

PROOF_AND_PROVENANCE_KO.txt: 강화 후보/증명/중복 비교/정확한 범위.
certify_double_exponential_counterkernel.py: 전 구간 오차 상계의 유리수 판정.
DOUBLE_EXPONENTIAL_CERTIFICATE.json: 실제 반례 함수의 정확한 음의 구간.
PROGRESS.json, EXECUTION_RECORD.json: 추가분과 미해결/실행 기록.
prior_audited_research.zip: 이전 중복 감사와 수학 연구 보존.

재현: python3 certify_double_exponential_counterkernel.py
표준 Python만 사용. 제타와 같은 차수1/2 및 exp(2u)형 이중지수 감소를 추가해도
일반 스칼라 부등식은 Hankel 양성을 보장하지 않는다. 실제 theta/RH 반례가 아니다.
