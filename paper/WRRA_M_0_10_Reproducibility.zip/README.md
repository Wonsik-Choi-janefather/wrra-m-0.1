# WRRA-M 0.10-r1 reproducibility package

Wonsik Choi · 2026-10-03 · CC BY 4.0

Address information load → physical energy and volume-derived pressure. The frozen calibration reproduces q=-0.52855, v=207.5109051266 km/s and conditional deflection=0.5355865106 arcsec.

[Input, scope and calculation guide](calculations/wrra_m_0_10/README.md) · [Evaluation and completion record](REVISION_0_10.md)

- [한국어 PDF](paper/WRRA_M_0_10_KO.pdf) · [DOCX](paper/WRRA_M_0_10_KO.docx)
- [English PDF](paper/WRRA_M_0_10_EN.pdf) · [DOCX](paper/WRRA_M_0_10_EN.docx)

```bash
python -m pip install -r calculations/wrra_m_0_10/requirements.txt
python calculations/wrra_m_0_10/run_release.py
```

The command regenerates numerical results, 32 checks and both manuscript sources. Published Word/PDF files are the checked final editions. SHA256SUMS verifies every included file; runtime versions and the clean-copy byte comparison are recorded under calculations/wrra_m_0_10/results.
