# WRRA_M 0.12-r1 reproducibility package

Wonsik Choi · 2026-10-03 · CC BY 4.0

Worldline proper-time updates and finite boundary spectra retain the frozen 0.11 calibration. The construction epsilon=0.05 is not a measured minimum time. The old slow expansion-state clock fails identification with the SI energy phase; that failure is preserved.

[Calculation guide](calculations/wrra_m_0_12/README.md) · [Completion record](REVISION_0_12.md)

- [한국어 PDF](paper/WRRA_M_0_12_KO.pdf) · [Word](paper/WRRA_M_0_12_KO.docx)
- [English PDF](paper/WRRA_M_0_12_EN.pdf) · [Word](paper/WRRA_M_0_12_EN.docx)

```bash
python -m pip install -r calculations/wrra_m_0_12/requirements.txt
python calculations/wrra_m_0_12/run_release.py
```

This regenerates numerical outputs, 36 new checks, 60 inherited checks and bilingual sources. Published Word/PDF editions are checked final artifacts. All captured result directories were removed before the byte comparison recorded in results/reproduction_checks.json. SHA256SUMS verifies archive contents. package_release.py is a publication-maintenance script, rather than the ordinary numerical reproduction command.
