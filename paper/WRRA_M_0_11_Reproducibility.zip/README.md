# WRRA_M 0.11-r1 reproducibility package

Wonsik Choi · 2026-10-03 · CC BY 4.0

The ordered G → H0 → f_phi → f_c → electron-energy calibration retains the frozen 0.10 physics, identifies mu_E=22217.345682173913 eV under electron mode 23, and reports residual freedoms.

[Input and calculation guide](calculations/wrra_m_0_11/README.md) · [Completion record](REVISION_0_11.md)

- [한국어 PDF](paper/WRRA_M_0_11_KO.pdf) · [Word](paper/WRRA_M_0_11_KO.docx)
- [English PDF](paper/WRRA_M_0_11_EN.pdf) · [Word](paper/WRRA_M_0_11_EN.docx)

```bash
python -m pip install -r calculations/wrra_m_0_11/requirements.txt
python calculations/wrra_m_0_11/run_release.py
```

This regenerates numerical outputs, 28 new checks, 32 inherited checks and both manuscript sources. Published Word/PDF editions are checked final artifacts. All captured results were removed for the clean-copy comparison recorded in results/reproduction_checks.json. SHA256SUMS verifies archive contents. Run package_release.py in the publication repository after document QA to rebuild the archive; it is a release-maintenance script rather than the ordinary numerical reproduction command.
