# WRRA-M 0.6 정보부하와 뒤틀림 중력 및 팽창

최원식 Wonsik Choi · 2026-10-01 · CC BY 4.0

0.6은 유한·동질 구성 모형을 완료했다. 상태별 정보부하를 실제 계산하고, 같은 에너지 함수와 고전 배경 작용으로 상태 진화·압력·팽창·뒤틀림을 연결한다. 국소 회전·렌즈에는 그중 모이는 부하를 기존 보정 응답에 전달한다. WRRA Core 1.0과 MCC 2.3.2를 기준으로 유지한다.

| 단계 | 실행 내용 |
| --- | --- |
| 검증 입력 | 전체를 분모로 한 표현형 4.93%, 숨은 부하 95.07%, 모이는 부문 26.5%, 잔여 배경 68.57%; 기존 응답과 16채널 전달자 |
| WRRA 고유 변환 | 양의 부하 연산자의 상태 trace, 단일 에너지 함수, 부피 미분 압력, unitary 상태 갱신 및 동질 고전 작용 |
| 산출값 | 현재 q=-0.52855; 기존 aT=1.191812669e-10 m/s² 및 회전·렌즈 재현; 비가환 상태의 부하 변화와 상쇄되는 교환 |
| 반증조건 | trace·양의성 실패, 압력 미분 불일치, 총 보존 실패, 별도 가속도 해의 제약 위반, 같은 응답의 운동·렌즈 불일치 |

모이는 에너지 지수 nc=0, 배경 지수 nb=3, 부하 연산자와 정보 시계는 공개한 구성 선택이다. 압력과 보존은 그 선택에서 계산한 결과다. 실제 우주의 유일한 미시 법칙, 절대 우주 길이, 완전한 4차원 공변 국소 이론이나 공간 섭동의 안정성을 확정한 것은 아니다. 대칭 전달자 선택 격차는 0이다. 질량 표현형의 양자화와 근본 중력의 비양자 전제를 구분한다.

## 재현

```bash
python -m pip install -r requirements.txt
python compute.py
python verify.py
```

compute.py는 parameters.json 및 baseline_0_5/parameters.json을 읽어 results/results.json과 요약·그림을 생성한다. verify.py는 0.5의 기록값, 기저 변환 및 경계 입력을 검사한다. 출력은 기본적으로 이 스크립트와 같은 디렉터리의 results에 저장된다. 다른 경로는 --out으로 지정할 수 있다. 원고 표를 다시 만들려면 기본 경로의 계산과 검사를 완료한 뒤 다음을 실행한다.

```bash
python write_papers.py
python build_reports.py
```

문서 생성에는 pandoc와 python-docx가 추가로 필요하다. 한글 출력은 Noto Sans CJK KR, 영문은 Liberation Serif/Sans 글꼴을 사용한다. Word 수식은 편집 가능한 네이티브 수식 22개이며, 두 언어는 동일한 수식·표 수치를 사용한다. PDF는 LibreOffice로 DOCX에서 변환했다.

전체 재현 ZIP에는 두 언어의 PDF·DOCX, 전체 궤도 results.json, 요약, 경계 검사, 그림, 원고와 코드가 포함된다. GitHub 계산 폴더에는 큰 전체 궤도를 제외한 요약·검사·그림을 제공하며 전체 궤도는 ZIP 또는 코드 실행으로 얻는다. baseline_0_5/results.json은 비교를 위해 고정한 수정된 0.5 기록이다.

정보 상태의 순수성·고윳값 보존은 unitary 구성의 결과다. 실험값과 맞는지에 대한 판단과 모형 내부 정합성 검사는 구분한다. 0.6 착수 모형의 고정 커널 제한은 기하 의존 에너지 연산자로 대체했으며 착수 기록은 별도 디렉터리에 보존한다.

## 0.6-r2 shared grid and record magnitude

`parameters.json:lattice_N` controls both information-state loads and transport tests. `baseline_0_5/parameters.json:internal_lattice_N` is retained as provenance; the carrier receives a private copy with the 0.6 grid. `lattice_contract` reports configured and effective sizes. `verify.py` checks the 64/128 and 128/64 combinations and unchanged uniform reference outputs. Nonuniform state loads may depend on lattice size.

“Global twist record magnitude” is an instantaneous aggregate from load density and spatial size at the current state and scale. No independent temporal accumulation law is computed. Reference q₀, rotation and conditional lensing remain unchanged. See [the revision record](../../REVISION_0_6_R2.md).

정보부하와 수송 전달자 검사의 격자 크기는 0.6의 lattice_N으로 통일한다. 기존 입력과 실제 적용값을 결과에 함께 표시하며, 교차 입력 검증을 추가했다. 전역 뒤틀림 기록의 크기는 그 순간의 부하 밀도와 공간 크기로 계산한 집계값이다. 시간 누적 법칙을 따로 계산하지 않는다.
