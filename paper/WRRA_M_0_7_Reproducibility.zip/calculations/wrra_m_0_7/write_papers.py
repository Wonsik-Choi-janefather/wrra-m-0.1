"""Matched KO/EN manuscripts generated from the executed 0.7 result ledger."""
from pathlib import Path
import json

ROOT = Path(__file__).resolve().parent
R = json.loads((ROOT/'results/results.json').read_text())
V = json.loads((ROOT/'results/verification.json').read_text())
EQ = {
1:r'\mathscr A=(a,\rho,\Theta,\mathcal R),\qquad \rho\succeq0,\quad\mathrm{Tr}\rho=1.',
2:r'K_c=2I-T-T^\dagger,\qquad K_b=\frac{K_c+\epsilon|0\rangle\langle0|}{1+\epsilon/(2N)}.',
3:r'A_\phi=f_\phi I,\quad A_c=\frac{f_c}{2}a^{n_c}K_c,\quad A_b=\frac{f_b}{2}a^{n_b}K_b.',
4:r'\mu_a(S)=\sum_{s\in S}\mathrm{Tr}(\rho A_s),\qquad W=\mu_a(\{\phi,c,b\}).',
5:r'F_\phi=\frac{\mathrm{Tr}(\rho A_\phi)}{W},\quad F_h=\frac{\mathrm{Tr}(\rho(A_c+A_b))}{W},\quad F_\phi+F_h=1.',
6:r'a=1,\quad\rho=I/N:\quad(F_\phi,F_c,F_b)=(0.0493,0.265,0.6857).',
7:r'\rho=I/N:\quad F_\phi(a)=\frac{f_\phi}{f_\phi+f_c+f_ba^3},\qquad n_c=0,\quad n_b=3.',
8:r'E_s=u_{\mathrm{crit},0}V_0\mathrm{Tr}(\rho A_s),\quad u_s=\frac{E_s}{V_0a^3},\quad p_s=-\frac{n_s}{3}u_s.',
9:r'H^2=\frac{8\pi G}{3c^2}u_{\mathrm{tot}},\qquad q=\frac{u_{\mathrm{tot}}+3p_{\mathrm{tot}}}{2u_{\mathrm{tot}}}.',
10:r'A=A_\phi+A_c+A_b,\quad\rho^{\prime}=U\rho U^\dagger,\quad U=e^{-i\tau A},\quad\mathrm{Tr}(\rho^{\prime}A)=\mathrm{Tr}(\rho A).',
11:r'E_{\mathrm{before}}+E_{\mathrm{environment,before}}=E_{\mathrm{after}}+E_{\mathrm{environment,after}}.'
}


def equation(n):
    return '\n\n$$'+EQ[n]+r'\tag{'+str(n)+'}$$\n\n'


def table(headers, rows):
    return '\n\n|'+'|'.join(headers)+'|\n|'+'|'.join(['---']*len(headers))+'|\n'+''.join('|'+ '|'.join(map(str,row))+'|\n' for row in rows)+'\n'


def case_table(lang):
    labels_ko=['균등 a 0.5','균등 a 1','균등 a 2','낮은 모드','높은 모드','영 모드','중첩 상태','균등 비가환','중첩 비가환']
    labels_en=['Uniform a 0.5','Uniform a 1','Uniform a 2','Low mode','High mode','Zero mode','Coherent packet','Uniform noncommuting','Packet noncommuting']
    labels=labels_ko if lang=='KO' else labels_en
    return table(['상태' if lang=='KO' else 'State','Jc','Jb','표현형 %' if lang=='KO' else 'Phenotype %','비표현형 %' if lang=='KO' else 'Hidden %'],
        [[name,f"{x['Jc']:.6f}",f"{x['Jb']:.6f}",f"{100*x['sector_shares']['phenotype']:.6f}",f"{100*x['hidden_share']:.6f}"] for name,x in zip(labels,R['cases'])])


def check_table(lang):
    names_ko=['세 공간 크기의 정확 분수 대조','양의 가중치와 합계','0.6 에너지와 압력 대조','기존 회전과 렌즈 재현','별도 부피 미분과 압력','상태와 연산자의 기저 변환','상태 스펙트럼과 에너지 보존','혼합 상태와 지수 변경','공개 보정값 변경의 전달','회계 부피 변경의 불변량','정보 가중치와 엔트로피 구분','영 부하의 비율 미정 처리','배경 부하 0 경계','잘못된 입력과 상태 차단','기록의 중복 부하 방지','공통 입력 장부 보존']
    rows=[]
    for i,x in enumerate(V['checks']):
        rows.append([i+1,names_ko[i] if lang=='KO' else x['name'].replace('_',' '),'통과' if lang=='KO' else 'Pass'])
    return table(['번호' if lang=='KO' else 'No','검사' if lang=='KO' else 'Check','결과' if lang=='KO' else 'Result'],rows)


ko='''# WRRA M 0 7 Actual과 표현형의 에너지 가중 정보 장부

우리 우주 모형의 공통 정의와 부하 측도 및 재현 가능한 계산

최원식 Wonsik Choi  
WRRA-M 0.7 | 2026년 10월 1일  
Independent Researcher Seoul Republic of Korea  
ORCID 0009-0001-4263-9772 | janefather@gmail.com

## 판정 순서와 연구 결과

검증 입력은 WRRA Core 1.0과 MCC 2.3.2를 이어받은 0.6-r2의 공개 코드와 보정 장부다. 광속은 SI 정의값으로 고정하고, 후기 우주 구성비와 국소 시험원의 조건은 갱신 가능한 입력으로 유지한다. WRRA 고유 변환은 양의 상태 부하를 세 부문으로 합산하고, 그 전체를 Actual의 에너지 가중 정보부하로 정규화하여 표현형과 비표현형 비율을 계산하는 것이다. 같은 부하를 기존 에너지 함수와 압력 및 중력·팽창 계산에 전달한다.

산출값은 기준 상태의 표현형 4.93%와 비표현형 95.07%, 상태·공간 크기 변경에 따른 비율, 그리고 기존 회전·렌즈·팽창 산출값의 재현이다. 반증조건은 허용 상태에서 음의 부하가 생기는 경우, 분해 합계가 맞지 않는 경우, 같은 입력의 0.6 에너지·압력과 어긋나는 경우, 또는 실행되지 않은 전환을 완료했다고 주장하는 경우다.

0.7은 Actual·양자화·표현형을 잇는 공통 정의와 측도를 확정하고 장부를 실제 계산한다. 이 판에서 닫힌 것은 가중 측도와 기존 부하 계산의 연결이다. 물리적 양자화 사건과 입자 필터 선택은 다음 판에서 실행한다. 알려진 값의 보정을 정당한 모형 구성으로 인정하며, 독립예측을 완료 조건으로 요구하지 않는다.

## Actual과 양자화 및 표현형의 정의

Actual은 현재 모형이 보유하는 상태·공간 크기·구성 입력·기록의 전체다. 100%는 이 전체의 채택한 가중 부하를 분모로 정규화한 값이다. 무한한 비트 목록이나 우주의 모든 미시 상태를 이미 관측했다는 뜻으로 사용하지 않는다. Θ는 상수·보정·연산자·시험원 조건의 공통 입력 장부이며, R은 물리적 결과 기록이다. 0.7에서 물리적 결과 기록은 빈 목록으로 유지한다.
'''+equation(1)+'''
양자화는 Actual 상태가 이산적인 표현형 결과와 관측 뒤 상태 및 물리적 기록으로 전환되는 연산 과정으로 정의한다. 0.7은 그 연산의 입출력과 부하 장부를 준비한다. 0/1 경계 선택, 발생확률, 관측 뒤 상태갱신을 아직 실행하지 않았으므로 결과 파일에 quantization_status를 미실행으로 명시한다.

표현형은 채택한 우리 우주 가지에서 현재 확정되어 표현된 부문의 부하다. 비표현형은 그 밖에 남아 있는 모이는 부하와 배경 부하다. 비표현형도 Actual에 포함되고 중력·팽창 장부에 기여한다. 비표현형의 존재를 관측 여부에 따라 0으로 처리하지 않는다. 잔여는 표현되지 않은 상태 내용의 보존을 가리키며, 이를 별도의 네 번째 에너지 성분으로 더하지 않는다.

물리적 기록은 전환 결과를 보유한 계의 상태다. 입력 출처와 코드 실행 로그는 재현 기록이며 물리적 관측 기록과 구분한다. 이후 기록계의 에너지는 기존 부문 안의 하위 배정으로 계산한다. 같은 에너지를 기록 비용이라는 이름으로 다시 더하지 않는다.

## 공통운반자와 양의 부하 연산자

0.6의 16개 시험 채널과 N개 내부 격자를 유지한다. N=128은 공간 부하를 계산하는 격자 크기이고, 입자 채널의 수가 아니다. 채널 공통 상태 I16/16과 내부 상태 ρ의 곱 구조를 이어받는다. 0.7은 이 구조에서 내부 부하를 계산하며 채널별 입자 배치나 필터 선택을 새로 확정하지 않는다.
'''+equation(2)+'''
균등 상태에서는 Jc=Tr(ρKc)=2이고 Jb=Tr(ρKb)=2다. ε=0은 기준 운반자, ε=8은 0.6에서 사용한 비가환 시험 입력이다. 이는 실제 우주의 ε를 측정한 값이 아니다. 부문별 가중 연산자를 다음처럼 둔다. 배경 비율 fb는 1−fφ−fc로 계산하며 세 비율을 서로 독립적으로 다시 입력하지 않는다.
'''+equation(3)+'''
fφ=0.0493, fc=0.265, fb=0.6857, nc=0, nb=3을 기준으로 채택한다. Aφ=fφI는 0.6의 압력 없는 표현형 공변 에너지를 유지하는 구성이다. 이 항 자체가 미시적 관측 사건을 생성하지는 않는다. 세 부문은 가중 부하의 장부 항목이며 직교하는 측정 결과 투영자라고 해석하지 않는다.

## 약 5퍼센트를 계산하는 측도

가중 정보부하 측도는 부문 집합 S에 대해 상태와 양의 연산자의 trace를 합산하여 정의한다. 허용된 상태와 연산자에서는 각 가중치가 음수가 아니며, 서로 겹치지 않는 부문 라벨 집합의 합에 대해 가법성이 성립한다.
'''+equation(4)+'''
여기서 정보의 무게는 에너지 응답을 만드는 상태별 기대 부하다. Shannon 정보량, von Neumann 엔트로피, 정보 비트 수 또는 채널 수와 동일한 측도가 아니다. 상태의 trace가 모두 1이어도 부하가 다를 수 있다. 상태 엔트로피는 별도의 진단값으로 결과 장부에 함께 기록한다.
'''+equation(5)+'''
Fφ와 Fh는 현재 상태의 전체 가중 부하에서 각 부문이 차지하는 몫이다. 개별 측정의 0 또는 1 발생확률이 아니다. W=0이면 정규화된 몫을 정의할 수 없으므로 JSON null을 기록한다. trace가 1인 상태라도 가중 연산자의 영 공간에 놓이면 이 경우가 생길 수 있다.
'''+equation(6)+'''
후기 우주의 약 5%를 표현형 부하에 대응시키는 것은 공개한 WRRA 구성 선택이다. 기존의 에너지 가중 보정과 정보부하 측도를 같은 장부에 대응시켜 현재 기준에서 4.93%를 재현한다. 이 대응을 정보 비트 수의 직접 측정 결과로 바꾸어 부르지 않는다. 상수·관측값의 반영을 통해 우리 우주 가지를 정하는 방법을 유지한다.

## 상태와 공간 크기가 바뀔 때의 비율

4.93%는 a=1인 균등 기준 상태의 보정 재현값이다. 같은 구성에서도 상태나 공간 크기가 달라지면 실제 비율을 다시 계산한다. 균등 상태에서 모이는 에너지 지수 0과 배경 지수 3을 유지하면 다음 식을 얻는다.
'''+equation(7)+case_table('KO')+'''
표의 낮은 모드·높은 모드·영 모드·중첩 상태는 계산 구조를 검사하는 시험 상태다. 해당 비율을 현재 우주의 새 관측값으로 제시하지 않는다. 같은 순수 상태 엔트로피 0인 낮은 모드와 높은 모드가 서로 다른 표현형 가중비를 주므로, 채택한 측도가 엔트로피나 상태의 수와 다른 것을 확인할 수 있다.

균등 기준의 a=0.5에서는 표현형 비율이 약 12.324615%, a=2에서는 약 0.850015%다. 이 값은 고정된 부피 의존성과 부문 배정에서 계산된 조건부 산출값이다. 미래 우주의 관측 예측으로 사용하는 경우에는 모형과 보정 규칙을 확정한 뒤 그 조건을 함께 제시한다.

## 같은 에너지 장부에서 압력과 중력 및 팽창 계산

V0는 대표 공변 부피이며 기본값 1 m³는 회계 단위다. 실제 우주의 크기로 해석하지 않는다. 기준 에너지 밀도는 ucrit,0=3H0²c²/(8πG)다. 가중 부하를 물리 에너지로 대응시키면 0.6의 세 부문 에너지와 정확히 같은 값을 얻는다. 표현형의 지수는 nφ=0이다.
'''+equation(8)+equation(9)+'''
현재 균등 기준에서 H/H0=1과 q=−0.52855를 재현한다. 같은 모이는 부하를 기존 국소 응답에 넣으면 시험 회전속도 207.510905 km/s와 조건부 렌즈 편향 0.535586511각초를 유지한다. 국소 시험원과 Φ=Ψ 조건을 유지한 재현이며, 실제 은하 관측자료를 새로 적합한 결과는 아니다.

뒤틀림 기록의 크기는 현재 부하와 공간 크기에서 계산하는 집계값으로 유지한다. 이 판에서도 별도의 시간 누적 법칙을 도입하지 않는다. 같은 부하에서 뒤틀림과 팽창이 계산된다는 연결과 뒤틀림이 팽창을 일으킨다는 인과 주장도 구분한다. 압력·팽창 방정식은 0.6에서 실행한 외부 수학을 사용하며, WRRA의 구성 성과는 상태 부하와 표현형 장부를 그 계산에 실제 연결한 데 있다.

## 검증 결과와 실패 조건

16개 검증 묶음을 통과했다. 대표 장부 9개 외에 혼합 상태·격자·지수 변경의 24개 경우를 실행했다. 잘못된 보정값·상태와 실행되지 않은 기록을 입력하는 9개 경우는 차단했다. 유리수로 계산한 균등 기준 비율, 별도 부피 유한차분, 기저 동시 변환과 고정 크기의 unitary 상태 변화를 사용해 장부를 대조했다.
'''+equation(10)+'''
식 10은 고정된 공간 크기의 에너지 보존 검사다. unitary 상태 변화에서 개별 부하 항목은 달라질 수 있지만 같은 총 연산자의 에너지는 보존된다. 실제 양자화 사건의 에너지 교환 검사를 통과했다는 뜻으로 확장하지 않는다.
'''+check_table('KO')+'''
균등 기준 비율의 최대 절대 오차는 2.776×10⁻¹⁷, 부문 가중치 합계의 최대 오차는 2.665×10⁻¹⁵다. 별도 부피 미분과 압력의 최대 상대 오차는 4.840×10⁻¹¹이다. 고정 크기 unitary 변화의 총 에너지 상대 오차는 2.220×10⁻¹⁶이며, 기존 회전·렌즈 재현 오차는 출력 정밀도에서 0이다. 이는 선언된 모형의 계산 정합성과 재현 성과다.

허용 상태에서 음의 부하가 나오거나, 부문 가중치와 전체의 합이 어긋나거나, 상태 trace·양성이 깨지거나, 같은 부피 에너지의 미분과 압력이 어긋나면 대응하는 계산을 수정해야 한다. 보정 규칙을 명시하지 않고 입력을 바꾸는 것과 미실행 측정 규칙을 완료로 표시하는 것도 이 판의 실패 조건이다.

## 다음 단계에 전달하는 장부

parameters.json이 상수·구성비·격자·지수·시험원·회계 부피의 유일한 실행 입력이다. 결과는 이 파일의 정규 JSON 표현에 대한 SHA256을 포함한다. 입력을 변경하면 결과와 해시가 함께 바뀌며, 실행 중 입력이 변형되면 실패한다. results.json은 각 부문의 가중치·에너지·밀도·압력과 0.6 연결 출력, 상태 생성법, 측정 미실행 상태를 보유한다.

0.8은 이 장부에 입자와 필터 선택 결과를 연결한다. 0.9는 실제 양자화 결과·발생확률·관측 뒤 상태·물리적 기록을 생성한다. 0.10은 반복 전환의 분기와 불확실성을 계산한다. 0.11은 그 전환과 기록계의 부하 교환을 물리 계산에 연결한다. 다음 식은 그때 사용할 회계 조건이며 0.7에서 실행한 측정 법칙이 아니다.
'''+equation(11)+'''
0.12는 전체 실행·문서·주장 장부를 대조한 뒤 1.0으로 확정한다. 0.7의 완료 판정은 공통 정의와 에너지 가중 측도 및 기존 부하 계산의 연결에 한정한다. 입자 선택·관측 법칙·전체 이론의 통합을 완료했다고 선행 판정하지 않는다. 같은 기준으로 기존 이론의 검증 입력과 WRRA 내부 실행을 구분한다.

## 재현 방법과 참고 자료

압축파일의 루트에서 python calculations/wrra_m_0_7/run_release.py를 실행하면 대표 결과표와 verification.json을 생성한다. 필요한 계산 라이브러리는 numpy와 scipy다. 원고 작성에는 pandoc와 python-docx, PDF 변환에는 LibreOffice가 별도로 필요하다. 고정 입력과 상태 생성법을 공개하므로 재현 과정에서 무작위로 보정값을 선택하지 않는다. 추가 혼합 상태 시험은 seed 707을 사용한다.

Choi Wonsik. WRRA-M 0.6-r2. 2026. https://doi.org/10.5281/zenodo.23076547

WRRA-M repository. https://github.com/Wonsik-Choi-janefather/wrra-m-0.1

Planck Collaboration. Planck 2018 results VI Cosmological parameters. Astronomy and Astrophysics 641 A6 2020. https://doi.org/10.1051/0004-6361/201833910 . 후기 우주 보정의 비교 자료이며, 0.7에서 새로 원자료를 적합한 것은 아니다. 4.93%와 26.5%의 정확한 실행값은 0.6-r2 입력에서 이어받은 반올림 보정값이다.

BIPM. The International System of Units SI defining constants. https://www.bipm.org/en/measurement-units/si-defining-constants . 광속 299792458 m/s는 고정 정의값으로 입력하며 WRRA 예측으로 분류하지 않는다.

Copyright 2026 Wonsik Choi. CC BY 4.0. https://creativecommons.org/licenses/by/4.0/
'''

en='''# WRRA M 0 7 Actual and Phenotype in an Energy Weighted Information Ledger

Common definitions and a reproducible load measure for our universe model

Wonsik Choi  
WRRA-M 0.7 | October 1 2026  
Independent Researcher Seoul Republic of Korea  
ORCID 0009-0001-4263-9772 | janefather@gmail.com

## Evaluation order and result

Verification inputs are the public 0.6-r2 code and calibration ledger continuing WRRA Core 1.0 and MCC 2.3.2. The speed of light is fixed by the SI definition; late-universe fractions and local test-source conditions remain editable inputs. The WRRA-specific transformation adds positive state loads in three sectors, normalizes their total as the energy-weighted information load of Actual, and computes phenotype and hidden shares. The same loads enter the existing energy, pressure, gravity and expansion calculation.

Outputs reproduce the reference phenotype share of 4.93 percent and hidden share of 95.07 percent, recalculate shares for changed states and scale, and retain the inherited rotation, lensing and expansion outputs. Falsification conditions include a negative admissible load, a failed partition, disagreement with the same-input 0.6 energy or pressure, or claiming an unexecuted transition as complete.

Version 0.7 establishes the common definitions, measure and computed ledger. Its completed connection is weighted accounting to the inherited load calculation. Physical quantization events and particle-filter selection are executed in subsequent releases. Calibration with established values is legitimate model construction; independent prediction is not required for this completion.

## Definitions of Actual quantization and phenotype

Actual is the complete current state, scale, constitutive inputs and records represented by this model. One hundred percent means normalization by the adopted total weighted load. It does not assert an infinite bit inventory or that every microscopic state of the universe has already been observed. Theta denotes the common input ledger of constants, calibrations, operators and test-source conditions; R denotes physical outcome records. The physical record list is empty in 0.7.
'''+equation(1)+'''
Quantization is defined as an operation taking the Actual state to a discrete phenotype outcome, a post-observation state and a physical record. This release prepares its input and output accounting. It does not yet execute boundary selection of 0 or 1, outcome probabilities or a measurement state update. The result explicitly reports quantization_status as unexecuted.

Phenotype is the load allocated to the currently expressed sector in the adopted our-universe branch. Hidden load comprises clustering and background sectors. Both belong to Actual and contribute to gravity and expansion. Lack of expression does not set their loads to zero. Residue denotes retained unexpressed state content and is not added as an independent fourth energy component.

A physical record is a system state retaining a transition outcome. Input provenance and execution logs are reproducibility records, distinguished from physical observation records. Future record-system energy is a suballocation within existing sectors. It must not be counted again under a separate record-cost label.

## Common carrier and positive load operators

The sixteen test channels and N internal lattice sites of 0.6 are retained. N=128 is a load-computation grid size, not a particle-channel count. The inherited product state uses the common channel state I16/16 and internal state rho. This release evaluates internal loads and does not newly select particle assignments or filters.
'''+equation(2)+'''
For the uniform state, Jc=Tr(rho Kc)=2 and Jb=Tr(rho Kb)=2. Epsilon zero is the reference carrier; epsilon eight is the inherited noncommuting test choice, not a measurement of the actual universe. Sector weighting operators are defined below. The background fraction is computed as 1 minus the phenotype and clustering fractions rather than entered independently.
'''+equation(3)+'''
The reference adopts fphi=0.0493, fc=0.265, fb=0.6857, nc=0 and nb=3. Aphi=fphi I retains the pressureless phenotype comoving energy of 0.6. This term does not itself generate a microscopic observation event. The sectors are weighted accounting terms and are not orthogonal outcome projectors.

## The measure underlying approximately five percent

For a set of sector labels S, the information-load measure sums state traces against positive weighting operators. Admissible states and operators give nonnegative weights and additivity for disjoint sets of sector labels.
'''+equation(4)+'''
Information weight means the state-dependent expected load entering the energy response. It is distinct from Shannon information, von Neumann entropy, a bit count or a channel count. Trace-one states can carry different loads. State entropy is reported separately as a diagnostic.
'''+equation(5)+'''
Fphi and Fh are shares of the total weighted load at the current state and scale. They are not probabilities of a zero or one measurement outcome. If W is zero, normalized shares are undefined and represented by JSON null. A trace-one carrier state can lie in the common null space of its load operators.
'''+equation(6)+'''
Mapping the approximately five percent late-universe reference to the phenotype sector is a disclosed WRRA constitutive choice. It connects the inherited energy-weighted calibration and the information-load measure in one ledger, reproducing 4.93 percent at the reference. This is not relabeled as a direct count of information bits. Established constants and observations remain valid calibration material for the selected our-universe branch.

## Shares under state and scale changes

The 4.93 percent value is a calibrated reference at a=1 in the uniform state. Even with the same constitution, a changed state or scale requires recalculation. Retaining clustering exponent zero and background exponent three gives the following uniform-state formula.
'''+equation(7)+case_table('EN')+'''
Low-mode, high-mode, zero-mode and packet rows are structural test states, not new observed cosmic fractions. Low and high pure modes both have zero state entropy but different phenotype shares. This distinguishes the adopted weighted measure from entropy or the number of states.

The uniform phenotype share is approximately 12.324615 percent at a=0.5 and 0.850015 percent at a=2. These are conditional outputs of the fixed volume dependence and sector allocation. If used as future-universe predictions, the frozen model and calibration conditions must accompany them.

## Energy pressure gravity and expansion from the same ledger

V0 is a representative comoving volume; its default of one cubic metre is a bookkeeping unit, not the size of the universe. The reference energy density is ucrit,0=3H0 squared c squared divided by 8 pi G. Mapping weighted loads to physical energy reproduces exactly the three sector energies of 0.6. The phenotype exponent is zero.
'''+equation(8)+equation(9)+'''
The present uniform reference reproduces H/H0=1 and q=-0.52855. Sending the same clustering load into the inherited local response retains test rotation 207.510905 km/s and conditional deflection 0.535586511 arcsec. The local test source and Phi=Psi condition are unchanged; no new observational galaxy fit is performed.

Global twist record magnitude remains an instantaneous aggregate of load and spatial size. No independent temporal accumulation law is added. Calculation of twist and expansion from the same load is distinguished from a claim that twist causes expansion. The pressure and expansion equations use external mathematics already executed in 0.6; the WRRA contribution here is the actual connection of state loads and phenotype accounting to those calculations.

## Verification and failure conditions

Sixteen check groups pass. In addition to nine representative ledgers, twenty-four mixed-state, grid and exponent combinations are evaluated. Nine invalid input or state cases, including a fictitious physical record, are rejected. Independent comparisons use rational reference fractions, finite volume differences, simultaneous basis changes and fixed-scale unitary propagation.
'''+equation(10)+'''
Equation ten tests energy conservation at fixed scale. Individual sector loads may change under unitary evolution while the energy of the same total operator is preserved. This is not expanded into a completed test of energy exchange during a physical quantization event.
'''+check_table('EN')+'''
The maximum reference-share error is 2.776 times 10 to the minus 17; the maximum sector-weight partition error is 2.665 times 10 to the minus 15. The independent pressure difference has maximum relative error 4.840 times 10 to the minus 11. The fixed-scale unitary total-energy relative error is 2.220 times 10 to the minus 16. Inherited rotation and lensing have zero discrepancy at output precision. These establish computation consistency and reproduction within the declared model.

A negative admissible load, inconsistent sector sum, loss of state positivity or trace, or mismatch between pressure and the same energy-volume derivative requires revision of the corresponding calculation. Undisclosed recalibration and reporting an unexecuted measurement law as complete are also failure conditions.

## Ledger passed to subsequent releases

Parameters.json is the sole executable input for constants, fractions, grid, exponents, test source and bookkeeping volume. Outputs include a SHA256 hash of its canonical JSON representation. Changing the input changes the result and hash; mutation during execution fails. Results.json retains sector weights, energy, density, pressure, the 0.6 bridge outputs, state recipes and the unexecuted measurement status.

Version 0.8 attaches particle and filter selection to this ledger. Version 0.9 generates physical quantization outcomes, probabilities, post-observation states and records. Version 0.10 computes repeated-event branching and uncertainty. Version 0.11 connects event and record-system energy exchanges to physical loads. The next equation is a future accounting contract, not an executed measurement law in 0.7.
'''+equation(11)+'''
Version 0.12 compares the integrated run, documents and claim ledger before freezing 1.0. Completion of 0.7 covers common definitions, the energy-weighted measure and the inherited load bridge. It does not pre-emptively certify particle selection, measurement dynamics or full theoretical integration. The same evidentiary standard distinguishes external validation inputs and actual WRRA execution.

## Reproduction and references

From the archive root, run python calculations/wrra_m_0_7/run_release.py to produce the case table and verification.json. Computation requires numpy and scipy. Document authoring additionally requires pandoc and python-docx; PDF rendering requires LibreOffice. Inputs and state recipes are fixed. The additional mixed-state tests use seed 707.

Choi Wonsik. WRRA-M 0.6-r2. 2026. https://doi.org/10.5281/zenodo.23076547

WRRA-M repository. https://github.com/Wonsik-Choi-janefather/wrra-m-0.1

Planck Collaboration. Planck 2018 results VI Cosmological parameters. Astronomy and Astrophysics 641 A6 2020. https://doi.org/10.1051/0004-6361/201833910 . This is calibration context; no new raw-data fit is performed in 0.7. The exact executable values 4.93 percent and 26.5 percent are rounded calibrations inherited from the 0.6-r2 ledger.

BIPM. The International System of Units SI defining constants. https://www.bipm.org/en/measurement-units/si-defining-constants . The speed of light 299792458 m/s is a fixed defining input, not a WRRA prediction.

Copyright 2026 Wonsik Choi. CC BY 4.0. https://creativecommons.org/licenses/by/4.0/
'''

for lang, source in [('KO',ko),('EN',en)]:
    (ROOT/f'source_{lang.lower()}.md').write_text(source)
print('Wrote matched KO/EN sources with 11 equations and executed result tables')
