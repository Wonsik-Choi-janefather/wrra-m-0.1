"""Numerical checks of r10 propositions; not tests of observational agreement."""
from pathlib import Path
import json
import numpy as np
from scipy.special import expit
from scipy.optimize import brentq
checks=[]
def check(name,condition):
 checks.append({'name':name,'passed':bool(condition)})
def close(a,b,tol=1e-10):return np.allclose(a,b,atol=tol,rtol=tol)
def sqrtpsd(x):
 v,u=np.linalg.eigh(x);return (u*np.sqrt(np.maximum(v,0)))@u.conj().T
I=np.eye(3); A=np.diag([.9,.6,.3]); Q=np.array([[1,1,0],[-1,1,0],[0,0,np.sqrt(2)]])/np.sqrt(2)
B=Q@np.diag([.8,.4,.2])@Q.T
rho=np.array([[.5,.1,0],[.1,.3,.04],[0,.04,.2]])
M=[sqrtpsd(I-A.T@A), B@A, sqrtpsd(I-B.T@B)@A]
out=[m@rho@m.T for m in M];prob=np.array([np.trace(x) for x in out])
check('general noncommuting contractions complete',close(sum(m.T@m for m in M),I))
check('all output states positive',all(np.linalg.eigvalsh(x).min()>-1e-12 for x in out))
check('probabilities sum to one',close(prob.sum(),1))
check('residual trace agrees with effect',close(prob[2],np.trace(rho@A.T@(I-B.T@B)@A)))
check('conditional residual normalized',close(np.trace(out[2]/prob[2]),1))
check('general contraction residual need not lie in kernel',close(np.trace(.75*rho),.75) and np.linalg.matrix_rank(.5*I)==3)
P=np.diag([1.,0,0]);C=I-P; rr=C@A@rho@A@C;rr/=np.trace(rr)
check('projector residual lies in return kernel',close(P@rr@P,0))
U=np.array([[1,0,0],[0,0,-1],[0,1,0.]])
check('invariant unitary preserves zero return',close(P@U@rr@U.T@P,0))
L=np.array([[0,1,0],[1,0,0],[0,0,1.]])
check('leaking unitary negative control gives return',np.trace(P@L@rr@L.T@P)>0)
N=1_000_000
prime=np.ones(N+1,dtype=bool);prime[:2]=False
for k in range(2,int(N**.5)+1):
 if prime[k]:prime[k*k::k]=False
n=np.arange(2,N+1);pr=prime[2:];even=(n%2==0)&~pr;odd=(n%2==1)&~pr
logs=np.log(n)
def fractions(alpha):
 w=np.exp(-alpha*logs);w/=w.sum();return w,w[even].sum(),w[odd].sum()
a=brentq(lambda a:fractions(a)[1]-.268,1.01,3,xtol=1e-14)
w,d,o=fractions(a);beta=.05/o
check('old alpha2 result preserved',close(fractions(2)[2],.04876893353364531))
check('old joint calibration preserved',close([a,beta],[1.8996876950554358,.8654570124136918]))
check('interior admissible target reproduced',close([beta*o,d,1-d-beta*o],[.05,.268,.682]))
check('domain endpoints beta zero and one',close([0*o,1*o],[0,o]))
check('six percent inadmissible at fixed alpha',.06/o>1)
# Two genuinely different finite drives, with identical total after calibration.
delta=np.array([[-.7,.4,.9],[.1,-.3,.6],[1.,.2,-.8],[.2,.8,-.5]])
weights=np.array([.2,.1,.3,.4])*o
other=delta+np.array([[.7],[-.4],[.3],[-.6]])
def T(h,z):return 1-np.prod(1-expit(z-h),axis=1)
def phi(h,z):return weights@T(h,z)
hs=[brentq(lambda h:phi(h,z)-.05,-40,40) for z in (delta,other)]
h=hs[0];aa=expit(delta-h);der=-np.prod(1-aa,axis=1)*aa.sum(axis=1)
check('analytic derivative matches centered difference',close(der,(T(h+1e-5,delta)-T(h-1e-5,delta))/2e-5,1e-8))
check('strictly decreasing on finite grid',np.all(np.diff([phi(x,delta) for x in np.linspace(-5,5,101)])<0))
check('both drives calibrate same aggregate',close([phi(hs[0],delta),phi(hs[1],other)],[.05,.05]))
check('same aggregate retains different address distributions',np.abs(weights*(T(hs[0],delta)-T(hs[1],other))).sum()>1e-5)
check('asymptotic endpoint limits',close([phi(-40,delta),phi(40,delta)],[o,0]))
# Nonprojective effects exercise the spectral measure-and-prepare realization.
effects=[np.diag([.3,.2,.1]),np.diag([.2,.5,.2]),np.diag([.5,.3,.7])]
kraus=[]
for s,E in enumerate(effects):
 vals,vecs=np.linalg.eigh(E)
 for j,v in enumerate(vals):
  k=np.zeros((3,3));k[s,:]=np.sqrt(v)*vecs[:,j];kraus.append(k)
f=np.array([np.trace(rho@E) for E in effects])
check('aggregate channel Kraus completeness',close(sum(k.T@k for k in kraus),I))
check('aggregate channel reproduces effect probabilities',close(sum(k@rho@k.T for k in kraus),np.diag(f)))
check('aggregate channel erases equal-diagonal coherence differences',close([np.trace((rho-np.diag(np.diag(rho)))@E) for E in effects],0))
f=np.array([.05,.268,.682]);u=2.3;V0=1.7
energy=lambda V:u*((f[0]+f[1])*V0+f[2]*V)
pressure=-u*f[2]
check('reference volume energy shares',close(u*V0*f/energy(V0),f))
check('pressure equals negative volume derivative',close(-(energy(2+1e-5)-energy(2-1e-5))/2e-5,pressure,1e-8))
check('finite volume work identity',close(energy(3)-energy(1),-pressure*2))
check('Friedmann normalization and q0',close([f.sum(),.5*(f[0]+f[1])-f[2]],[1,-.523]))
nonuniform=f*np.array([1,2,1]);nonuniform/=nonuniform.sum()
check('nonuniform energy readout changes fraction',close(nonuniform,[.05,.536,.682]/np.array(1.268)) and not close(nonuniform,f))
result={'scope':'Model mathematics and implementation; not empirical validation','passed':sum(x['passed'] for x in checks),'total':len(checks),'values':{'alpha':a,'beta':beta,'odd_available':o,'six_percent_beta':.06/o,'nonuniform_energy_percent':(100*nonuniform).tolist(),'drive_thresholds':hs},'checks':checks}
Path(__file__).with_name('results_r10.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
print(json.dumps(result,ensure_ascii=False,indent=2));assert all(x['passed'] for x in checks)
