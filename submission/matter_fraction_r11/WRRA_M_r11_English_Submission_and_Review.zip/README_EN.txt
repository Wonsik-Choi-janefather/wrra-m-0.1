WRRA ordinary matter fractions — English submission draft r11
8 October 2026
Authors: Wonsik Choi and Jeongin Choi

Canonical manuscript sources
review_r11/manuscript_EN.json: English submission draft, 214-word abstract.
review_r11/manuscript_KO.json: updated Korean reference version.
output/: editable Word files and rendered reading PDFs.
English is edited and reorganized for journal readers, not a line-by-line translation.
Both versions preserve the original numerical benchmarks. The English version uses
consecutive equation and table numbering; equation_map.json maps earlier equation labels.
The fixed Core expansion Worldline–Residue–Resource–Action replaces the inconsistent
expanded name appearing in the older Korean manuscript.

Revision content
Arithmetic motivation and explicit failure conditions were added. The English
edition reduces repetition, distinguishes calibration from outputs, and positions
the work relative to measurement/channel mathematics and informational toy models.
Strict review identified an admission-window mistranslation, a prime-sum transcription
error, a publication-title mismatch, and a compressed channel-comparison argument.
These were corrected. Recorded outcome–address states and a shared partial trace
now make the common downstream operation explicit. A fixed address-9 load contrast
shows which differences can be read before aggregation and disappear afterward.
This contrast is a conditional diagnostic, not a measured particle assignment.

Execution
Python 3.12.14, NumPy 2.3.5, SciPy 1.17.0 were used for the new checks.
Install numerical dependencies with: python -m pip install numpy scipy
Run from this package root:
python r10_check.py
python common_readout_check.py
python address_readout_check.py
Expected results: 27/27, 8/8, and 9/9 respectively.
The finite examples complement the manuscript proofs; assertion counts are not
counts of empirical agreement.

Prior evidence
prior_review/ preserves previous review and execution records.
review_r8/ and review_r9/ contain the prior implementations and inputs.
The five previously rerun suites passed 107 implementation assertions.
Their execution commands are:
python review_r9/renderer_coupling_check.py
python review_r9/phase_control_comparison.py
python review_r8/benchmark_derivation.py
python review_r8/twist_bridge_check.py
python review_r8/vacuum_reference_check.py
Those older programs additionally require mpmath, matplotlib, and pillow.
They preserve original numerical parameters and may use a local Korean font path.
This does not affect the two new readout checks, which do not render figures.

Rebuilding Word
python -m pip install python-docx lxml matplotlib
Install Pandoc, Latin Modern Math, and Noto Sans CJK KR separately.
python review_r11/build_documents.py
The authoritative input is the JSON source. Korean figure rendering expects
/usr/local/share/fonts/wrra/NotoSansCJKkr-Regular.otf; on another computer set
FontProperties to the actual installed path. LibreOffice or Word can export PDFs.
The English manuscript contains tables and native editable equations, without
rasterized mathematical expressions. PDFs were visually reviewed page by page.

Review status
Astra_Strict_Review_r11_KO.txt records an actual internal AI review.
Mathematical consistency and a recommendation for journal publication are separate
judgments. Read the full report; no external journal acceptance is claimed.
No journal submission, Zenodo publication, or GitHub publication was performed
for this revision.

Publication provenance
Earlier Korean r9: https://doi.org/10.5281/zenodo.23112865
Upstream inputs: https://doi.org/10.5281/zenodo.23092499
Downstream energy reference: https://doi.org/10.5281/zenodo.23076547
There is no new DOI assigned to the English revision.

Author information before actual submission
Funding and competing-interest declarations have not been supplied in the record.
They are explicitly pending in the draft, not silently guessed.
Both authors have approved the final manuscript and consented to submission.
Confirm Jeongin Choi's affiliation or unaffiliated city/country. Wonsik Choi's existing Seoul affiliation, email, and ORCID are
preserved. Submission_Notes_KO.txt lists these remaining administrative fields.
