from pathlib import Path
import json
ROOT=Path(__file__).resolve().parent
SOURCES={lang:json.loads((ROOT/f'manuscript_{lang}.json').read_text()) for lang in ['KO','EN']}
TITLES={k:v['title'] for k,v in SOURCES.items()}
SUBTITLES={k:v['subtitle'] for k,v in SOURCES.items()}
BLOCKS={k:v['blocks'] for k,v in SOURCES.items()}
