from pathlib import Path
import json,copy,subprocess
from zipfile import ZipFile
from lxml import etree
from docx import Document
from docx.shared import Inches,Pt,RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT,WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
from matplotlib.font_manager import FontProperties,findfont
from manuscript import BLOCKS,TITLES,SUBTITLES,ROOT

OUT=ROOT.parent/'output';OUT.mkdir(exist_ok=True)
ASSETS=ROOT/'assets';ASSETS.mkdir(exist_ok=True)
NS={'m':'http://schemas.openxmlformats.org/officeDocument/2006/math'}

def figure(lang):
 font=FontProperties(fname='/usr/local/share/fonts/wrra/NotoSansCJKkr-Regular.otf',size=10) if lang=='KO' else FontProperties(family='DejaVu Sans',size=10)
 fig,ax=plt.subplots(figsize=(7.6,3.0),dpi=250)
 ax.set_xlim(0,10);ax.set_ylim(-.12,6);ax.axis('off')
 labels= {
  'KO':['공통전달자\n같은 상태와 전달 골격','상류 관계 주소\n소수와 합성 관계','초기 진입 A\n정상 복귀 B','잔존 Actual 31.8%\n접힘 보존','최종 렌더러 미짝 포트\n표현형 φ 5%  비표현형 D 26.8%','복귀 R 68.2%\n반사와 정상 복귀','하류 물리 판독\n물질과 기록  에너지 부하','에너지 부하 판독\n표현형과 별도로 명세'],
  'EN':['Common carrier\nShared state and transport','Upstream relation addresses\nPrimes and composites','Initial admission A\nNormal return B','Retained Actual 31.8%\nFold preservation','Expressed φ 5%\nUnexpressed D 26.8%','Returned R 68.2%\nReflection and return','Downstream physical readout\nMatter records energy load','Common energy function\nGravity and expansion'] }[lang]
 boxes=[(.2,4.75,2.8,.8),(3.6,4.75,3.1,.8),(3.6,3.5,3.1,.8),(3.6,2.25,3.1,.8),(3.6,1,3.1,.8),(7.4,3.5,2.35,.8),(.2,1,2.8,.8),(.2,-.0,2.8,.7)]
 for i,((x,y,w,h),s) in enumerate(zip(boxes,labels)):
  ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0.025,rounding_size=.045',facecolor='white',edgecolor='black',linewidth=1))
  ax.text(x+w/2,y+h/2,s,ha='center',va='center',fontproperties=font,fontsize=9.2)
 def arrow(a,b,dashed=False): ax.annotate('',xy=b,xytext=a,arrowprops=dict(arrowstyle='->',color='black',lw=1.05,linestyle='--' if dashed else '-'))
 arrow((3.05,5.15),(3.55,5.15),True)
 for a,b in [((5.15,4.72),(5.15,4.34)),((5.15,3.47),(5.15,3.09)),((5.15,2.22),(5.15,1.84)),((6.75,3.9),(7.34,3.9))]:arrow(a,b)
 arrow((3.56,1.4),(3.05,1.4),True);arrow((1.6,.96),(1.6,.74),True)
 ax.plot([8.575,8.575,3.07],[3.46,.35,.35],color='black',lw=1.05,linestyle='--')
 arrow((3.35,.35),(3.04,.35),True)
 ax.text(6.2,.53,'복귀 부문의 부하 명세' if lang=='KO' else 'Return load interface',ha='center',fontproperties=font,fontsize=8)
 fig.subplots_adjust(left=.01,right=.99,top=.99,bottom=.01)
 path=ASSETS/f'whole_flow_{lang}.png';fig.savefig(path,bbox_inches='tight',pad_inches=.04);plt.close(fig)
 return path

def font(run,lang,size=None,bold=None):
 run.font.name='Noto Sans CJK KR' if lang=='KO' else 'Times New Roman'
 run._element.get_or_add_rPr().get_or_add_rFonts().set(qn('w:eastAsia'),'Noto Sans CJK KR')
 run.font.color.rgb=RGBColor(0,0,0)
 if size:run.font.size=Pt(size)
 if bold is not None:run.bold=bold

def make_table(doc,b,lang):
 cap=doc.add_paragraph(b['caption'],'Caption');cap.paragraph_format.keep_with_next=True
 tab=doc.add_table(rows=1,cols=len(b['headers']));tab.alignment=WD_TABLE_ALIGNMENT.CENTER;tab.autofit=False
 for j,w in enumerate(b['widths']):tab.columns[j].width=Inches(w)
 borders=OxmlElement('w:tblBorders')
 for name in ('top','bottom','left','right','insideH','insideV'):
  x=OxmlElement('w:'+name);x.set(qn('w:val'),'single');x.set(qn('w:sz'),'4');x.set(qn('w:color'),'D9D9D9');borders.append(x)
 tab._tbl.tblPr.append(borders)
 head=OxmlElement('w:tblHeader');tab.rows[0]._tr.get_or_add_trPr().append(head)
 for ri,values in enumerate([b['headers']]+b['rows']):
  row=tab.rows[0] if ri==0 else tab.add_row();row._tr.get_or_add_trPr().append(OxmlElement('w:cantSplit'))
  for j,v in enumerate(values):
   cell=row.cells[j];cell.width=Inches(b['widths'][j]);cell.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
   margin=OxmlElement('w:tcMar')
   for name in ('top','bottom','left','right'):
    el=OxmlElement('w:'+name);el.set(qn('w:w'),'100');el.set(qn('w:type'),'dxa');margin.append(el)
   cell._tc.get_or_add_tcPr().append(margin)
   if ri==0:
    sh=OxmlElement('w:shd');sh.set(qn('w:fill'),'E7E7E7');cell._tc.get_or_add_tcPr().append(sh)
   pp=cell.paragraphs[0];pp.paragraph_format.space_after=Pt(1);pp.paragraph_format.line_spacing=1.1
   pp.paragraph_format.keep_with_next=(ri==0 or (len(b['rows'])<=4 and ri<len(b['rows'])))
   pp.alignment=WD_ALIGN_PARAGRAPH.CENTER if (len(str(v))<23 and j>0) else WD_ALIGN_PARAGRAPH.LEFT
   font(pp.add_run(str(v)),lang,10.3,ri==0)
 doc.add_paragraph().paragraph_format.space_after=Pt(1)

def build(lang,stem='WRRA_M_물질5퍼센트_용어병기_한글_r9',source_filename=None):
 blocks=BLOCKS[lang]
 equations=[b for b in blocks if b['kind']=='eq']
 md=ASSETS/'equations.txt';md.write_text('\n\n'.join('$$\n'+b['tex']+'\n$$' for b in equations))
 mathdoc=ASSETS/'equations.docx'
 subprocess.run(['pandoc','-f','markdown',str(md),'-o',str(mathdoc)],check=True)
 with ZipFile(mathdoc) as z:tree=etree.fromstring(z.read('word/document.xml'))
 nodes=tree.xpath('//m:oMath',namespaces=NS)
 assert len(nodes)==len(equations)
 mathnodes={b['label']:copy.deepcopy(n) for b,n in zip(equations,nodes)}
 d=Document();sec=d.sections[0]
 sec.page_width=Inches(8.5);sec.page_height=Inches(11)
 sec.left_margin=sec.right_margin=Inches(.85);sec.top_margin=Inches(.75);sec.bottom_margin=Inches(.70)
 sec.footer_distance=Inches(.28)
 for name in ['Normal','Title','Subtitle','Heading 1','Heading 2','Caption']:
  st=d.styles[name];st.font.name='Noto Sans CJK KR' if lang=='KO' else 'Times New Roman';st.font.color.rgb=RGBColor(0,0,0)
  st._element.get_or_add_rPr().get_or_add_rFonts().set(qn('w:eastAsia'),'Noto Sans CJK KR')
  st.font.italic=False;st.paragraph_format.alignment=WD_ALIGN_PARAGRAPH.LEFT;st.paragraph_format.first_line_indent=Pt(0)
  for el in st._element.xpath('.//w:pBdr|.//w:numPr'):el.getparent().remove(el)
 normal=d.styles['Normal'];normal.font.size=Pt(11 if lang=='KO' else 11.5)
 normal.paragraph_format.line_spacing=Pt(16.5 if lang=='KO' else 15.8);normal.paragraph_format.space_after=Pt(6)
 normal.paragraph_format.widow_control=True
 for name,size in [('Title',20),('Subtitle',11),('Heading 1',13),('Heading 2',11.5),('Caption',10)]:
  d.styles[name].font.size=Pt(size);d.styles[name].font.bold=name in ('Title','Heading 1','Heading 2')
 d.styles['Heading 1'].paragraph_format.space_before=Pt(10);d.styles['Heading 1'].paragraph_format.space_after=Pt(5)
 d.styles['Heading 2'].paragraph_format.space_before=Pt(7);d.styles['Heading 2'].paragraph_format.space_after=Pt(4)
 for name in ['Heading 1','Heading 2']:d.styles[name].paragraph_format.keep_with_next=True
 d.styles['Caption'].paragraph_format.space_after=Pt(5);d.styles['Caption'].paragraph_format.line_spacing=1.1
 d.add_paragraph(TITLES[lang],'Title');d.add_paragraph(SUBTITLES[lang],'Subtitle')
 author='최원식 Wonsik Choi  ·  최정인 Jeongin Choi' if lang=='KO' else 'Wonsik Choi · Jeongin Choi'
 affiliation='최원식  독립 연구자  대한민국 서울' if lang=='KO' else 'Wonsik Choi  Independent Researcher  Seoul  Republic of Korea'
 contact='교신저자 최원식  ORCID 0009-0001-4263-9772  janefather@gmail.com' if lang=='KO' else 'Correspondence Wonsik Choi  ORCID 0009-0001-4263-9772  janefather@gmail.com'
 for line in [author,affiliation,contact, '투고용 영문 대응 개정판 r11  2026년 10월 8일' if lang=='KO' else 'English submission draft r11  8 October 2026']:
  pp=d.add_paragraph();pp.paragraph_format.space_after=Pt(2);font(pp.add_run(line),lang,9.5)
 for b in blocks:
  kind=b['kind']
  if kind=='h':
   hp=d.add_paragraph(b['text'],'Heading '+str(b['level']))
   if b['text']=='서론':hp.paragraph_format.page_break_before=True
  elif kind in ('p','keywords','ref'):
   pp=d.add_paragraph(b['text'])
   if kind in ('ref','keywords'):
    pp.paragraph_format.line_spacing=Pt(13);pp.paragraph_format.space_after=Pt(4)
    for run in pp.runs:font(run,lang,9.5)
  elif kind=='table':make_table(d,b,lang)
  elif kind=='eq':
   pp=d.add_paragraph();pp.alignment=WD_ALIGN_PARAGRAPH.CENTER;pp.paragraph_format.space_before=Pt(2);pp.paragraph_format.space_after=Pt(7);pp.paragraph_format.line_spacing=1;pp.paragraph_format.keep_together=True
   node=mathnodes[b['label']]
   for mr in node.xpath('.//*[local-name()="r"]'):
    rpr=OxmlElement('w:rPr');fonts=OxmlElement('w:rFonts');fonts.set(qn('w:ascii'),'Latin Modern Math');fonts.set(qn('w:hAnsi'),'Latin Modern Math');rpr.append(fonts)
    sz=OxmlElement('w:sz');sz.set(qn('w:val'),'21');rpr.append(sz);mr.insert(0,rpr)
   pp._p.append(node);font(pp.add_run('  ('+b['label']+')'),lang,9)
  elif kind=='fig':
   pp=d.add_paragraph();pp.paragraph_format.keep_with_next=True;pp.paragraph_format.line_spacing=1;pp.alignment=WD_ALIGN_PARAGRAPH.CENTER
   pic=ASSETS/'phase_controls_KO.png' if b.get('name')=='phase_controls' else figure(lang)
   pp.add_run().add_picture(str(pic),width=Inches(6.6));d.add_paragraph(b['caption'],'Caption')
 footer=sec.footer.paragraphs[0];footer.alignment=WD_ALIGN_PARAGRAPH.CENTER
 run=footer.add_run();font(run,lang,9)
 begin=OxmlElement('w:fldChar');begin.set(qn('w:fldCharType'),'begin');run._r.append(begin)
 instruction=OxmlElement('w:instrText');instruction.set(qn('xml:space'),'preserve');instruction.text=' PAGE ';run._r.append(instruction)
 separate=OxmlElement('w:fldChar');separate.set(qn('w:fldCharType'),'separate');run._r.append(separate)
 value=OxmlElement('w:t');value.text='1';run._r.append(value)
 end=OxmlElement('w:fldChar');end.set(qn('w:fldCharType'),'end');run._r.append(end)
 d.core_properties.title=TITLES[lang];d.core_properties.subject=SUBTITLES[lang];d.core_properties.author='Wonsik Choi; Jeongin Choi'
 d.core_properties.keywords='WRRA; minimal computation; common carrier; dimension filter; ordinary matter; vacuum reference; cosmological benchmark'
 path=OUT/(stem+'.docx');d.save(path)
 (ROOT/(source_filename or f'manuscript_{lang}.json')).write_text(json.dumps({'title':TITLES[lang],'subtitle':SUBTITLES[lang],'blocks':blocks},ensure_ascii=False,indent=2))
 print(path)

if __name__=='__main__':
 build('KO',stem='WRRA_M_Matter_Fraction_r11_KO')
 build('EN',stem='WRRA_M_Matter_Fraction_r11_EN')
