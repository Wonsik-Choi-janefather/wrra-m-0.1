"""WRRA energy-pressure compatibility v0.2. Offline deterministic reproduction.
Run python reproduce.py. Energies normalized to E*=2 m_mu, v=V/V0.
The compensation spectrum is a declared effective construction, not measured matter.
"""
from pathlib import Path
import contextlib, io, json, runpy, hashlib, platform
import numpy as np
import scipy
from scipy.linalg import expm
from scipy.optimize import brentq
from scipy.integrate import quad
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
R=Path(__file__).resolve().parent
with contextlib.redirect_stdout(io.StringIO()):
    carrier=runpy.run_path(str(R/'inherited/carrier/reproduce.py'))
decay=carrier['prior']; interface=decay['inherited']
X=float(interface['rows'][0]['electron_pair_probability'])
m=decay['m']; M=decay['M']; r=(m/M)**2
A=.05; D=.268; L=.682; beta=.035; K=1+beta/A
checks=[]
def check(name,error,tol=1e-11):
    error=float(error)
    checks.append(dict(name=name,error=error,tolerance=tol,passed=bool(np.isfinite(error) and error<=tol)))
def yes(name,condition):check(name,0 if condition else 1,0)
for key,prior in [('carrier',carrier),('decay',decay),('interface',interface)]:
    yes('inherited '+key+' suite',all(c['passed'] for c in prior['checks']))
def e(v): return np.sqrt(r+(1-r)*np.asarray(v)**(-2/3))
def s(v): return (1-r)*np.asarray(v)**(-2/3)/(3*e(v))
def e2(v):
    y=(1-r)*np.asarray(v)**(-2/3)
    return y*(5*r+4*y)/(9*np.asarray(v)**2*(r+y)**1.5)
def b(v,x=X):return x*e(v)+1-x
def fd(f,v,h=2e-5):return -v*(f(v*(1+h))-f(v*(1-h)))/(2*h*v)
vgrid=np.geomspace(.5,8,301)
check('energy derivative electron',np.max(np.abs(fd(e,vgrid)-s(vgrid))),1e-9)
check('analytic curvature versus second difference',np.max(np.abs((e(vgrid*(1+1e-4))-2*e(vgrid)+e(vgrid*(1-1e-4)))/(1e-4*vgrid)**2-e2(vgrid))),2e-7)
yes('strict kinetic convexity',np.all(e2(vgrid)>0))
yes('reservoir has negative independent bulk response',np.all(-e2(vgrid)<0))

# Correlated matching subspace |s,c_s>, |e,c_e>, |mu,c_mu>.
# Reservoir state c_s=c_mu may share one level; implement two reservoir levels.
witness=[]
for v in [.5,.8,1.,2.,8.]:
    hm=np.diag([1.,float(e(v)),1.]); hc=np.diag([K-1,K-float(e(v))])
    total=np.kron(hm,np.eye(2))+np.kron(np.eye(3),hc)
    idx=[0,3,4] # |s,0>, |e,1>, |mu,0>
    for target,prob in [(3,X),(4,1-X)]:
        hi=np.zeros((6,6));hi[0,target]=hi[target,0]=.1
        U=expm(-1j*np.pi/(2*.1)*(total+hi));state=U[:,0]
        check(f'matching transfer v={v} target={target}',abs(abs(state[target])**2-1))
        for theta in [0.,np.pi/6,np.pi/4,np.pi/2,np.pi]:
            pulse=expm(-1j*theta/.1*(total+hi))[:,0]
            check(f'partial pulse probabilities v={v} target={target} theta={theta}',max(abs(abs(pulse[0])**2-np.cos(theta)**2),abs(abs(pulse[target])**2-np.sin(theta)**2)))
            yes(f'partial pulse no leakage v={v} target={target} theta={theta}',sum(abs(pulse[q])**2 for q in range(6) if q not in [0,target])<1e-20)
        check(f'bare conservation commutator v={v} target={target}',np.max(abs(total@hi-hi@total)))
        check(f'joint energy v={v} target={target}',abs(np.vdot(state,total@state).real-K))
    check(f'matching energy degeneracy v={v}',np.max(abs(np.diag(total)[idx]-K)))
    ps=np.kron(np.diag([0,float(s(v)),0]),np.eye(2))
    pc=np.kron(np.eye(3),np.diag([0,-float(s(v))]))
    check(f'matching stress v={v}',np.max(abs(np.diag(ps+pc)[idx])))
    yes(f'positive reservoir spectrum v={v}',np.min(np.diag(hc))>=0)
    yes(f'algebraic dominant energy diagnostic v={v}',K-e(v)>=s(v))
    # A common, uncorrelated reservoir cannot cancel both source and hot branch.
    yes(f'fixed reservoir negative control v={v}',s(v)>.01)
    q=float(s(v)); offsets=np.linspace(-1.5*q,.5*q,2001)
    residual=np.maximum(abs(offsets),abs(offsets+q))
    check(f'unresolved minimax pressure v={v}',abs(residual.min()-q/2))
    witness.append(dict(v=v,electron_energy=float(e(v)),electron_stress=float(s(v)),
                        electron_compensation=float(K-e(v)),ensemble_compensation=float(K-b(v))))

pos_limit=((1-r)/(K*K-r))**1.5
dec_limit=brentq(lambda v:e(v)+s(v)-K,.1,1)
beta_pos=A*(e(.5)-1);beta_dec=A*(e(.5)+s(.5)-1)
yes('positivity fails below compression boundary',K-e(.99*pos_limit)<0)
check('positivity boundary equation',abs(K-e(pos_limit)))
check('dominant diagnostic boundary equation',abs(K-e(dec_limit)-s(dec_limit)))
yes('dominant diagnostic fails before positivity',dec_limit>pos_limit)
yes('reserve fits inherited D allocation',0<beta<D)
for row in interface['rows']:
    xx=row['electron_pair_probability']
    def et(v):return A*b(v,xx)+(beta+A*(1-b(v,xx)))+(D-beta)+L*v
    check('aggregate energy '+row['drive'],np.max(abs(et(vgrid)-(A+D+L*vgrid))))
    check('aggregate stress '+row['drive'],np.max(abs(fd(et,vgrid)+L*vgrid)),1e-9)
    check('aggregate q '+row['drive'],abs(.5*(1-3*L/et(1))+.523))
    check('reserve integrated work '+row['drive'],abs(quad(lambda v:xx*s(v)/v,.5,8)[0]-(b(.5,xx)-b(8,xx))))

# Cold channels: fixed pair count loses common energy; compensated or renumbered alternatives.
cold_energy=X*m/M+1-X
cold_comp=X*(1-m/M)
check('cold compensated reference energy',abs(cold_energy+cold_comp-1))
yes('cold pair count common-energy obstruction',abs(cold_energy-1)>.5)
number_multiplier=1/cold_energy
check('cold renormalized expected energy',abs(number_multiplier*cold_energy-1))
yes('cold renormalization changes count',number_multiplier>3)
yes('constant compensation is cold zero pressure',fd(lambda v: np.zeros_like(v)+cold_comp,2)==0)

# A one-point constant-density compensator C=a v matches stress only at v=1.
rho=X*s(1)
check('vacuumlike tuning at reference',abs(X*s(1)-rho))
yes('vacuumlike tuning fails on interval',max(abs(X*s(vgrid)-rho*vgrid))>.3)
# Positive-curvature correction stabilizes the compensator but changes the dust law.
kappa=3.
yes('elastic correction convex on interval',np.min(kappa-X*e2(vgrid))>0)
def stable_total(v):return K+.5*kappa*(np.asarray(v)-1)**2
check('elastic stress derivative',np.max(abs(fd(stable_total,vgrid)+kappa*vgrid*(vgrid-1))),1e-7)
yes('strict curvature excludes interval dust',abs(fd(stable_total,2))>1)

# Actual handoff to the finite decay kernel at fixed volume.
times=np.array([0.,1.,3.,5.]); dyn=[]
for u in times:
    now=decay['fixed'](X,float(u)); stress=now['pv_over_E0']
    rigid_residual=stress-X*s(1)
    check(f'rigid decay residual u={u}',abs(rigid_residual-(1-X)*(-np.expm1(-u))*decay['D']))
    def efixed(v):
        return X*e(v)+(1-X)*(np.exp(-u)+(-np.expm1(-u))*decay['moments'](decay['k'],v**(-1/3))[0]/M)
    check(f'adaptive matched decay stress derivative u={u}',abs(stress+fd(lambda v:K-efixed(v),1.)),1e-9)
    dyn.append(dict(time_tau=float(u),matter_stress=stress,rigid_residual=rigid_residual,
                    matching_reservoir_stress=-stress))
yes('rigid compensation fails after decay',dyn[-1]['rigid_residual']>.08)

# Birth records retained. Independent construction of the same split-step cohort state.
k=decay['k']; wp=k['w'].sum(axis=1); pe=k['pe'][:,0]
nu=float(np.sum(k['w']*(k['ea']+k['en'])))
def frozen_cohorts(t,dt=.01,h=.1):
    steps=int(round(t/dt));t=steps*dt;vnow=np.exp(3*h*t)
    birth=np.arange(1,steps+1)*dt
    counts=2*(1-X)*np.exp(-birth+dt)*(-np.expm1(-dt))
    mu=2*(1-X)*np.exp(-t)
    def energy(v):
        ratios=(np.exp(3*h*birth)/v)**(1/3)
        daughter=np.hypot(m,ratios[:,None]*pe)@wp+nu*ratios
        return float((2*X*np.hypot(m,np.sqrt(M*M-m*m)*v**(-1/3))+mu*M+counts@daughter)/(2*M))
    def stress(v):
        ratios=(np.exp(3*h*birth)/v)**(1/3); mom=ratios[:,None]*pe
        daughter=(mom*mom/np.hypot(m,mom))@wp/3+nu*ratios/3
        return float(X*s(v)+counts@daughter/(2*M))
    return vnow,energy,stress
expansion=[]
for t in [1.,3.,5.]:
    vn,ef,pf=frozen_cohorts(t)
    inherited=np.array(decay['expanding'](X,.01,T=t))/(2*M)
    check(f'executed cohort energy t={t}',abs(ef(vn)-inherited[0]))
    check(f'executed cohort stress t={t}',abs(pf(vn)-inherited[1]))
    check(f'frozen cohort derivative t={t}',abs(fd(ef,vn)-pf(vn)),1e-9)
    check(f'cohort compensation derivative t={t}',abs(fd(lambda v:K-ef(v),vn)+pf(vn)),1e-9)
    check(f'cohort total energy t={t}',abs(ef(vn)+(K-ef(vn))-K),0)
    # Independent finite difference, not merely algebraic assignment of opposite pressure.
    check(f'cohort total pressure t={t}',abs(pf(vn)+fd(lambda v:K-ef(v),vn)),1e-9)
    expansion.append(dict(time_tau=t,v=vn,matter_energy=ef(vn),matter_stress=pf(vn),
                          reservoir_energy=K-ef(vn),reservoir_stress=fd(lambda v:K-ef(v),vn)))

# Packet-level equal-energy decay transition changes the reservoir force without energy transfer.
for j in [0,17,1000,4095]:
    Enew=float((k['ee'].ravel()[j]+k['ea'].ravel()[j]+k['en'].ravel()[j])/M)
    Snew=float((k['pe'].ravel()[j]**2/k['ee'].ravel()[j]+k['ea'].ravel()[j]+k['en'].ravel()[j])/(3*M))
    check(f'decay packet joint energy j={j}',abs(Enew+(K-Enew)-K))
    check(f'decay record zero birth energy jump j={j}',abs((K-Enew)-(K-1)))
    yes(f'decay record nonzero stress jump j={j}',Snew>.1)

# Daughter admissibility applies to records together with their allowed volume.
packet_nu=M-np.hypot(m,pe)
ratios=np.geomspace(1.,8.,101)[:,None]**(-1/3)
packet_e=np.hypot(m,ratios*pe)+packet_nu*ratios
packet_p=((ratios*pe)**2/np.hypot(m,ratios*pe)+packet_nu*ratios)/3
yes('daughter postbirth energy bound',np.max(packet_e/M)<=1+1e-14)
yes('daughter postbirth pressure bound',np.max((packet_p-packet_e/3)/M)<=1e-14)
yes('daughter postbirth positive reservoir',np.min(K-packet_e/M)>=0)
yes('daughter postbirth stronger diagnostic',np.min(K-(packet_e+packet_p)/M)>=0)
vb=float(np.exp(1.5)); aa=(vb/.5)**(1/3)
excluded=(np.hypot(m,aa*pe)+packet_nu*aa)/M
yes('late birth compressed outside admitted domain fails',np.all(K-excluded<0))
eta=.1
mismatch=eta*X*s(1)
check('mismatched record residual',abs((X*s(1)-(1-eta)*X*s(1))-mismatch))
eps=.003
check('spectral slope error residual',abs(fd(lambda v:eps*v*v,2)+2*eps*4),1e-9)

out=dict(version='0.2',inputs=dict(m_e_MeV=m,m_mu_MeV=M,r=r,X=X,A=A,D=D,Lambda=L,beta=beta,K=K,interval=[.5,8.]),
    capacity=dict(positivity_limit=pos_limit,dominant_diagnostic_limit=dec_limit,
                  minimum_beta_positive_at_vhalf=float(beta_pos),minimum_beta_dominant_at_vhalf=float(beta_dec)),
    cold=dict(matter_energy=cold_energy,compensation=cold_comp,number_multiplier=number_multiplier),
    static=witness,decay=dyn,expansion=expansion,
    daughter_domain=dict(rule="v >= birth_volume",K_sufficient=4/3,excluded_birth_volume=vb,excluded_volume=.5,excluded_energy_min=float(excluded.min()),excluded_energy_max=float(excluded.max())),
    protocol=dict(mismatch_eta=eta,mismatch_residual=float(mismatch)),
    q_without_compensation=float(.5*(1+3*(A*X*s(1)-L))),q_with_compensation=-.523,
    inherited_counts={name:len(a['checks']) for name,a in [('carrier',carrier),('decay',decay),('interface',interface)]},
    checks=checks,passed=sum(c['passed'] for c in checks),total=len(checks),
    versions=dict(python=platform.python_version(),numpy=np.__version__,scipy=scipy.__version__,matplotlib=matplotlib.__version__))
(R/'results.json').write_text(json.dumps(out,indent=2))
provenance={str(p.relative_to(R)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (R/'inherited').rglob('*') if p.name in ['reproduce.py','r11_controls.json']}
(R/'provenance.json').write_text(json.dumps(provenance,indent=2))
plt.rcParams.update({'font.size':10,'font.family':'DejaVu Sans','pdf.fonttype':42})
fig,ax=plt.subplots(1,2,figsize=(7,2.8),layout='constrained')
ax[0].plot(vgrid,b(vgrid),label='Matter');ax[0].plot(vgrid,K-b(vgrid),label='Compensator');ax[0].axhline(K,color='k',ls=':',label='Total')
ax[0].set(xscale='log',xlabel='Volume ratio v',ylabel='Energy / E*');ax[0].legend(fontsize=8)
ax[1].plot(vgrid,X*s(vgrid),label='Matter');ax[1].plot(vgrid,-X*s(vgrid),label='Compensator');ax[1].axhline(0,color='k',ls=':',label='Total')
ax[1].set(xscale='log',xlabel='Volume ratio v',ylabel='Pressure-volume / E*');ax[1].legend(fontsize=8)
for ext in ['png','pdf']:fig.savefig(R/'figures'/('Fig1.'+ext),dpi=240)
plt.close(fig)
fig,ax=plt.subplots(1,2,figsize=(7,2.8),layout='constrained')
vs=np.linspace(.15,1,300)
ax[0].plot(vs,K-e(vs),label='Energy');ax[0].plot(vs,K-e(vs)-s(vs),label='Energy minus |PV|');ax[0].axhline(0,color='k',lw=.7)
ax[0].axvline(pos_limit,color='gray',ls=':');ax[0].axvline(dec_limit,color='gray',ls='--');ax[0].set(xlabel='Volume ratio v',ylabel='Hot-branch reservoir / E*');ax[0].legend(fontsize=7)
tt=np.linspace(0,5,101);stress=np.array([decay['fixed'](X,t)['pv_over_E0'] for t in tt])
ax[1].plot(tt,stress-X*s(1),label='Frozen compensator residual');ax[1].axhline(0,color='k',ls=':',label='Updated matching records')
ax[1].set(xlabel='Time / muon lifetime',ylabel='Residual pressure-volume / E*');ax[1].legend(fontsize=7)
for ext in ['png','pdf']:fig.savefig(R/'figures'/('Fig2.'+ext),dpi=240)
plt.close(fig)
print(json.dumps({k:v for k,v in out.items() if k not in ['checks']},indent=2))
assert all(c['passed'] for c in checks),[c for c in checks if not c['passed']]
