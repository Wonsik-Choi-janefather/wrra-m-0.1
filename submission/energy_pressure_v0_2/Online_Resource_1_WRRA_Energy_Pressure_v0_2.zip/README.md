# Energy and Pressure Compatibility in Finite WRRA Models

Cold Allocations and Compensating Sectors · v0.2 · 9 October 2026

Wonsik Choi and Jeongin Choi. Correspondence: janefather@gmail.com.

## Reproduce

From this directory run `python reproduce.py` with NumPy, SciPy and Matplotlib installed. The deterministic offline run executes the unchanged inherited carrier, decay and interface scripts before the new calculation. It writes results.json, provenance.json and figures. No network access or fitting is required. See requirements.txt for the recorded package versions.

The new suite contains 244 checks. Inherited suites report 123 carrier, 56 decay and 47 interface checks; these nested counts overlap and are not independent experiments. An assertion fails if any recorded test fails. The published numerical values use Python 3.12.14.

## Inputs and construction

The archived address preparation and measured lepton mass energies are retained. The new effective reservoir spectrum is deliberately complementary to the matter energies. The chosen reserve beta=0.035, K=1.7 and volume interval [0.5,8] are design inputs. Capacity thresholds, pressure responses, and compatibility restrictions are derived from them. Known-value recovery is a consistency result.

A matching subspace in a six-dimensional matter-reservoir space closes energy and pressure and supports a volume-independent carrier pulse. This statement does not apply to arbitrary states of the full product space. An independently convex additive material cannot cancel the hot kinetic sector on an interval. Decay composition requires updated finite momentum/birth records; the physical origin of this update is not derived.

## Files

- manuscript.md: complete English source with proofs and references.
- guide_KO.md: Korean explanation.
- reproduce.py: new finite compensation and failure tests.
- results.json: numerical results and individual test tolerances.
- provenance.json: SHA-256 hashes of inherited source and control inputs.
- figures/: vector PDF and raster PNG figures.
- inherited/carrier/reproduce.py: unchanged carrier v0.2 calculation.
- inherited/carrier/inherited/decay/reproduce.py: unchanged decay v0.2 calculation.
- inherited/carrier/inherited/decay/inherited/: unchanged interface and archived controls.
- Astra_Medium_Review_KO.txt: separate AI review of v0.1.
- Response_to_Astra_KO.txt: point-by-point v0.2 revision record.
- Astra_Medium_Recheck_KO.txt: focused AI recheck of the revision.

## Preceding records

1. r11: https://doi.org/10.5281/zenodo.23237629
2. Particle interface: https://doi.org/10.5281/zenodo.23241511
3. Dynamic decays: https://doi.org/10.5281/zenodo.23246308
4. Carrier coupling: https://doi.org/10.5281/zenodo.23250062

This fifth manuscript has not been submitted or publicly deposited by this workflow. Human authors must finalize authorship, affiliation, funding and competing-interest declarations before journal submission. AI assistance is disclosed in the manuscript. Version 0.1 received a separate Astra medium AI review. This v0.2 addresses that review; review records are AI preparation records, not external journal peer review.

The static interval belongs to the initial records. Daughter records on the executed monotone path admit v >= birth_volume; Proposition 6 gives a sufficient K >= 4/3 bound. Counterfactual compression is a failure control, not part of that path. Partial pulses and domain/protocol tests bring the new suite to 244 checks.
