"""Figure-4 vector extraction and experiment-parameter unitary comparison."""
from pathlib import Path
import csv,json
import fitz
import numpy as np
from scipy.optimize import minimize_scalar

OUT=Path('WRRA_Time_Crystal_Observation_v0_5');OUT.mkdir(exist_ok=True)

def extract():
 p=fitz.open('nature21413.pdf')[2];ds=p.get_drawings()
 # Axis tick centers, publisher PDF page 3, in PDF points.
 x0=340.0353; dx=(550.1963-340.0353)/.12
 y0=193.0803;dy=(193.0803-82.7903)/.08
 rows=[]
 for drawing,label in [(292,.072),(302,.048),(331,.024),(351,.012)]:
  for item in ds[drawing]['items']:
   kind,a,b=item
   assert kind=='l' and abs(a.x-b.x)<1e-6
   rows.append({'two_J0_t2':label,'epsilon':round((a.x-x0)/dx,3),
    'observed_height':(y0-(a.y+b.y)/2)/dy,'observed_sd':abs(a.y-b.y)/2/dy,
    'pdf_x':a.x,'pdf_y':(a.y+b.y)/2,'drawing':drawing})
 assert len(rows)==35
 return rows

def evolve(epsilon,jphase,n=10,seeds=100,steps=100,alpha=1.5):
 rng=np.random.default_rng(20261023)
 z=1.-2.*((np.arange(2**n)[:,None]>>np.arange(n))&1)
 # Same disorder instances used at all epsilon and interaction strengths.
 h=rng.uniform(0,np.pi,(seeds,n))
 energy=h@z.T
 for i in range(n):
  for j in range(i+1,n):energy+=jphase/(j-i)**alpha*(z[:,i]*z[:,j])[None,:]
 diag=np.exp(-1j*energy)
 psi=np.zeros((seeds,2**n),complex);psi[:,0]=1
 theta=np.pi*(1-epsilon);c=np.cos(theta/2);s=-1j*np.sin(theta/2)
 tr=np.empty((steps,seeds,n));normerr=0.
 for k in range(steps):
  for q in range(n):
   v=psi.reshape(seeds,-1,2,2**q)
   a=v[:,:,0,:].copy();b=v[:,:,1,:].copy()
   v[:,:,0,:]=c*a+s*b;v[:,:,1,:]=s*a+c*b
  psi*=diag;prob=np.abs(psi)**2
  tr[k]=prob@z
  normerr=max(normerr,float(abs(prob.sum(1)-1).max()))
 # Central Fourier magnitude, averaged over sites and disorder, after 100 cycles.
 amp=abs(np.mean(tr*((-1.)**np.arange(1,steps+1))[:,None,None],axis=0))
 return {'central_amplitude':float(amp.mean()),'disorder_sd_of_site_mean':float(amp.mean(1).std(ddof=1)),
 'norm_error':normerr},tr

def main():
 rows=extract();cache={}
 for idx,r in enumerate(rows):
  key=(r['epsilon'],r['two_J0_t2'])
  val,tr=evolve(key[0],key[1]/2)
  cache[key]=val;r.update(val)
  print(f"{idx+1}/35 eps={key[0]} 2Jt={key[1]} A={val['central_amplitude']:.5f}",flush=True)
 with (OUT/'observed_and_calculated.csv').open('w') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
 obs=np.array([r['observed_height'] for r in rows]);sd=np.array([r['observed_sd'] for r in rows]);pred=np.array([r['central_amplitude'] for r in rows])
 # This is a plotting/damping calibration, not a physical parameter prediction.
 def score(mask):
  a=float(np.sum(pred[mask]*obs[mask]/sd[mask]**2)/np.sum((pred[mask]/sd[mask])**2))
  res=(a*pred-obs)
  return a,{'rms':float(np.sqrt(np.mean(res**2))),'sd_scaled_mean_square':float(np.mean((res/sd)**2)),
  'within_one_reported_sd':int(np.sum(abs(res)<=sd)),'within_two_reported_sd':int(np.sum(abs(res)<=2*sd))}
 a,stats=score(np.ones(len(rows),bool))
 train=np.array([i%3!=0 for i in range(len(rows))]);at,_=score(train)
 hold=~train;held_res=(at*pred-obs)[hold]
 summary={'points':len(rows),'common_amplitude_scale':a,'all_points':stats,
 'held_out_points':int(hold.sum()),'training_scale':at,'heldout_rms':float(np.sqrt(np.mean(held_res**2))),
 'heldout_sd_scaled_mean_square':float(np.mean((held_res/sd[hold])**2)),
 'max_norm_error':max(r['norm_error'] for r in rows),'per_coupling':[]}
 for j in [.072,.048,.024,.012]:
  mask=np.array([r['two_J0_t2']==j for r in rows]);ac,_=score(mask)
  rr=a*pred[mask]-obs[mask]
  summary['per_coupling'].append({'two_J0_t2':j,'n':int(mask.sum()),'common_scale_rms':float(np.sqrt(np.mean(rr**2))),
   'common_scale_sd_scaled_mean_square':float(np.mean((rr/sd[mask])**2)),'separate_scale_diagnostic':ac})
 (OUT/'summary.json').write_text(json.dumps(summary,indent=2))
 print(json.dumps(summary,indent=2),flush=True)

if __name__=='__main__':main()
