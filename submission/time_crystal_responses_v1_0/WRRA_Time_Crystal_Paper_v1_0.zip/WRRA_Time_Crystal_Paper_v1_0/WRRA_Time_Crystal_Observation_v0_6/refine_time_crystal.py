"""Refine device approximation; preserve v0.5's frozen data and split."""
from pathlib import Path
import csv,json,argparse
import numpy as np
from scipy.optimize import minimize,root,minimize_scalar
from compare_observation import extract

OUT=Path('WRRA_Time_Crystal_Observation_v0_6');OUT.mkdir(exist_ok=True)
GROUPS=[.072,.048,.024,.012]

def coupling_matrices(n=10):
 def fun(x):return x-np.array([sum((x[i]-x[j])/abs(x[i]-x[j])**3 for j in range(n) if j!=i) for i in range(n)])
 def energy(x):return .5*sum(x*x)+sum(1/abs(x[j]-x[i]) for i in range(n) for j in range(i+1,n))
 fit=minimize(energy,np.linspace(-3,3,n),jac=fun,method='BFGS',options={'gtol':1e-10})
 pos=np.sort(root(fun,fit.x,tol=1e-11).x)
 # MHz units; common 2*pi factors cancel in normalized coupling ratios.
 axial=.44;transverse=4.8;detuning=.155
 dynamical=transverse**2*np.eye(n)
 for i in range(n):
  for j in range(i+1,n):
   q=axial**2/abs(pos[j]-pos[i])**3
   dynamical[i,i]-=q;dynamical[j,j]-=q;dynamical[i,j]+=q;dynamical[j,i]+=q
 mode_freq2,modes=np.linalg.eigh(dynamical)
 modal=(modes/( (transverse+detuning)**2-mode_freq2))@modes.T
 inverse=np.linalg.inv((transverse+detuning)**2*np.eye(n)-dynamical)
 err=float(abs(modal-inverse).max())
 np.fill_diagonal(modal,0);modal/=max(np.diag(modal,1))
 power=np.zeros((n,n))
 for i in range(n):
  for j in range(i+1,n):power[i,j]=power[j,i]=abs(j-i)**-1.5
 checks={'equilibrium_gradient_max':float(abs(fun(pos)).max()),'mode_inverse_max_error':err,
 'positions_dimensionless':pos.tolist(),'transverse_modes_MHz':np.sqrt(mode_freq2).tolist(),
 'nearest_neighbor_ratios':np.diag(modal,1).tolist(),
 'pair_matrix_rms_difference':float(np.sqrt(np.mean((modal[np.triu_indices(n,1)]-power[np.triu_indices(n,1)])**2)))}
 assert checks['equilibrium_gradient_max']<1e-9 and err<1e-12
 return {'powerlaw':power,'modal_trap':modal},checks

def trace(eps,jphase,matrix,seeds=100):
 n=matrix.shape[0];steps=100;rng=np.random.default_rng(20261023)
 z=1.-2.*((np.arange(2**n)[:,None]>>np.arange(n))&1)
 h=rng.uniform(0,np.pi,(seeds,n));energy=h@z.T
 for i in range(n):
  for j in range(i+1,n):energy+=jphase*matrix[i,j]*(z[:,i]*z[:,j])[None,:]
 diagonal=np.exp(-1j*energy);psi=np.zeros((seeds,2**n),complex);psi[:,0]=1
 c=np.cos(np.pi*(1-eps)/2);s=-1j*np.sin(np.pi*(1-eps)/2)
 out=np.empty((100,seeds,n));norm=0.
 for k in range(100):
  for q in range(n):
   v=psi.reshape(seeds,-1,2,2**q);a=v[:,:,0,:].copy();b=v[:,:,1,:].copy()
   v[:,:,0,:]=c*a+s*b;v[:,:,1,:]=s*a+c*b
  psi*=diagonal;p=abs(psi)**2;out[k]=p@z
  norm=max(norm,float(abs(p.sum(1)-1).max()))
 return out,norm

def stats(pred,y,sd,mask):
 e=(pred-y)[mask];s=sd[mask]
 return {'n':int(mask.sum()),'rms':float(np.sqrt(np.mean(e**2))),
 'mean_sd_scaled_squared_residual':float(np.mean((e/s)**2)),
 'within_1sd':int(np.sum(abs(e)<=s)),'within_2sd':int(np.sum(abs(e)<=2*s))}

def analyze():
 rows=extract();y=np.array([r['observed_height'] for r in rows]);sd=np.array([r['observed_sd'] for r in rows]);g=np.array([r['two_J0_t2'] for r in rows]);train=np.arange(35)%3!=0;hold=~train
 records=[];predictions={}
 for branch in ['powerlaw','modal_trap']:
  tr=np.load(OUT/f'{branch}_traces.npz')['trace']
  feature_cache={}
  # Contrast envelope is an observation model, not a Lindblad evolution.
  # Gamma is common across settings; per-setting contrast follows the original
  # experiment's documented setting dependence. No epsilon-axis remapping.
  def features(gamma):
   key=float(gamma)
   if key not in feature_cache:
    window=np.exp(-gamma*np.arange(1,101))*(-1.)**np.arange(1,101)
    feature_cache[key]=abs(np.einsum('ptsi,t->psi',tr,window)/100).mean((1,2))
   return feature_cache[key]
  for group_scales,damp in [(False,False),(False,True),(True,False),(True,True)]:
   name=f'{branch}_'+('group4' if group_scales else 'common1')+('_envelope' if damp else '')
   def fit(mask):
    def at(gamma):
     x=features(gamma);pred=np.zeros(35);coef=[]
     for group in GROUPS if group_scales else [None]:
      choose=np.ones(35,bool) if group is None else g==group;m=choose&mask
      a=float(np.sum(y[m]*x[m]/sd[m]**2)/np.sum(x[m]**2/sd[m]**2))
      pred[choose]=a*x[choose];coef.append(a)
     return float(np.sum(((pred-y)[mask]/sd[mask])**2)),pred,coef
    if damp:
     fit=minimize_scalar(lambda ga:at(ga)[0],bounds=(0,.08),method='bounded',options={'xatol':1e-7})
     gamma=float(fit.x)
     # Include both explicit boundaries rather than assuming an interior optimum.
     gamma=min([0.,gamma,.08],key=lambda ga:at(ga)[0])
    else:gamma=0.
    loss,pred,coef=at(gamma)
    if damp:
     grid=np.linspace(0,.08,81);losses=np.array([at(ga)[0] for ga in grid]);best=int(losses.argmin())
     local=minimize_scalar(lambda ga:at(ga)[0],bounds=(grid[max(0,best-1)],grid[min(80,best+1)]),method='bounded',options={'xatol':1e-9})
     candidates=[gamma,0.,.08,float(local.x),float(grid[best])]
     gamma=min(candidates,key=lambda ga:at(ga)[0]);loss,pred,coef=at(gamma)
    return gamma,pred,coef
   ga,pred,coef=fit(train);ga_all,pred_all,coef_all=fit(np.ones(35,bool))
   rec={'name':name,'branch':branch,'parameters':(4 if group_scales else 1)+int(damp),
    'train_gamma_per_period':ga,'train_scale_coefficients':coef,
    'training':stats(pred,y,sd,train),'heldout':stats(pred,y,sd,hold),
    'all_at_training_fit':stats(pred,y,sd,np.ones(35,bool)),
    'all_refit_gamma':ga_all,'all_refit_coefficients':coef_all,
    'all_refit':stats(pred_all,y,sd,np.ones(35,bool))}
   records.append(rec);predictions[name]={'training_fit':pred.tolist(),'full_refit':pred_all.tolist()}
 # The setting-dependent contrast model is chosen on physical grounds, before
 # reading held-out errors; all eight candidates are retained.
 (OUT/'model_comparison.json').write_text(json.dumps(records,indent=2))
 (OUT/'predictions.json').write_text(json.dumps(predictions,indent=2))
 for r in records:print(json.dumps(r),flush=True)

def generate():
 matrices,checks=coupling_matrices();rows=extract();(OUT/'coupling_verification.json').write_text(json.dumps(checks,indent=2))
 maxnorm=0
 for branch,matrix in matrices.items():
  np.savetxt(OUT/f'{branch}_coupling_ratios.csv',matrix,delimiter=',')
  path=OUT/f'{branch}_traces.npz'
  if path.exists():continue
  traces=[]
  for idx,r in enumerate(rows):
   t,e=trace(r['epsilon'],r['two_J0_t2']/2,matrix);traces.append(t);maxnorm=max(maxnorm,e)
   print(branch,idx+1,'/35',flush=True)
  np.savez_compressed(path,trace=np.array(traces))
 (OUT/'kernel_verification.json').write_text(json.dumps({'norm_error':maxnorm},indent=2))
 analyze()

if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('--analyze-only',action='store_true');args=parser.parse_args()
 if args.analyze_only:analyze()
 else:generate()
