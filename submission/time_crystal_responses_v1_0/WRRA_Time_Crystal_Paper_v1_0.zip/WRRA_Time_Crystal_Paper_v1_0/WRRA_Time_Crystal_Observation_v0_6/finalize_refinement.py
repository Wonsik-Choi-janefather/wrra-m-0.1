from pathlib import Path
import json,csv,shutil,zipfile
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from compare_observation import extract

p=Path('WRRA_Time_Crystal_Observation_v0_6');rows=extract()
records=json.loads((p/'model_comparison.json').read_text());models={r['name']:r for r in records}
pred=json.loads((p/'predictions.json').read_text());name='modal_trap_group4_envelope';base='powerlaw_common1'
all_refit=np.array(pred[name]['full_refit']);frozen=np.array(pred[name]['training_fit']);before=np.array(pred[base]['full_refit'])
minimal_name='modal_trap_common1_envelope'
minimal=np.array(pred[minimal_name]['full_refit'])
y=np.array([r['observed_height'] for r in rows]);sd=np.array([r['observed_sd'] for r in rows]);g=np.array([r['two_J0_t2'] for r in rows]);hold=np.arange(35)%3==0

out=[]
for i,r in enumerate(rows):
 out.append({**r,'heldout_for_calibration':int(hold[i]),'v05_full_refit':before[i],
 'v06_full_refit':all_refit[i],'v06_minimal_two_parameter_fit':minimal[i],'v06_frozen_training_fit':frozen[i],
 'v06_full_refit_residual_over_sd':(all_refit[i]-y[i])/sd[i],
 'v06_frozen_residual_over_sd':(frozen[i]-y[i])/sd[i]})
with (p/'comparison_residuals.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=list(out[0]));w.writeheader();w.writerows(out)

fig,axes=plt.subplots(2,2,figsize=(10,7),sharex=True,sharey=True)
for ax,j in zip(axes.flat,[.072,.048,.024,.012]):
 m=g==j;x=np.array([r['epsilon'] for r in rows])[m]
 ax.errorbar(x,y[m],yerr=sd[m],fmt='o',color='#25354a',ms=4,capsize=3,label='Published observations +/-1 SD')
 ax.plot(x,before[m],':',color='#9b9fa7',lw=2,label='v0.5: common scale (1 parameter)')
 ax.plot(x,all_refit[m],'-s',color='#bc6425',ms=3,label='v0.6: device correction (5 parameters)')
 ax.plot(x,minimal[m],'--',color='#277f7b',lw=1.4,label='v0.6: shared device decay (2 parameters)')
 xx=np.array([r['epsilon'] for r in rows]);mhold=m&hold
 ax.scatter(xx[mhold],y[mhold],s=62,facecolors='none',edgecolors='#25354a',lw=1)
 ax.set_title(f'2 J0 t2 = {j:.3f}');ax.grid(alpha=.18);ax.set_ylim(0,.10);ax.set_xlim(0,.12)
for ax in axes[-1]:ax.set_xlabel('Fractional pulse error epsilon')
for ax in axes[:,0]:ax.set_ylabel('Central Fourier peak height (a.u.)')
axes[0,0].legend(fontsize=6.8)
fig.suptitle('Time-crystal observation comparison: device refinement',fontsize=14)
fig.text(.5,.015,'Full-data refits shown; open rings mark reused holdouts. Device contrasts and decay are calibrated, not independently measured.',ha='center',fontsize=8)
fig.tight_layout(rect=[0,.04,1,.95]);fig.savefig(p/'refined_comparison.png',dpi=180);plt.close(fig)

selected=models[name];baseline=models[base]
mini=models[minimal_name]
summary={'baseline_full_rms':baseline['all_refit']['rms'],'refined_full_rms':selected['all_refit']['rms'],
 'full_rms_reduction_percent':100*(1-selected['all_refit']['rms']/baseline['all_refit']['rms']),
 'baseline_heldout_rms':baseline['heldout']['rms'],'refined_heldout_rms':selected['heldout']['rms'],
 'heldout_rms_reduction_percent':100*(1-selected['heldout']['rms']/baseline['heldout']['rms']),
 'full_refit_within_2sd_before':baseline['all_refit']['within_2sd'],
 'full_refit_within_2sd_after':selected['all_refit']['within_2sd'],
 'heldout_within_2sd_before':baseline['heldout']['within_2sd'],
 'heldout_within_2sd_after':selected['heldout']['within_2sd'],
 'fitted_envelope_1e_time_ms_from_training':[.074/selected['train_gamma_per_period'],.075/selected['train_gamma_per_period']],
 'largest_frozen_holdout_sd_residual':float(max(abs((frozen-y)[hold]/sd[hold]))),
 'minimal_two_parameter_full_rms':mini['all_refit']['rms'],
 'minimal_two_parameter_heldout_rms':mini['heldout']['rms'],
 'minimal_two_parameter_heldout_rms_reduction_percent':100*(1-mini['heldout']['rms']/baseline['heldout']['rms']),
 'minimal_two_parameter_heldout_sd_squared_reduction_percent':100*(1-mini['heldout']['mean_sd_scaled_squared_residual']/baseline['heldout']['mean_sd_scaled_squared_residual']),
 'note':'Five-parameter branch improves raw RMS; the two-parameter branch is better on SD-weighted holdout error. Holdouts were reused during model exploration.'}
(p/'refinement_summary.json').write_text(json.dumps(summary,indent=2))
for f in ['refine_time_crystal.py','finalize_refinement.py','compare_observation.py','source_involution_check.py']:
 shutil.copy(f,p/f)
(p/'requirements.txt').write_text('numpy\nscipy\nmatplotlib\nPyMuPDF\n')
print(json.dumps(summary,indent=2))
