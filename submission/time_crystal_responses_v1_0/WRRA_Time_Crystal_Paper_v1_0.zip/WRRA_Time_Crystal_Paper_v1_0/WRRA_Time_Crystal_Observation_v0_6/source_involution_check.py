"""Reconstruct MCC 3.0 v0.28-r6 section 139.4 from its published formula."""
import json
import numpy as np
from scipy.linalg import expm

def verify():
 # Explicit serialization, newly specified for this implementation.
 address=lambda mode,supply,record:(mode*2+supply)*2+record
 a=address(8,1,0);b=address(72,0,1);d=128*2*2
 G=np.eye(d);G[a,a]=G[b,b]=0;G[a,b]=G[b,a]=1
 Pminus=(np.eye(d)-G)/2
 # Unitless H*tau/hbar, following section 139.4.
 generator=np.pi*Pminus
 U=np.eye(d)-2*Pminus
 V=np.eye(d)[:,[a,b]]
 X=np.array([[0.,1.],[1.,0.]])
 Z=np.diag([1.,-1.]);Zsource=V@Z@V.T
 defects={}
 for delta in [0,.001,.01,.05]:
  w=1+delta
  # Active two-state diagonalization; full 512-state complement is identity.
  active=expm(-1j*np.pi*w/2*np.array([[1,-1],[-1,1]]))
  psi=np.array([1.,0.],complex);trace=[]
  for k in range(1,513):
   psi=active@psi;trace.append(float(abs(psi[0])**2-abs(psi[1])**2))
  k=np.arange(1,513);analytic=np.cos(np.pi*w*k)
  defects[str(delta)]={'tail_M2':float(np.mean(np.array(trace)[256:]*(-1.)**k[256:])),
    'analytic_error':float(np.max(abs(np.array(trace)-analytic)))}
 # The full source involution is checked without diagonalizing irrelevant states.
 result={'source_dimension':d,'active_indices':[a,b],
 'G_squared_error':float(abs(G@G-np.eye(d)).max()),
 'U_equals_G_error':float(abs(U-G).max()),
 'generator_commutes_with_G_error':float(abs(generator@G-G@generator).max()),
 'logical_exchange_intertwiner_error':float(abs(G@V-V@X).max()),
 'logical_readout_intertwiner_error':float(abs(Zsource@V-V@Z).max()),
 'active_subspace_leakage_error':float(abs((np.eye(d)-V@V.T)@G@V).max()),
 'rate_error_controls':defects,
 'note':'Defective isolated G is a coherent oscillator, without robust locking.'}
 assert result['G_squared_error']==0 and result['U_equals_G_error']==0
 assert max(x['analytic_error'] for x in defects.values())<1e-10
 return result

if __name__=='__main__':print(json.dumps(verify(),indent=2))
