from pathlib import Path
import csv,json,html
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from weasyprint import HTML

ROOT=Path(__file__).resolve().parent
DATA=ROOT/'WRRA_Time_Crystal_Observation_v0_6'
OUT=ROOT/'publication';OUT.mkdir(exist_ok=True)
DOI='10.5281/zenodo.23585846'
MODELS={r['name']:r for r in json.loads((DATA/'model_comparison.json').read_text())}
VERIFY=json.loads((DATA/'REVALIDATION.json').read_text())

def table(headers,rows):
 return '<table><thead><tr>'+''.join('<th>'+str(a)+'</th>' for a in headers)+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+str(a)+'</td>' for a in row)+'</tr>' for row in rows)+'</tbody></table>'
def p(s):return '<p>'+s+'</p>'
def eq(s,num):return f'<div class="eq">{s}<span>({num})</span></div>'
def section(n,title,body):return f'<section><div class="running">WRRA time-crystal responses · v1.0 · 23 October 2026</div><h2>{n}. {title}</h2>{body}</section>'

CSS='''
@font-face {font-family:Noto;src:url(file:///usr/local/share/fonts/noto/NotoSansCJKkr-Regular.otf)}
@page {size:A4;margin:19mm 19mm 18mm; @bottom-left{content:"Wonsik Choi";font-size:8pt;color:#65717c} @bottom-right{content:counter(page);font-size:8pt;color:#65717c}}
*{box-sizing:border-box}body{font-family:Noto,sans-serif;color:#17222d;font-size:9.3pt;line-height:1.48;margin:0}
section{break-before:page}section:first-of-type{break-before:auto}.running{font-size:8pt;letter-spacing:.2pt;color:#70808a;margin-bottom:12pt}
h1{font-size:22pt;line-height:1.32;color:#142e44;margin:17pt 0 12pt;font-weight:500}h2{font-size:15pt;line-height:1.35;color:#142e44;margin:0 0 13pt}h3{font-size:10.8pt;color:#142e44;margin:15pt 0 5pt}
p{margin:0 0 9pt;text-align:justify;orphans:3;widows:3}.authors{font-size:12pt;margin:0 0 4pt}.meta{color:#536473;font-size:8.5pt;line-height:1.6;margin-bottom:14pt}.abstract{background:#f1f5f7;padding:13pt 15pt;margin:14pt 0}
.abstract h3{margin:0 0 6pt}.abstract p:last-child{margin-bottom:0}table{border-collapse:collapse;width:100%;font-size:8.4pt;line-height:1.5;margin:12pt 0}th{background:#eaf0f4;color:#142e44;font-weight:500;text-align:left}th,td{padding:6pt 7pt;border-bottom:.5pt solid #d4dce2;vertical-align:top}thead{display:table-header-group}tr{break-inside:avoid}
.eq{font-family:Noto,sans-serif;background:#f7f8fa;padding:9pt 12pt;margin:10pt 0;font-size:10pt;line-height:1.55;break-inside:avoid}.eq span{float:right;color:#687786;margin-left:10pt}.caption{font-size:8pt;line-height:1.5;color:#4b5c6b;margin:5pt 0 10pt}img{max-width:100%;height:auto} .references{font-size:8.4pt;line-height:1.5}.references p{margin-bottom:7pt;word-break:break-word}a{color:#205b80;text-decoration:none}.small{font-size:8.6pt}.callout{border-left:3pt solid #396a85;padding:7pt 12pt;background:#f4f7f8;margin:10pt 0}.language{string-set:lang content()}.code{font-family:monospace;white-space:pre-wrap;font-size:8pt;background:#f3f5f6;padding:9pt}
'''

def make_figures():
 t=json.loads((DATA/'finite_response_traces.json').read_text());fig,axes=plt.subplots(1,2,figsize=(9.5,3.2))
 for key,color,label in [('0','#8c97a3','No interactions'),('0.8','#286d85','Interacting J0=0.8')]:
  a=np.array(t[key]);n=np.arange(1,len(a)+1)
  axes[0].plot(n[:28],a[:28],'.-',lw=1,color=color,label=label)
  axes[1].plot(n,(-1.)**n*a,lw=.9,color=color,label=label)
 axes[0].set(xlabel='Drive periods',ylabel='Initial-state correlation C(n)',title='Period doubling in the raw observable')
 axes[1].set(xlabel='Drive periods',ylabel='Staggered memory',title='Finite-time stability under pulse error')
 for ax in axes:ax.grid(alpha=.2);ax.legend(fontsize=7)
 fig.tight_layout();fig.savefig(OUT/'finite_response.png',dpi=170);plt.close(fig)
 # Figure 2 is regenerated from the independently replayed observation model.
 import sys
 sys.path.insert(0,str(ROOT))
 # Finalization script resolves paths relative to cwd, which is ROOT.
 import runpy
 runpy.run_path(str(ROOT/'finalize_refinement.py'),run_name='__main__')
 import shutil
 shutil.copy(DATA/'refined_comparison.png',OUT/'observation_comparison.png')

def result_table(ko=False):
 keys=['powerlaw_common1','modal_trap_common1_envelope','modal_trap_group4_envelope']
 labels=['이전 모형','공통 감쇠 보강','설정별 장치 보강'] if ko else ['Reference','Shared-decay extension','Setting-dependent extension']
 return table(['모형','계수','전체 RMS','보류 RMS','보류 SD²'] if ko else ['Model','k','Full RMS','Held RMS','Held SD²'],[[label,MODELS[key]['parameters'],f"{MODELS[key]['all_refit']['rms']:.6f}",f"{MODELS[key]['heldout']['rms']:.6f}",f"{MODELS[key]['heldout']['mean_sd_scaled_squared_residual']:.3f}"] for label,key in zip(labels,keys)])

def references(ko=False):
 return '<div class="references">'+''.join(p(x) for x in [
 '[1] J. Zhang et al. Observation of a discrete time crystal. <i>Nature</i> 543, 217–220 (2017). <a href="https://doi.org/10.1038/nature21413">doi:10.1038/nature21413</a>. Published Fig. 4 and Methods; preprint arXiv:1609.08684v1 for the trap-frequency specification.',
 '[2] N. Y. Yao, A. C. Potter, I.-D. Potirniche and A. Vishwanath. Discrete Time Crystals: Rigidity, Criticality, and Realizations. <i>Phys. Rev. Lett.</i> 118, 030401 (2017). <a href="https://doi.org/10.1103/PhysRevLett.118.030401">doi:10.1103/PhysRevLett.118.030401</a>.',
 '[3] W. Choi and J. Choi. <i>Minimal Computing Cosmology 3.0</i>, v0.28-r6 (2026), §§6, 95, 112–113, 135.9–11 and 139.4. <a href="https://doi.org/10.5281/zenodo.23551789">doi:10.5281/zenodo.23551789</a>. The current Library manuscript and public repository release metadata were consulted.',
 f'[4] W. Choi. This paper and reproducibility package, v1.0. <a href="https://doi.org/{DOI}">doi:{DOI}</a>.'
 ])+'</div>'

def english():
 pages=[]
 title='A WRRA Implementation of Period-Doubled Time-Crystal Responses'
 b='<div class="language small">English edition</div><h1>'+title+'</h1><p style="font-size:14pt;color:#526675">Finite SOURCE Exchange and Observation-Level Comparison</p>'
 b+='<div class="authors">Wonsik Choi</div><div class="meta">Independent Researcher, Seoul, Republic of Korea<br>Wonsik Choi ORCID: 0009-0001-4263-9772<br>Version 1.0 · 23 October 2026 · DOI: '+DOI+'</div>'
 b+='<div class="abstract"><h3>Abstract</h3>'+p('We construct a conditional WRRA implementation of finite-time, period-doubled time-crystal responses. A registered 512-state SOURCE exchange is reduced by an exact transition-and-readout-preserving map to a two-state block. Coupled blocks reproduce a response at half the drive frequency that survives pulse errors over the tested time window. The isolated exchange is explicitly shown not to provide error-robust locking. We then compare the fixed model with 35 aggregate experimental points extracted from a published trapped-ion time-crystal experiment. Reconstructed trap-mode couplings and an observation-level contrast envelope reduce the full-data RMS discrepancy from 0.007445 to 0.003493 with five calibration parameters. A smaller two-parameter extension improves the reused held-point RMS by 23.38% and its SD-normalized residual by 38.76%. Residual disagreement and the increase in calibration freedom are retained. The result is an implemented structural explanation and a finite-time observational comparison, not a proof of an asymptotic time-crystal phase or a complete device reconstruction.')+'</div>'
 b+=table(['Evaluation stage','Content'],[['Validated input','WRRA registered exchange; published experiment and device settings'],['WRRA-specific transformation','Exact block compilation; fixed conditional coupling and readout'],['Output','Finite-time subharmonic rigidity and explicit observation residuals'],['Falsification condition','Loss of locking or persistent residuals under frozen device inputs']])
 pages.append('<section><div class="running">Research preprint · '+DOI+'</div>'+b+'</section>')
 b=p('WRRA is used here as an execution and ownership architecture: a specified finite state, legal transition and observable must be connected by an actual computation [3]. Observed constants and interactions are legitimate inputs to the renderer. The contribution is the explicit SOURCE-to-response compilation and its audited comparison, rather than the first discovery of the established spin Hamiltonian [1,2].')
 b+=eq('A = |8,1,0⟩,  B = |72,0,1⟩;  G A = B,  G B = A;  G² = I.','1')
 b+=p('The state space has dimension 128 × 2 × 2 = 512. G is the identity on the other basis states. With V|0⟩ = A and V|1⟩ = B, and Z<sub>S</sub> = |A⟩⟨A| − |B⟩⟨B|, the exact identities are')
 b+=eq('G V = V X,   Z<sub>S</sub> V = V Z,   (I − VV†) G V = 0.','2')
 b+=eq('H<sub>G</sub> = πℏ(I − G)/(2τ),   exp(−iH<sub>G</sub>τ/ℏ) = G.','3')
 b+=p('These are reconstructed from §139.4 of [3]. They preserve the selected transition and observable, not every arbitrary 512-state history. The active product space of N blocks is exactly closed under the declared local pulses and diagonal pair couplings; it therefore uses 2<sup>N</sup> complex amplitudes. This is a restricted-state compilation, not a compression theorem for unrestricted SOURCE states.')
 b+=eq('U<sub>F</sub> = exp[−i(∑<sub>i&lt;j</sub> J<sub>ij</sub>Z<sub>i</sub>Z<sub>j</sub> + ∑<sub>i</sub>h<sub>i</sub>Z<sub>i</sub>)]<br>× exp[−i(π−δ)∑<sub>i</sub>X<sub>i</sub>/2].','4')
 b+=p('J and h in Eq. (4) are integrated, dimensionless phases. The SOURCE pulse generated by I−G has the opposite X-rotation sign up to a global phase; a fixed Z basis change yields Eq. (4) while preserving the diagonal coupling, initial Z-product states and Z readout. This equivalence is independently checked with matrix exponentials. Couplings are declared inputs, not constants newly derived from G.')
 b+=p('The 15-channel transport space in §6 of [3] is not identified with the 15 Pauli components of a two-qubit operator. The SOURCE exchange, material spin, transport channel and matter–antimatter output label remain distinct objects. No observed laboratory period is equated with a universal fundamental clock.')
 pages.append(section(1,'Finite exchange and the compiled dynamics',b))
 b=p('An exact exchange alternates A and B and returns after two pulses. That alone is insufficient for a time-crystal response: an isolated imperfect exchange gives C(n)=cos[π(1+η)n] and its frequency follows the pulse error η. The interacting control asks whether a nonzero error interval retains a peak at 1/(2T), without forcing the observed states to alternate in the propagation code.')
 b+=p('The finite-response audit uses N=10, 16 fixed random product-state/disorder samples, h∈[−π,π], nearest-neighbor J<sub>i</sub>∈[0.8J<sub>0</sub>,1.2J<sub>0</sub>], and 512 periods. This is the mechanism-control branch, separate from the experiment-parameter branch below. Define C(n) as the average initial-state spin correlation; M₂ is the signed average of (−1)<sup>n</sup>C(n) over the final half-window.')
 records=list(csv.DictReader((DATA/'finite_response_replay.csv').open()));rs=[]
 for delta in [.05,.1,.2,.3]:
  a=next(r for r in records if float(r['epsilon_rad'])==delta and float(r['j0'])==0 and int(r['steps'])==512)
  c=next(r for r in records if float(r['epsilon_rad'])==delta and float(r['j0'])==.8 and int(r['steps'])==512)
  rs.append([delta,f"{float(a['tail_signed_memory']):.6f}",f"{float(c['tail_signed_memory']):.6f}",c['peak_cycles_per_T']])
 b+=table(['δ (rad)','M₂, uncoupled','M₂, interacting','Peak × T'],rs)
 b+='<img src="finite_response.png"><div class="caption">Figure 1. Raw period doubling and staggered memory for δ=0.1 rad. Interaction removes the long-time dephasing seen in the uncoupled control over the tested window. Averaging the observable does not impose a 2T trajectory on the state.</div>'
 b+=p('At δ=0.1 rad, extending the run to 2,048 periods gives M₂=0.634400 with interactions and −0.006857 without them. The subharmonic peak remains at 0.5 cycles/T in the interacting case. This finite-chain, finite-time signature supports the claimed response reproduction. Thermodynamic-limit order, infinite lifetime and many-body localization are not proved by this calculation.')
 pages.append(section(2,'Finite-time response and negative controls',b))
 b=p('For the observation-level comparison, Fig. 4 of [1] supplies 35 plotted central-peak heights and their displayed ±1 SD bars. Values are recovered from vector error bars in the publisher PDF; independent marker centers agree within 0.00201 PDF points. These are published aggregate observations, not individual experimental shots. The input PDF is identified by its SHA-256 hash in the package.')
 b+=table(['Frozen input','Value or convention'],[['System and window','10 aligned initial spins; 100 periods'],['Pulse error','Fractional ε; rotation angle π(1−ε), so δ=πε'],['Coupling labels','2J₀t₂ = 0.072, 0.048, 0.024, 0.012'],['Pair counting','Each unordered pair once; coefficient J₀t₂'],['Disorder','Integrated fields uniform on [0,π]; 100 fixed samples'],['Reference shape','|i−j|<sup>−1.5</sup>; seed 20261023'],['Calibration split','23 points; original indices not divisible by 3'],['Reused held points','12 points; indices 0,3,6,…,33']])
 b+=p('A fixed spin-axis rotation maps the laboratory observable to the compiled Z readout. The apparatus uses a drive period of about 74–75 μs. The selected SOURCE clock is not inferred from this period. The experiment’s exact disorder realizations and measured 45 pair couplings are unavailable here; the calculation samples the reported distribution and approximates the device couplings.')
 b+=eq('P<sub>g</sub>(ε) = s<sub>g</sub> ⟨ |100<sup>−1</sup> ∑<sub>n=1</sub><sup>100</sup> e<sup>−γn</sup>(−1)<sup>n</sup>C<sub>i</sub>(n)| ⟩<sub>samples,i</sub>.','5')
 b+=p('For device reconstruction, equilibrium positions minimize a harmonic-trap plus Coulomb energy. With transverse dynamical matrix A, the normalized pair-coupling shape is the off-diagonal part of [(f<sub>x</sub>+Δ)<sup>2</sup>I−A]<sup>−1</sup>, equivalent to the normal-mode sum in [1]. Inputs are f<sub>x</sub>=4.8 MHz, f<sub>z</sub>=0.44 MHz and Δ=0.155 MHz from the preprint Methods. Uniform optical forcing and an ideal straight harmonic-trap chain are assumptions, not measured apparatus details.')
 b+=p('Eq. (5) adds a phenomenological observation-contrast envelope. It is not a Lindblad simulation or a derivation of microscopic leakage. The minimal extension has common s and γ; the setting-dependent extension has four s<sub>g</sub> and one γ. All eight combinations of two coupling shapes and four observation models are retained. Gamma is scanned on 81 grid points over [0,0.08] per period and refined locally. No ε-axis shift, coupling refit, discarded point or inflated error bar is used.')
 pages.append(section(3,'Published observations and device model',b))
 b=p('Calibration uses the displayed SD as weights. The table separates refitting all 35 points from predicting the 12 reused held points after fitting only the other 23. “Held SD²” denotes the mean squared residual divided by the displayed SD; it is a diagnostic, not a formal χ² test.')
 b+=result_table()
 b+='<img src="observation_comparison.png"><div class="caption">Figure 2. Published aggregate observations and full-data refits. Grey: one-parameter reference; teal: two-parameter shared-decay extension; orange: five-parameter setting-dependent extension. Open rings identify the reused held points, but the curves displayed here are full-data refits.</div>'
 b+=p('The five-parameter extension reduces full-data RMS by 53.08% and reused held-point RMS by 28.38%. The displayed ±2 SD count rises from 23/35 to 32/35 for full-data refits, and from 8/12 to 11/12 for held points. The two-parameter extension reduces held RMS by 23.38% and held SD² by 38.76%; it is the primary minimal device extension. The five-parameter branch is reported as a more flexible setting-conditioned comparison.')
 b+=p('The data split has been reused during exploration and is not an untouched external test. Calibration freedom increases from one to two or five parameters. Correlated uncertainties and individual shots are unavailable, so coverage counts are descriptive. They do not establish a universal pass threshold.')
 pages.append(section(4,'Observation-level results',b))
 b=p('A substantial residual remains. At 2J₀t₂=0.072 and ε=0.01, the observation is 0.072563±0.002301. The five-parameter model fitted to the other 23 points yields 0.060240 (−5.35 displayed SD); refitting all 35 gives 0.065467 (−3.08 SD). This small-error point lies outside the same setting’s calibration ε-range. Nevertheless, its remaining full-refit residual cannot be attributed to extrapolation alone.')
 b+=p('Conversely, at the same coupling and ε=0.03, the full-refit discrepancy decreases from about +7.56 SD to +2.47 SD. Thus narrowing the aggregate mismatch does not make every observation consistent. The five-parameter held SD² is 2.854, slightly worse than the reference 2.603, despite its lower raw RMS. This is why the smaller extension is retained separately.')
 b+=p('Device-input mismatch, unknown disorder realizations and the simplified contrast envelope are plausible explanations, not uniquely identified causes. The data do not establish that WRRA dynamics is exempt from revision. Nor does disagreement in this particular device approximation invalidate every WRRA module. The measured pair matrix, actual disorder arrays and time-resolved contrast would discriminate these possibilities.')
 b+='<h3>Falsification and revision conditions</h3>'+table(['Target','Failure or revision trigger'],[['Compiled SOURCE map','Transition/readout identities or active-space closure fail'],['Finite response','Peak follows pulse error or memory decays over the claimed window'],['Frozen observation model','Residuals persist after matched apparatus inputs and uncertainties'],['Device-loss interpretation','A fitted envelope conflicts with measured time-resolved contrast'],['Expanded claim','No asymptotic-phase claim without the required size/time analysis']])
 b+='<h3>Revalidation and reproducibility</h3>'+p(f'A fresh, isolated replay of both coupling branches was followed by {VERIFY["passed"]}/{VERIFY["total"]} internal verification families. These cover SOURCE algebra and readout, pulse-basis equivalence, coupled/uncoupled controls, trap equilibrium and resolvent, independent dense propagation, preserved observations, full reference replay, independent calibration normal equations, probability norms, source-PDF identity and all optimizer bounds. The independent dense propagation differs by at most 2.47×10<sup>−14</sup>. These checks are not external peer review.')
 b+=p('The archive contains bilingual PDFs, source scripts, all model comparisons, extracted observations, residuals, figures, checksums and a verification report. The third-party publisher PDF is fetched separately and not redistributed. AI assistance was used in implementation, checking and manuscript preparation. The code exposes all declared inputs and calibration choices.')
 b+='<h3>Conclusion</h3>'+p('The SOURCE-to-response implementation reproduces finite-time period-doubled rigidity and supports a quantitative, partly successful observation-level explanation. Calibrated device refinements reduce the mismatch. Remaining residuals, unresolved device identity and unproved asymptotic-phase claims are explicitly retained.')
 pages.append(section(5,'Residuals, falsification and reproducibility',b))
 b=references()+p('Reproduction starts from an empty workspace with the supplied scripts and the separately obtained publisher PDF. The paper’s SOURCE construction is taken from the current §139.4 of [3]; its actual numerical reconstruction is in source_involution_check.py.')
 b+='<div class="code">python refine_time_crystal.py\npython verify_release.py\npython finalize_refinement.py\npython write_paper.py</div>'
 b+=p('Required packages: NumPy, SciPy, PyMuPDF, Matplotlib and WeasyPrint. Paper generation uses the Noto Sans CJK Korean font. Intermediate trajectories can be regenerated; published numerical tables are included. The DOI identifies this version and its associated computational record.')
 pages.append(section(6,'References and execution record',b))
 return title,''.join(pages)

def korean():
 pages=[];title='주기배가 시간결정 반응의 WRRA 구현과 관측 대조'
 b='<div class="language small">한글판</div><h1>'+title+'</h1><p style="font-size:14pt;color:#526675">유한 SOURCE 교환에서 장치 감쇠까지</p><div class="authors">최원식</div><div class="meta">독립연구자 · 대한민국 서울<br>최원식 ORCID: 0009-0001-4263-9772<br>버전 1.0 · 2026년 10월 23일 · DOI: '+DOI+'</div>'
 b+='<div class="abstract"><h3>초록</h3>'+p('WRRA에 등록된 512상태 SOURCE 교환을 출발점으로, 전이와 판독을 정확히 보존하는 두 상태 부분공간을 구성한다. 여러 블록에 명시한 상호작용을 적용하면 유한 관측시간 동안 구동 주기의 두 배로 반복하고 일정한 자극 오차에도 주파수가 고정되는 반응이 재현된다. 교환 연산 하나만으로는 오차에 견고한 주기 고정이 성립하지 않는다는 음성 대조도 제시한다. 이어 이온 시간결정 실험의 집계 관측점 35개와 대조한다. 트랩 모드 결합과 관측 대비의 감쇠를 보강한 5계수 모형은 전체 RMS 차이를 0.007445에서 0.003493으로 줄였다. 더 작은 2계수 모형도 기존 보류점 RMS를 23.38%, SD 정규화 잔차를 38.76% 줄였다. 보정 자유도 증가, 재사용 보류점 및 남은 불일치를 함께 공개한다. 성과는 구조적 설명의 실제 구현과 유한 시간 관측 대조이며, 열역학적 극한의 시간결정 상이나 실제 장치 전체를 재현했다는 주장은 아니다.')+'</div>'
 b+=table(['판정 순서','논문에서 실행한 내용'],[['검증 입력','원문의 SOURCE 교환, 공개 실험과 장치 조건'],['WRRA 고유 변환','전이·판독 보존 축약, 고정 결합·관측기 연결'],['산출값','유한 시간 주기 고정과 관측 잔차'],['반증조건','반복 질서 소실 또는 고정 장치 입력에서 지속되는 불일치']])
 pages.append('<section><div class="running">연구 사전공개 논문 · '+DOI+'</div>'+b+'</section>')
 b=p('WRRA는 명세한 현재 상태와 허용 전이, 관측량이 하나의 실제 실행으로 연결돼야 한다는 구조로 사용한다[3]. 검증된 상수와 상호작용은 해석기를 구성하는 정당한 입력이다. 이번 독창성의 평가 대상은 기존 스핀 해밀토니언[1,2]의 최초 발견이 아니라, SOURCE의 교환을 반응으로 연결하는 구체적인 변환과 그 계산·관측 검수다.')
 b+=eq('A = |8,1,0⟩,  B = |72,0,1⟩;  G A = B,  G B = A;  G² = I.','1')
 b+=p('전체 차원은 128×2×2=512이며, G는 나머지 기저 상태를 유지한다. V|0⟩=A, V|1⟩=B, Z<sub>S</sub>=|A⟩⟨A|−|B⟩⟨B|로 두면 다음 항등식이 성립한다.')
 b+=eq('G V = V X,   Z<sub>S</sub> V = V Z,   (I − VV†) G V = 0.','2')
 b+=eq('H<sub>G</sub> = πℏ(I − G)/(2τ),   exp(−iH<sub>G</sub>τ/ℏ) = G.','3')
 b+=p('이 구성은 [3]의 139.4절을 실제 512차원 연산으로 재구성한 것이다. 선택한 전이와 판독을 보존하며 모든 임의의 SOURCE 이력을 압축한다는 뜻이 아니다. N개 블록의 활성 곱부분공간은 선언한 국소 펄스와 대각 결합 아래 닫혀 있으므로 2<sup>N</sup> 복소 진폭으로 계산할 수 있다.')
 b+=eq('U<sub>F</sub> = exp[−i(∑<sub>i&lt;j</sub> J<sub>ij</sub>Z<sub>i</sub>Z<sub>j</sub> + ∑<sub>i</sub>h<sub>i</sub>Z<sub>i</sub>)]<br>× exp[−i(π−δ)∑<sub>i</sub>X<sub>i</sub>/2].','4')
 b+=p('J와 h는 시간 적분을 포함한 무차원 위상이다. I−G가 만드는 펄스의 X 회전 부호는 전역 위상과 고정된 Z 기저변환으로 식 (4)에 옮길 수 있다. 대각 결합·초기 Z 곱상태·Z 판독의 상관도는 보존된다. 이 관계는 별도의 행렬지수 계산으로 검산했다. 결합은 공개한 입력이며 G에서 새로 도출한 자연 상수가 아니다.')
 b+=p('원문 6장의 15채널 전달 공간을 두 큐비트의 15개 Pauli 성분과 동일시하지 않는다. SOURCE 교환, 물질 스핀, 전달 채널과 물질·반물질 출력 라벨은 각각의 소유 대상을 유지한다. 실험 주기를 우주의 유일한 기본 클럭과 동일시하지도 않는다.')
 pages.append(section(1,'유한 교환과 전이·판독 보존 구현',b))
 b=p('완전한 교환은 A와 B를 번갈아 거쳐 두 번 뒤에 복귀한다. 그러나 이것만으로 시간결정의 견고함이 성립하지 않는다. 고립된 교환에 위상 오차 η를 주면 C(n)=cos[π(1+η)n]이 되어 반복 주파수가 오차를 따라 움직인다. 결합 대조에서는 실제 상태 전이에 교대를 강제하지 않은 채, 유한한 오차 구간에서 1/(2T) 성분이 유지되는지 검사한다.')
 b+=p('기작 대조는 N=10, 고정된 초기 곱상태·무질서 표본 16개, h∈[−π,π], 최근접 J<sub>i</sub>∈[0.8J<sub>0</sub>,1.2J<sub>0</sub>], 512주기를 사용한다. 이 분기는 다음 절의 실험 조건 분기와 별개다. C(n)은 초기 스핀 방향에 대한 평균 상관도이며 M₂는 마지막 절반 구간의 (−1)<sup>n</sup>C(n)을 부호 그대로 평균한 값이다.')
 records=list(csv.DictReader((DATA/'finite_response_replay.csv').open()));rs=[]
 for delta in [.05,.1,.2,.3]:
  a=next(r for r in records if float(r['epsilon_rad'])==delta and float(r['j0'])==0 and int(r['steps'])==512);c=next(r for r in records if float(r['epsilon_rad'])==delta and float(r['j0'])==.8 and int(r['steps'])==512)
  rs.append([delta,f"{float(a['tail_signed_memory']):.6f}",f"{float(c['tail_signed_memory']):.6f}",c['peak_cycles_per_T']])
 b+=table(['δ (rad)','무결합 M₂','결합 M₂','피크 × T'],rs)
 b+='<img src="finite_response.png"><div class="caption">그림 1. δ=0.1 rad에서의 원 상관도와 교대 기억. 결합이 있을 때 검사한 시간 동안 반복 질서가 유지된다. 관측량의 평균과 교대 성분 분석은 상태의 궤적 자체에 2T를 강제하는 연산이 아니다.</div>'
 b+=p('δ=0.1 rad에서 2,048주기로 연장하면 결합 M₂는 0.634400, 무결합은 −0.006857이다. 결합 분기의 피크는 0.5 cycles/T에 남는다. 이는 유한 계·유한 시간에서의 핵심 반응 재현 성과다. 열역학적 극한의 질서, 무한 수명이나 다체 국소화 자체를 이 계산으로 증명하지 않는다.')
 pages.append(section(2,'유한 시간 반응과 음성 대조',b))
 b=p('관측 대조는 [1]의 그림 4에서 중앙 피크 높이 35개와 표시된 ±1 SD를 사용한다. 출판 PDF의 벡터 오차막대를 좌표 변환했으며 독립 마커 중심과의 최대 차이는 0.00201 PDF point다. 이는 공개된 집계 관측값이며 개별 검출 원자료는 아니다. 입력 PDF의 SHA-256 해시를 함께 보존한다.')
 b+=table(['고정 입력','값과 규약'],[['계와 관측창','같은 방향 초기 스핀 10개, 100주기'],['펄스 오차','상대 오차 ε, 회전각 π(1−ε), δ=πε'],['결합 표지','2J₀t₂ = 0.072, 0.048, 0.024, 0.012'],['쌍 합산','무순서 쌍마다 한 번, 계수는 J₀t₂'],['무질서','누적 위상 [0,π] 균등분포, 고정 표본 100개'],['기준 결합','|i−j|<sup>−1.5</sup>, 난수 시드 20261023'],['보정·재사용 보류','순번을 3으로 나눈 나머지가 0이 아닌 23점 / 나머지 0인 12점']])
 b+=p('고정된 스핀 축 회전으로 실험 판독을 구현의 Z 판독에 옮긴다. 장치 구동 주기는 약 74–75 μs이며 그 값으로 SOURCE의 근본 셔터를 추정하지 않는다. 실제 실험의 특정 무질서 배열과 측정된 45개 결합값은 확보하지 못했으므로 공개 분포와 장치 근사를 사용한다.')
 b+=eq('P<sub>g</sub>(ε) = s<sub>g</sub> ⟨ |100<sup>−1</sup> ∑<sub>n=1</sub><sup>100</sup> e<sup>−γn</sup>(−1)<sup>n</sup>C<sub>i</sub>(n)| ⟩<sub>표본,i</sub>.','5')
 b+=p('트랩 모드 결합은 조화 트랩과 쿨롱 에너지의 평형 위치에서 횡방향 행렬 A를 계산한 뒤, [(f<sub>x</sub>+Δ)<sup>2</sup>I−A]<sup>−1</sup>의 비대각 성분을 정규화해 얻는다. 이는 [1]의 정상모드 합과 같은 선형대수 표현이다. 프리프린트 방법 절의 f<sub>x</sub>=4.8 MHz, f<sub>z</sub>=0.44 MHz, Δ=0.155 MHz를 사용한다. 균일 광학 구동과 이상적인 직선 조화 트랩은 명시한 가정이다.')
 b+=p('식 (5)의 감쇠는 관측 대비의 현상론적 포락선이다. Lindblad 잡음이나 원자 준위 누설의 미시모형으로 부르지 않는다. 최소 보강은 공통 s와 γ의 2계수, 설정별 보강은 네 s<sub>g</sub>와 공통 γ의 5계수다. 두 결합과 네 관측기의 총 8개 후보를 모두 보존했다. γ∈[0,0.08]/주기를 81점에서 탐색하고 최저 구간을 다시 최적화했다. ε축 이동·결합 재피팅·관측점 제외·오차막대 확대는 하지 않았다.')
 pages.append(section(3,'공개 관측값과 장치 모형',b))
 b=p('표시 SD를 가중치로 보정한다. 아래 표는 전체 35점 재보정과, 23점만 보정한 뒤 기존 보류 12점에 적용한 결과를 분리한다. 보류 SD²는 표시 SD로 나눈 잔차의 제곱평균이며 공식 카이제곱 검정량으로 해석하지 않는다.')
 b+=result_table(True)
 b+='<img src="observation_comparison.png"><div class="caption">그림 2. 관측값과 전체 재보정 곡선. 회색은 1계수 기준, 청록은 2계수 최소 보강, 주황은 5계수 설정별 보강이다. 빈 원은 재사용 보류점의 위치다. 이 그림의 곡선은 전체 재보정 결과이며 보류 예측 곡선과 혼용하지 않는다.</div>'
 b+=p('5계수 보강은 전체 RMS를 53.08%, 기존 보류 RMS를 28.38% 줄였다. 전체 재보정의 ±2 SD 안 점수는 23/35에서 32/35로, 보류점에서는 8/12에서 11/12로 늘었다. 2계수 최소 보강도 보류 RMS를 23.38%, 보류 SD²를 38.76% 줄였다. 따라서 최소 장치 보강과 더 유연한 설정별 정합 분기를 구분해 유지한다.')
 b+=p('보류점은 탐색에서 재사용됐으므로 외부 독립 검증이 아니다. 보정 자유도도 1개에서 2개 또는 5개로 늘었다. 공분산과 개별 검출 자료가 없으므로 오차막대 안 점수는 서술적 진단이며 사전에 고정한 보편적 통과 기준이 아니다.')
 pages.append(section(4,'관측 대조 결과',b))
 b=p('가장 강한 결합 2J₀t₂=0.072, ε=0.01에서 관측은 0.072563±0.002301이다. 23점으로 보정한 5계수 모형은 0.060240으로 약 −5.35 표시 SD, 전체 재보정은 0.065467로 약 −3.08 SD다. 이 점은 같은 결합 설정의 보정 ε범위 밖에 있지만, 전체 재보정에도 남는 차이를 외삽만으로 설명할 수는 없다.')
 b+=p('반면 같은 결합의 ε=0.03에서는 전체 재보정 잔차가 약 +7.56 SD에서 +2.47 SD로 줄었다. 전체 차이가 줄어도 모든 점이 정합하는 것은 아니다. 5계수 보강의 보류 SD²는 2.854로 기준 2.603보다 약간 나쁘다. 원 RMS와 오차막대에 대한 잔차를 함께 보존하며, 모든 지표에서 우월하다고 결론내리지 않는다.')
 b+=p('실제 장치 입력과의 차이, 알려지지 않은 무질서 표본, 단순한 대비 포락선은 원인 후보다. 어느 하나가 유일 원인이라고 확인하지 않았다. WRRA 동역학이 수정에서 면제된다는 결론도, 이 장치 근사의 불일치가 모든 WRRA 모듈을 반증한다는 결론도 아니다. 실제 결합행렬·사용한 무질서 배열·시간별 대비 자료가 이 구분을 도울 것이다.')
 b+='<h3>반증·수정 조건</h3>'+table(['검사 대상','실패 또는 수정 조건'],[['SOURCE 구현','전이·판독 항등식이나 활성 부분공간 닫힘 실패'],['유한 반응','주파수가 오차를 추종하거나 주장한 시간창에서 질서 소실'],['관측 모형','장치 입력과 불확실성을 고정한 뒤에도 잔차 지속'],['장치 감쇠 해석','보정 포락선과 시간별 실측 대비가 불일치'],['범위 확대','크기·시간 검증 없이 점근적 상의 입증으로 확대']])
 b+='<h3>재검증과 재현성</h3>'+p(f'별도 폴더에서 두 결합 분기를 처음부터 재실행하고 {VERIFY["passed"]}/{VERIFY["total"]}개 내부 검증 항목의 통과를 확인했다. SOURCE 대수·판독, 펄스 기저변환, 결합·무결합 대조, 트랩 평형과 모드 합, 별도 조밀행렬 진화, 관측값 보존, 기준 결과 재생, 독립 보정 정상방정식, 확률 norm, PDF 동일성과 최적화 경계를 검사한다. 별도 조밀행렬 관측량의 차이는 최대 2.47×10<sup>−14</sup> 이하다. 이는 외부 학술 심사 통과를 뜻하지 않는다.')
 b+=p('공개 패키지에는 한·영 PDF, 코드, 모든 모형 비교, 추출 관측값·잔차, 그림과 해시·검증 기록을 담는다. 타 출판사의 PDF는 별도로 내려받으며 재배포하지 않는다. 구현·검산·원고 작성에 AI의 도움을 사용했다. 선언한 입력과 보정 선택은 코드에 드러난다.')
 b+='<h3>결론</h3>'+p('SOURCE에서 반응까지의 구현으로 유한 시간 주기배가의 견고함을 재현했고 실제 집계 관측값과 정량 대조했다. 장치 보강은 차이를 더 줄인다. 동시에 남은 잔차, 불완전한 장치 동일성 및 아직 입증하지 않은 점근적 상의 범위를 그대로 보존한다.')
 pages.append(section(5,'잔차·반증조건·재현성',b))
 b=references(True)+p('제공 코드를 빈 작업 폴더에 놓고 출판 PDF를 nature21413.pdf로 별도 내려받아 다음 명령을 실행한다. SOURCE 구성의 근거는 [3]의 139.4절이며 실제 재구성은 source_involution_check.py에 있다.')
 b+='<div class="code">python refine_time_crystal.py\npython verify_release.py\npython finalize_refinement.py\npython write_paper.py</div>'
 b+=p('필요 패키지는 NumPy, SciPy, PyMuPDF, Matplotlib, WeasyPrint다. 논문 출력에는 Noto Sans CJK Korean 글꼴을 사용한다. 중간 궤적은 다시 생성할 수 있으며 공개 수치표는 패키지에 포함한다. DOI는 이 버전의 논문과 연관 계산 기록을 식별한다.')
 pages.append(section(6,'참고문헌과 실행 기록',b))
 return title,''.join(pages)

def main():
 make_figures()
 for lang,fun in [('EN',english),('KO',korean)]:
  title,body=fun();text=f'<!doctype html><html lang="{lang.lower()}"><head><meta charset="utf-8"><title>{html.escape(title)}</title><style>{CSS}</style></head><body>{body}</body></html>'
  path=OUT/f'WRRA_Time_Crystal_Responses_v1_0_{lang}.html';path.write_text(text)
  HTML(filename=str(path)).write_pdf(str(path.with_suffix('.pdf')))
  print(path.with_suffix('.pdf'))

if __name__=='__main__':main()
