import numpy as np

def evolve(n=10, eps=.1, j0=.8, seeds=16, steps=512):
    # Dimensionless integrated Hamiltonian phases, Pauli eigenvalues +/-1.
    rng=np.random.default_rng(20261023)
    bits=((np.arange(2**n)[:,None]>>np.arange(n))&1)
    z=1.-2.*bits
    h=rng.uniform(-np.pi,np.pi,(seeds,n))
    bonds=rng.uniform(.8,1.2,(seeds,n-1))*j0
    phase=h@z.T+bonds@(z[:,:-1]*z[:,1:]).T
    diagonal=np.exp(-1j*phase)
    initial=rng.integers(0,2**n,seeds)
    signs=z[initial]
    memory=(signs@z.T)/n
    psi=np.zeros((seeds,2**n),complex)
    psi[np.arange(seeds),initial]=1
    c=np.cos((np.pi-eps)/2); s=-1j*np.sin((np.pi-eps)/2)
    trace=[]; max_norm_error=0
    for t in range(steps):
        for q in range(n):
            v=psi.reshape(seeds,-1,2,2**q)
            a=v[:,:,0,:].copy(); b=v[:,:,1,:].copy()
            v[:,:,0,:]=c*a+s*b; v[:,:,1,:]=s*a+c*b
        psi*=diagonal
        p=np.abs(psi)**2
        max_norm_error=max(max_norm_error,float(abs(p.sum(1)-1).max()))
        trace.append((p*memory).sum(1))
    trace=np.array(trace)
    demod=trace*((-1.)**np.arange(1,steps+1))[:,None]
    tail=demod[steps//2:].mean(0)
    f=np.fft.rfftfreq(steps//2)
    power=abs(np.fft.rfft(trace[steps//2:],axis=0))**2
    peak=f[power.mean(1).argmax()]
    return {'n':n,'epsilon_rad':eps,'j0':j0,'seeds':seeds,'steps':steps,
            'tail_signed_memory':float(tail.mean()),'seed_sd':float(tail.std(ddof=1)),
            'peak_cycles_per_T':float(peak),'norm_error':max_norm_error},trace

if __name__=='__main__':
    import json
    for j in [0,.8]:
        for e in [0,.05,.1,.2,.3]:
            row,_=evolve(j0=j,eps=e)
            print(json.dumps(row),flush=True)
