"""Independent release checks; run after a fresh refine_time_crystal.py replay."""
from pathlib import Path
import csv,hashlib,json,sys
import numpy as np
from scipy.linalg import expm
from source_involution_check import verify as verify_source
from time_crystal_probe import evolve
from refine_time_crystal import coupling_matrices,trace,OUT
from compare_observation import extract

def main():
 checks=[]
 def check(name,ok,detail):
  checks.append({'name':name,'passed':bool(ok),'detail':detail})
 source=verify_source();check('source_involution_and_intertwining',max(v for k,v in source.items() if k.endswith('_error'))<1e-12,source)
 # An independent two-level pulse check, including the fixed basis change.
 I=np.eye(2);X=np.array([[0,1],[1,0]],complex);Z=np.diag([1,-1]);theta=np.pi-.1
 err=float(abs(Z@expm(-1j*theta*(I-X)/2)@Z-np.exp(-1j*theta/2)*expm(-1j*theta*X/2)).max())
 check('source_pulse_basis_equivalence',err<1e-12,err)
 responses=[];fig_traces={}
 for j in [0,.8]:
  for e in [0,.05,.1,.2,.3]:
   row,tr=evolve(j0=j,eps=e);responses.append(row)
   if e==.1:fig_traces[str(j)]=tr.mean(1).tolist()
 for j in [0,.8]:
  row,tr=evolve(j0=j,eps=.1,steps=2048);responses.append(row)
 with (OUT/'finite_response_replay.csv').open('w') as f:
  w=csv.DictWriter(f,fieldnames=list(responses[0]));w.writeheader();w.writerows(responses)
 (OUT/'finite_response_traces.json').write_text(json.dumps(fig_traces))
 interacting=[r for r in responses if r['j0']==.8 and r['epsilon_rad']>0]
 check('finite_time_rigidity',all(r['peak_cycles_per_T']==.5 and r['tail_signed_memory']>.25 for r in interacting),interacting)
 uncoupled=[r for r in responses if r['j0']==0 and r['epsilon_rad']>0]
 check('uncoupled_negative_control',all(abs(r['tail_signed_memory'])<.05 for r in uncoupled),uncoupled)
 matrices,coupling=coupling_matrices();check('trap_equilibrium_and_modal_resolvent',coupling['equilibrium_gradient_max']<1e-9 and coupling['mode_inverse_max_error']<1e-12,coupling)
 # Dense-matrix calculation independently checks a modal-coupled 3-block chain.
 mats,_=coupling_matrices(3);M=mats['modal_trap'];tr,norm=trace(.03,.036,M,seeds=2)
 n=3;z=1.-2.*((np.arange(8)[:,None]>>np.arange(n))&1);rng=np.random.default_rng(20261023);h=rng.uniform(0,np.pi,(2,n));rx=expm(-1j*np.pi*(1-.03)*X/2);pulse=np.kron(np.kron(rx,rx),rx);err=0
 for s in range(2):
  energy=z@h[s]
  for i in range(n):
   for j in range(i+1,n):energy+=.036*M[i,j]*z[:,i]*z[:,j]
  U=np.diag(np.exp(-1j*energy))@pulse;psi=np.eye(8,dtype=complex)[:,0]
  for k in range(100):
   psi=U@psi;err=max(err,float(abs(abs(psi)**2@z-tr[k,s]).max()))
 check('independent_dense_dynamics',err<1e-11,err)
 rows=extract();old=list(csv.DictReader(open('WRRA_Time_Crystal_Observation_v0_5/observed_and_calculated.csv')))
 input_error=max(max(abs(r['observed_height']-float(o['observed_height'])),abs(r['observed_sd']-float(o['observed_sd']))) for r,o in zip(rows,old))
 check('observed_values_preserved',len(rows)==35 and input_error<1e-12,input_error)
 cache=np.load(OUT/'powerlaw_traces.npz')['trace'];amps=abs(np.einsum('ptsi,t->psi',cache,(-1.)**np.arange(1,101))/100).mean((1,2))
 err=float(abs(amps-np.array([float(o['central_amplitude']) for o in old])).max());check('v05_full_replay',err<1e-12,err)
 # Independent normal equations for the common-scale WLS reference.
 y=np.array([r['observed_height'] for r in rows]);sd=np.array([r['observed_sd'] for r in rows]);weighted=(amps/sd)[:,None]
 a=float(np.linalg.lstsq(weighted,y/sd,rcond=None)[0][0]);models=json.loads((OUT/'model_comparison.json').read_text());baseline=next(r for r in models if r['name']=='powerlaw_common1')
 check('independent_calibration_normal_equation',abs(a-baseline['all_refit_coefficients'][0])<1e-12,{'independent_scale':a})
 kernel=json.loads((OUT/'kernel_verification.json').read_text());check('probability_norms',0<kernel['norm_error']<1e-10,kernel)
 sha=hashlib.sha256(Path('nature21413.pdf').read_bytes()).hexdigest();check('source_pdf_identity',sha=='645b138317304e38fbc15a949a741aad6897bd49fca14d4a5a20a39bea08805f',sha)
 # Optimizer now compares an 81-point grid and refines the best bracket.
 check('all_eight_models_and_bounds',len(models)==8 and all(0<=r['train_gamma_per_period']<=.08 and 0<=r['all_refit_gamma']<=.08 for r in models),{'models':len(models),'grid_points':81})
 report={'passed':sum(c['passed'] for c in checks),'total':len(checks),'checks':checks,
 'scope':'Internal algebra, numerical dynamics, extraction replay and calibration checks; not external peer review or full-phase proof.'}
 (OUT/'REVALIDATION.json').write_text(json.dumps(report,indent=2))
 print(json.dumps({'passed':report['passed'],'total':report['total'],'failed':[c['name'] for c in checks if not c['passed']]},indent=2))
 assert report['passed']==report['total']

if __name__=='__main__':main()
