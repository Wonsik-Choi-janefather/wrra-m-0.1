"""Phenomenological WRRA twist-stress toy calibration; diagonal diagnostic only.
Run from this directory with CAMB 2.0.4 installed. This does not derive stress dynamics.
"""
import os,sys,json,time
from pathlib import Path
os.environ.setdefault('OMP_NUM_THREADS','2')
sys.path.append(str(Path(__file__).resolve().parent.parent/'cmb_deps'))
import camb
import numpy as np
from scipy.optimize import least_squares
from scipy.signal import find_peaks
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
R=Path(__file__).resolve().parent
data={s:np.loadtxt(R/f'COM_PowerSpect_CMB-{s}-binned_R{v}.txt') for s,v in [('TT','3.01'),('TE','3.02'),('EE','3.02')]}
ix={'TT':0,'TE':3,'EE':1}
calls=0
def model(x,accuracy=1.5,fixed_omega_b=None):
    # x = H0, total nonbaryonic matter fraction, scalar amplitude /1e-9, tilt.
    H,OD,A,n=x; h2=(H/100)**2
    p=camb.CAMBparams()
    p.set_cosmology(H0=H,ombh2=(.05*h2 if fixed_omega_b is None else fixed_omega_b),omch2=.12,tau=.0544,mnu=.06,nnu=3.046,TCMB=2.7255)
    p.set_cosmology(H0=H,ombh2=(.05*h2 if fixed_omega_b is None else fixed_omega_b),omch2=OD*h2-p.omnuh2,tau=.0544,mnu=.06,nnu=3.046,TCMB=2.7255)
    p.InitPower.set_params(As=A*1e-9,ns=n,pivot_scalar=.05)
    p.set_dark_energy(w=-1)
    p.set_for_lmax(2500,lens_potential_accuracy=0)
    p.NonLinear=camb.model.NonLinear_none
    p.Accuracy.AccuracyBoost=accuracy;p.Accuracy.lAccuracyBoost=accuracy
    # Linear matter lensing potential; identical prescription before and after calibration.
    result=camb.get_results(p)
    spec=result.get_cmb_power_spectra(p,CMB_unit='muK',lmax=2500,spectra=['total'])['total']
    return spec,result,p
def residual(spec):
    return np.concatenate([(np.interp(d[:,0],np.arange(len(spec)),spec[:,ix[s]])-d[:,1])/((d[:,2]+d[:,3])/2) for s,d in data.items()])
def objective(x,mask):
    global calls
    calls+=1;spec,_,_=model(x)
    r=residual(spec)
    if calls%5==0:print('evaluation',calls,'params',x.tolist(),'objective',float(np.mean(r[mask]**2)),flush=True)
    return r[mask]

j=json.loads((R/'twist_calibration_results.json').read_text());f=j['fitted_parameters']
x=np.array([f['H0'],f['Omega_D_total'],f['A_s_in_1e_minus9'],f['n_s']])
bounds=([55,.15,1.5,.90],[80,.40,3.,1.05]);N=sum(map(len,data.values()))
train=np.arange(N)%4!=0

def fitrun(name,start,mask,fixedomega=None,step=1e-3):
 def obj(v):return residual(model(v,fixed_omega_b=fixedomega)[0])[mask]
 fit=least_squares(obj,start,bounds=bounds,diff_step=step,x_scale=[5,.05,.3,.05],max_nfev=30,ftol=1e-5,xtol=1e-5,gtol=1e-4)
 sp,res,p=model(fit.x,fixed_omega_b=fixedomega)
 rr=residual(sp)
 info={'parameters':fit.x.tolist(),'success':bool(fit.success),'termination':str(fit.message),'nfev':fit.nfev,'cost':float(fit.cost),'objective_sum_r_squared':float(np.sum(rr[mask]**2)),'optimality':float(fit.optimality),'active_mask':fit.active_mask.tolist(),'R_all':float(np.sqrt(np.mean(rr**2))),'Omega_b':float(res.get_Omega('baryon')),'fixed_omega_b':fixedomega,'difference_step':step}
 print(name,json.dumps(info),flush=True)
 return info
out={}
out['main_fit_recheck']=fitrun('main_fit_recheck',x,np.ones(N,dtype=bool))
out['alternative_start']=fitrun('alternative_start',np.array([70,.25,2.2,.98]),np.ones(N,dtype=bool),step=5e-4)
out['fixed_physical_baryon_sensitivity']=fitrun('fixed_physical_baryon_sensitivity',x,np.ones(N,dtype=bool),fixedomega=.0227138)
out['training_fit_reproduction']=fitrun('training_fit_reproduction',np.array([67.4,.268,2.1,.9649]),train)
# Identical physical inputs through an ordinary direct CAMB setup vs the WRRA density wrapper.
sp,res,p=model(x)
q=camb.CAMBparams();q.set_cosmology(H0=x[0],ombh2=p.ombh2,omch2=p.omch2,tau=.0544,mnu=.06,nnu=3.046,TCMB=2.7255)
q.InitPower.set_params(As=x[2]*1e-9,ns=x[3],pivot_scalar=.05);q.set_dark_energy(w=-1);q.set_for_lmax(2500,lens_potential_accuracy=0);q.NonLinear=camb.model.NonLinear_none;q.Accuracy.AccuracyBoost=1.5;q.Accuracy.lAccuracyBoost=1.5
rr=camb.get_results(q);direct=rr.get_cmb_power_spectra(q,CMB_unit='muK',lmax=2500,spectra=['total'])['total']
out['identical_input_equivalence']={'max_abs_Dl_difference':float(np.max(np.abs(sp-direct))),'meaning':'implementation mapping equivalence, not independent twist validation'}
(R/'twist_robustness_results.json').write_text(json.dumps(out,indent=2))
