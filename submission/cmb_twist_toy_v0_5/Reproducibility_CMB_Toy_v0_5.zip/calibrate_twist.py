"""Phenomenological WRRA twist-stress toy calibration; diagonal diagnostic only.
Run from this directory with CAMB 2.0.4 installed. This does not derive stress dynamics.
"""
import os,sys,json,time
from pathlib import Path
os.environ.setdefault('OMP_NUM_THREADS','2')
sys.path.append(str(Path(__file__).resolve().parent.parent/'cmb_deps'))
import camb
import numpy as np
from scipy.optimize import least_squares
from scipy.signal import find_peaks
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
R=Path(__file__).resolve().parent
data={s:np.loadtxt(R/f'COM_PowerSpect_CMB-{s}-binned_R{v}.txt') for s,v in [('TT','3.01'),('TE','3.02'),('EE','3.02')]}
ix={'TT':0,'TE':3,'EE':1}
calls=0
def model(x,accuracy=1.5):
    # x = H0, total nonbaryonic matter fraction, scalar amplitude /1e-9, tilt.
    H,OD,A,n=x; h2=(H/100)**2
    p=camb.CAMBparams()
    p.set_cosmology(H0=H,ombh2=.05*h2,omch2=.12,tau=.0544,mnu=.06,nnu=3.046,TCMB=2.7255)
    p.set_cosmology(H0=H,ombh2=.05*h2,omch2=OD*h2-p.omnuh2,tau=.0544,mnu=.06,nnu=3.046,TCMB=2.7255)
    p.InitPower.set_params(As=A*1e-9,ns=n,pivot_scalar=.05)
    p.set_dark_energy(w=-1)
    p.set_for_lmax(2500,lens_potential_accuracy=0)
    p.NonLinear=camb.model.NonLinear_none
    p.Accuracy.AccuracyBoost=accuracy;p.Accuracy.lAccuracyBoost=accuracy
    # Linear matter lensing potential; identical prescription before and after calibration.
    result=camb.get_results(p)
    spec=result.get_cmb_power_spectra(p,CMB_unit='muK',lmax=2500,spectra=['total'])['total']
    return spec,result,p
def residual(spec):
    return np.concatenate([(np.interp(d[:,0],np.arange(len(spec)),spec[:,ix[s]])-d[:,1])/((d[:,2]+d[:,3])/2) for s,d in data.items()])
def objective(x,mask):
    global calls
    calls+=1;spec,_,_=model(x)
    r=residual(spec)
    if calls%5==0:print('evaluation',calls,'params',x.tolist(),'objective',float(np.mean(r[mask]**2)),flush=True)
    return r[mask]
base=np.array([67.4,.268,2.1,.9649]);bounds=([55,.15,1.5,.90],[80,.40,3.,1.05])
base_spec,_,_=model(base)
N=sum(map(len,data.values()));train=np.arange(N)%4!=0;held=~train
fit_train=least_squares(objective,base,args=(train,),bounds=bounds,diff_step=1e-3,x_scale=[5,.05,.3,.05],max_nfev=35,ftol=1e-5,xtol=1e-5,gtol=1e-4)
train_spec,_,_=model(fit_train.x)
fit=least_squares(objective,fit_train.x,args=(np.ones(N,dtype=bool),),bounds=bounds,diff_step=1e-3,x_scale=[5,.05,.3,.05],max_nfev=35,ftol=1e-5,xtol=1e-5,gtol=1e-4)
spec,result,p=model(fit.x)
high_spec,_,_=model(fit.x,accuracy=2.)
def summary(sp):
    r=residual(sp);out={};start=0
    for s,d in data.items():
        n=len(d);out[s]=float(np.sqrt(np.mean(r[start:start+n]**2)));start+=n
    out['all']=float(np.sqrt(np.mean(r**2)));return out
peaks=find_peaks(spec[:,0])[0];peaks=[int(x) for x in peaks if 100<=x<=1000][:3]
fields=['baryon','cdm','nu','photon','neutrino','de']
cfg={k:float(v) for k,v in zip(['H0','Omega_D_total','A_s_in_1e_minus9','n_s'],fit.x)}
dens={k:float(result.get_Omega(k)) for k in fields}
assert np.all(np.isfinite(spec)) and abs(sum(dens.values())-1)<1e-5
assert abs(dens['baryon']-.05)<1e-8
ell=np.arange(len(spec))
for name,sp in [('twist_calibrated',spec),('twist_before_calibration',base_spec),('twist_calibrated_accuracy2',high_spec)]:
    np.savetxt(R/(name+'.csv'),np.column_stack([ell,sp]),delimiter=',',header='ell,TT_Dl_uK2,EE_Dl_uK2,BB_Dl_uK2,TE_Dl_uK2',comments='')
base_r=residual(base_spec);train_r=residual(train_spec)
record={'model':'WRRA effective pressureless twist-stress toy model v0.3',
 'calibration_target':'Planck PR3 binned TT/TE/EE; diagonal error-bar objective, not official likelihood',
 'validated_inputs':{'Omega_b_fixed':.05,'standard_radiation_recombination_GR':'inherited','tau':.0544,'mnu':.06,'Neff':3.046,'T_CMB':2.7255},
 'WRRA_transform':'twist gravitational phenotype -> effective pressureless fluid -> radiation-completed density budget; adopted CAMB transfer operator',
 'phenomenological_twist_hypothesis':{'w_D':0,'cs2_D':0,'anisotropic_stress_D':0,'P_R(k)':'A_s (k/0.05 Mpc^-1)^(n_s-1); amplitude and tilt calibrated effective initial conditions, not source-derived'},
 'parameter_order':['H0','Omega_D_total','A_s_in_1e_minus9','n_s'],'bounds':bounds,'initial_parameters':base.tolist(),
 'fitted_parameters':cfg,'densities_today':dens,'omega_b':p.ombh2,'omega_D':p.omch2,
 'fit_status':{'success':bool(fit.success),'message':str(fit.message),'nfev':fit.nfev,'total_solver_calls':calls},
 'before_R':summary(base_spec),'after_R':summary(spec),
 'holdout':{'definition':'every fourth concatenated TT/TE/EE bin held out; deterministic diagnostic, correlated bins not independent',
 'train_count':int(train.sum()),'heldout_count':int(held.sum()),'train_fit_parameters':fit_train.x.tolist(),
 'heldout_R_before':float(np.sqrt(np.mean(base_r[held]**2))),
 'heldout_R_after_train_fit':float(np.sqrt(np.mean(train_r[held]**2))),
 'final_fit_uses_all_bins':True},
 'TT_peaks':peaks,'TT_peak_heights':[float(spec[x,0]) for x in peaks],
 'derived':{k:float(v) for k,v in result.get_derived_params().items()},
 'accuracy_test':{'AccuracyBoost':2,'lAccuracyBoost':2,'R':summary(high_spec),
 'RMS_difference_in_public_bin_sigma':float(np.sqrt(np.mean((residual(high_spec)-residual(spec))**2)))},
 'falsification_conditions':['effective twist closure must actually realize its adopted pressureless stress/conservation rules','fixed calibrated spectra must be checked with proper band windows, covariance and likelihood; no formal pass claimed','failure of positive density closure or numerical stability rejects this implementation'],
 'interpretation':'calibrated reproduction of CMB shape; parameters fitted to these data are calibration inputs, not new predictions; inherited transfer physics does not establish internally derived finite-source dynamics'}
(R/'twist_calibration_results.json').write_text(json.dumps(record,indent=2))
fig,axs=plt.subplots(3,2,figsize=(12,10),sharex=True,gridspec_kw={'width_ratios':[2,1]})
for row,s in enumerate(['TT','TE','EE']):
 d=data[s];k=ix[s]
 axs[row,0].errorbar(d[:,0],d[:,1],yerr=[d[:,2],d[:,3]],fmt='.',ms=3,color='#777777',alpha=.7,label='Planck PR3 binned')
 axs[row,0].plot(ell[2:],base_spec[2:,k],color='#999999',lw=1,label='Before calibration')
 axs[row,0].plot(ell[2:],spec[2:,k],color='#bc5b19',lw=1.5,label='Calibrated twist toy')
 sigma=(d[:,2]+d[:,3])/2
 for sp,label,color in [(base_spec,'Before','#999999'),(spec,'After','#bc5b19')]:
  rr=(np.interp(d[:,0],ell,sp[:,k])-d[:,1])/sigma
  axs[row,1].plot(d[:,0],rr,'.-',lw=.6,ms=2,color=color,label=label)
 axs[row,1].axhline(0,color='black',lw=.5)
 axs[row,0].set_ylabel(s+r' $D_\ell$ [$\mu K^2$]');axs[row,1].set_ylabel('Residual / bin error')
 for ax in axs[row]:ax.grid(alpha=.2);ax.set_xlim(2,2500)
axs[0,0].legend(fontsize=8);axs[0,1].legend(fontsize=8)
for ax in axs[-1]:ax.set_xlabel(r'Multipole $\ell$')
fig.suptitle('WRRA twist-stress toy: calibrated CMB reproduction (diagonal diagnostic)',fontsize=13)
fig.tight_layout(rect=[0,0,1,.965]);fig.savefig(R/'Twist_CMB_Calibrated.png',dpi=160)
print(json.dumps(record,indent=2),flush=True)
