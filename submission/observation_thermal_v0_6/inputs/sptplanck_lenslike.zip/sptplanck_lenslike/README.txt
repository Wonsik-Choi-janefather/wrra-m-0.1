##########################################
# Version History:
#
# v1.1, created December 7th, 2017, GS.
##########################################

=== OVERVIEW ===

- This likelihood allows to run chains using the SPT+Planck 2500 sq.deg. lensing data.
- The structure of this likelihood is based on the Planck lensing likelihood files released within the July 2015 CosmoMC version.
- This likelihood has been tested within the November 2016 CosmoMC version.

=== LINEAR CORRECTIONS ===

- This likelihood includes linear lensing corrections accounting for cosmological changes in the cltt and clpp power spectra.
- For lensing only constraints, the TT corrections are fixed to the base_plikHM_TT_lowTEB cosmology
(parameter values from https://wiki.cosmos.esa.int/planckpla2015/images/f/f7/Baseline_params_table_2015_limit68.pdf, p.12 and
cltt computed with the November 2016 CAMB Fortran version.)

=== INSTALLATION ===

In a working CosmoMC environment,
- copy batch2/lensing_sptplanck_fgrm.ini and batch2/lensonly_sptplanck_fgrm.ini to your CosmoMC batch2/ subdirectory;
- copy data/sptplanck_lensing and data/base_plikHM_TT_lowTEB_lmax3000.minimum.theory_cl to your CosmoMC data/ subdirectory;
- include the appropriate .ini file in your primary .ini file (see examples in sptplanck_lenslike/chains/).
