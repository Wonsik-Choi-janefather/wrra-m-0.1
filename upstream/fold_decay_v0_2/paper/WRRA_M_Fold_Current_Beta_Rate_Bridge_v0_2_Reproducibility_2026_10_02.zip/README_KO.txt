WRRA-M 접힘 전환과 입자 붕괴율 계산 0.2
최원식 2026-10-02

재현
python -m pip install -r requirements.txt
python compute.py

보정 입력: 핵자 질량, GF, Vud, 관측 λ 및 중성자 수명.
구성 선택: 3·5 표식, 대칭 공간 바닥상태, 유한 소수 계열의 대칭 진폭 커널.
전체 입력과 보정, 전환 행렬원소와 상태 진폭, 민감도 및 30개 검사는 results.json에 기록했다.

원고 재생성
python build_doc.py
python-docx, lxml, matplotlib, Pandoc 및 Noto Sans CJK KR와 Latin Modern Math 필요.
