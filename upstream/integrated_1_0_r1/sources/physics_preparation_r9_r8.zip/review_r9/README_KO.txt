WRRA_M 물질 5퍼센트 용어 병기와 도입 순서 정리판 r9
2026년 10월 2일

현재 주 원고는 output/WRRA_M_물질5퍼센트_용어병기_한글_r9.docx와 같은 이름의 PDF다.
초록 다음에 WRRA의 간단한 기초 설명을 두고 서론을 이어 배치했다.
첫 정의에 표준 수학 개념과 기능 설명을 병기하고 부록 B의 표 10에서 대응을 정리했다.
수리적으로 같은 정의와 WRRA의 역할을 옮긴 기능 설명을 구분했다.
기존 수식 25개, 수치 표 10개, 기존 참고문헌 9개와 계산 코드 및 결과를 보존했다.
관측 기준과 보정 입력, 대조 및 반증조건은 기존 내용을 유지했다.
표준 정의 출처로 IBM Quantum Learning과 MIT OpenCourseWare를 추가했다.
주 원고 22쪽의 수식과 표 및 페이지 배치를 렌더링하여 검토했다.

편집 원본은 review_r9/manuscript_KO.json이다.
review_r9에서 python build_documents.py로 현재 Word를 생성한다.
계산 재현 방법과 원래 소스는 보존된 review_r8/README_KO.txt 및 rebuild_source를 따른다.
기존 확장 원고 r8은 독립 파일로 그대로 유지한다.
이 묶음에는 이전 r8의 원고·계산 자료와 현재 r9의 편집 소스를 함께 보존한다.
이번 수정은 용어와 도입 순서를 다루며 새 수치 계산을 실행한 개정판은 아니다.
검증 내역은 qa/r9_final_validation.json에 기록한다.
