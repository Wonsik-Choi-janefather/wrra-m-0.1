from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import json, hashlib, shutil

ROOT=Path(__file__).resolve().parents[1]
SRC=ROOT/'review_r9'; OUT=ROOT/'output'
STEM='WRRA_M_물질5퍼센트_용어병기_한글_r9'
shutil.copy2(ROOT/'qa/r9_delivery'/f'{STEM}.pdf',OUT/f'{STEM}.pdf')
readme='''WRRA_M 물질 5퍼센트 용어 병기와 도입 순서 정리판 r9
2026년 10월 2일

현재 주 원고는 output/WRRA_M_물질5퍼센트_용어병기_한글_r9.docx와 같은 이름의 PDF다.
초록 다음에 WRRA의 간단한 기초 설명을 두고 서론을 이어 배치했다.
첫 정의에 표준 수학 개념과 기능 설명을 병기하고 부록 B의 표 10에서 대응을 정리했다.
수리적으로 같은 정의와 WRRA의 역할을 옮긴 기능 설명을 구분했다.
기존 수식 25개, 수치 표 10개, 기존 참고문헌 9개와 계산 코드 및 결과를 보존했다.
관측 기준과 보정 입력, 대조 및 반증조건은 기존 내용을 유지했다.
표준 정의 출처로 IBM Quantum Learning과 MIT OpenCourseWare를 추가했다.
주 원고 22쪽의 수식과 표 및 페이지 배치를 렌더링하여 검토했다.

편집 원본은 review_r9/manuscript_KO.json이다.
review_r9에서 python build_documents.py로 현재 Word를 생성한다.
계산 재현 방법과 원래 소스는 보존된 review_r8/README_KO.txt 및 rebuild_source를 따른다.
기존 확장 원고 r8은 독립 파일로 그대로 유지한다.
이 묶음에는 이전 r8의 원고·계산 자료와 현재 r9의 편집 소스를 함께 보존한다.
이번 수정은 용어와 도입 순서를 다루며 새 수치 계산을 실행한 개정판은 아니다.
검증 내역은 qa/r9_final_validation.json에 기록한다.
'''
(SRC/'README_KO.txt').write_text(readme)
sources=[OUT/f'{STEM}.docx',OUT/f'{STEM}.pdf']
sources += [SRC/name for name in ('manuscript.py','manuscript_KO.json','build_documents.py','revision_map_r9.json','README_KO.txt','phase_control_comparison.py','phase_control_comparison_results.json','renderer_coupling_check.py','renderer_coupling_results.json','assets/whole_flow_KO.png','assets/phase_controls_KO.png','assets/equations.txt')]
sources += [ROOT/'qa/validate_r9.py',ROOT/'qa/package_r9.py',ROOT/'qa/r9_final_validation.json']
old=OUT/'WRRA_M_보정대조보강_r8_원고및계산자료.zip'
archive=OUT/'WRRA_M_용어병기_r9_원고및계산자료.zip'
records=[]
with ZipFile(old) as baseline,ZipFile(archive,'w',ZIP_DEFLATED) as z:
    for name in baseline.namelist():
        data=baseline.read(name);z.writestr(name,data)
        records.append({'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
    for p in sources:
        data=p.read_bytes();name=str(p.relative_to(ROOT));z.writestr(name,data)
        records.append({'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
    manifest={'edition':'r9-KO-terminology','opening_order':['Abstract','WRRA brief foundation','Introduction'],'pages':22,'equations':25,'tables':12,'references':11,'calculation_files_changed':False,'observational_benchmark_changes':False,'files':records}
    m=json.dumps(manifest,ensure_ascii=False,indent=2)
    (SRC/'manifest_r9_KO.json').write_text(m)
    z.writestr('review_r9/manifest_r9_KO.json',m)
    assert z.testzip() is None
with ZipFile(archive) as z:
    for row in records:
        data=z.read(row['path']);assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
print(json.dumps({'zip_entries_verified':len(records)+1,'files':[str(OUT/(STEM+ext)) for ext in ('.docx','.pdf')]+[str(archive)]},ensure_ascii=False))
