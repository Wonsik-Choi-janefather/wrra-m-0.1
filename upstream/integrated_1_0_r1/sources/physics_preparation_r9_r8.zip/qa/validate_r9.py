from pathlib import Path
from zipfile import ZipFile
from lxml import etree
from pypdf import PdfReader
import json, re, hashlib

ROOT=Path(__file__).resolve().parents[1]
STEM='WRRA_M_물질5퍼센트_용어병기_한글_r9'
old=json.loads((ROOT/'review_r8/manuscript_KO.json').read_text())['blocks']
new=json.loads((ROOT/'review_r9/manuscript_KO.json').read_text())['blocks']
select=lambda bs,k:[b for b in bs if b['kind']==k]
assert select(old,'eq')==select(new,'eq')
ns={'m':'http://schemas.openxmlformats.org/officeDocument/2006/math','w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
def xml(path):
    with ZipFile(path) as z:return etree.fromstring(z.read('word/document.xml'))
previous=xml(ROOT/'output/WRRA_M_물질5퍼센트_보정대조보강_한글_r8.docx')
current=xml(ROOT/'output'/f'{STEM}.docx')
native=lambda t:[etree.tostring(n,method='c14n') for n in t.xpath('//m:oMath',namespaces=ns)]
assert native(previous)==native(current) and len(native(current))==25
assert len(current.xpath('//w:tbl',namespaces=ns))==12
for i,(a,b) in enumerate(zip(select(old,'table'),select(new,'table')),1):
    if i not in (10,11):assert a==b,i
assert select(old,'ref')==select(new,'ref')[:9]
assert len(select(new,'ref'))==11
assert [b['text'] for b in select(new,'h')][:3]==['초록','WRRA의 기초 모형','서론']
labels={b['label'] for b in select(new,'eq')}
tables={re.match(r'표 (\d+)',b['caption']).group(1) for b in select(new,'table')}
refs={re.match(r'\[(\d+)\]',b['text']).group(1) for b in select(new,'ref')}
for b in new:
    for key in ('text','caption'):
        t=b.get(key,''); assert '@@' not in t and 'OLD_TABLE' not in t
        assert all(x in labels for x in re.findall(r'식 ([A-Z]?\d+[a-d]?)',t))
        assert all(x in tables for x in re.findall(r'(?<![가-힣])표 (\d+)',t))
        assert all(x in refs for g in re.findall(r'\[([\d,]+)\]',t) if '0' not in g.split(',') for x in g.split(','))
text=json.dumps(new,ensure_ascii=False)
assert '4.8769%' in text and '4점' not in text
assert 'Dyadic Response Bounds and Spectral Geometry of Jeongin Arithmetic Filters' in text
assert not any(x in text for x in ('DNA','끈이론','뒤틀림','q₀','부록 E','10¹²⁰'))
unchanged=[]
for p in (ROOT/'review_r8').rglob('*'):
    if not p.is_file() or '__pycache__' in p.parts:continue
    rel=p.relative_to(ROOT/'review_r8')
    if p.suffix not in ('.py','.json','.txt') or rel.parts[0] in ('assets','extension_assets'):continue
    if p.name in ('manuscript_KO.json','build_documents.py','README_KO.txt','package_deliverables.py'):continue
    q=ROOT/'review_r9'/rel
    assert q.read_bytes()==p.read_bytes(),str(rel)
    unchanged.append(str(rel))
pdf=ROOT/'qa/r9_delivery'/f'{STEM}.pdf'; reader=PdfReader(pdf)
assert len(reader.pages)==22
assert all((ROOT/'qa/r9_delivery'/f'page-{n}.png').is_file() for n in range(1,23))
assert not any('\ufffd' in p.extract_text() or '¿' in p.extract_text() for p in reader.pages)
compact=lambda t:re.sub(r'\s+','',t)
assert 'WRRA의기초모형' in compact(reader.pages[0].extract_text())
assert compact(reader.pages[1].extract_text()).startswith('2서론')
for name,count in [('phase_control_comparison_results',36),('renderer_coupling_results',20)]:
    r=json.loads((ROOT/'review_r9'/f'{name}.json').read_text())
    assert r['all_passed'] and r['passed']==r['total']==count
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
report={'edition':'r9-KO-terminology','all_passed':True,
        'main_pages_reviewed_at_original_resolution':list(range(1,23)),
        'native_equations_unchanged':25,'tables':12,'existing_references_unchanged':9,
        'added_primary_definition_sources':2,'numeric_tables_unchanged':10,
        'opening_order':['Abstract','WRRA brief foundation','Introduction'],
        'observational_benchmark_changes':False,'new_numerical_calculations':False,
        'unchanged_calculation_and_reference_files':unchanged,
        'preserved_control_check_record':36,'preserved_renderer_check_record':20,
        'files':[{'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)} for p in [ROOT/'output'/f'{STEM}.docx',pdf]]}
(ROOT/'qa/r9_final_validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print(json.dumps({k:v for k,v in report.items() if k not in ('files','unchanged_calculation_and_reference_files','main_pages_reviewed_at_original_resolution')},ensure_ascii=False))
