"""Package the Korean calibration and control comparison revision."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import hashlib, json, shutil
from pypdf import PdfReader

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / 'review_r8'
OUT = ROOT / 'output'
STEM = 'WRRA_M_물질5퍼센트_보정대조보강_한글_r8'
docx, pdf = [OUT / (STEM + ext) for ext in ('.docx', '.pdf')]
shutil.copy2(ROOT / 'qa/r8_core_release' / (STEM + '.pdf'), pdf)
pages = len(PdfReader(pdf).pages)
EXT_STEM='WRRA_M_확장가능성과접속조건_한글_r8'
ext_docx=OUT/(EXT_STEM+'.docx')
ext_pdf=OUT/(EXT_STEM+'.pdf')
shutil.copy2(ROOT/'qa/r8_extensions_release'/(EXT_STEM+'.pdf'),ext_pdf)
extension_pages=len(PdfReader(ext_pdf).pages)
controls = json.loads((SRC / 'phase_control_comparison_results.json').read_text())
assert controls['all_passed'] and controls['passed'] == controls['total'] == 36
coupling = json.loads((SRC / 'renderer_coupling_results.json').read_text())
assert coupling['all_passed'] and coupling['passed'] == coupling['total'] == 20
assert (SRC / 'renderer_coupling_results.json').read_bytes() == (ROOT / 'review_r7/renderer_coupling_results.json').read_bytes()
old = json.loads((ROOT / 'rebuild_source/reproduction_results.json').read_text())
unchanged = []
for row in old['rows']:
    p = ROOT / 'rebuild_source/work' / row['study'] / 'code' / row['result']
    assert hashlib.sha256(p.read_bytes()).hexdigest() == row['result_sha256']
    unchanged.append(str(p.relative_to(ROOT)))
preserved = {}
for name in ('vacuum_reference_results','twist_bridge_results','benchmark_derivation_results','phase_ledger_results'):
    result = json.loads((SRC / (name + '.json')).read_text())
    assert result['all_passed']
    assert (SRC / (name + '.json')).read_bytes() == (ROOT / 'review_r7' / (name + '.json')).read_bytes()
    preserved[name] = result.get('total', len(result['checks']))

readme = f'''WRRA_M 물질 5퍼센트 보정과 대조 검증 보강판 r8
2026년 10월 2일
최원식 Wonsik Choi · 최정인 Jeongin Choi

이번 보강
3 보정 입력과 WRRA 산출값의 역할을 표 4에서 명시했다.
α = 2 고정 시험과 두 구성비 목표를 사용한 공동 보정을 구분했다.
복귀 R은 장부의 완전성에서 계산된다.
관측값을 보정에 사용한 구성비 재현의 설명 성과를 유지한다.
4 정지 제타 위상·등간격 주파수·일정 진입 장부를 실제로 비교했다.
공통 임계값 h를 유지한 비교와 각각 같은 5%에 h를 보정한 비교를 나누었다.
공통 h에서 표현형은 5.000000%, 4.859796%, 5.095593%, 4.710550%다.
각 h를 보정하면 모두 5%·26.8%·68.2%를 재현하지만 주소별 진입과 잔존 분포는 다르다.
총량 재현과 내부 상태의 차이를 함께 평가하며 제타 구동의 유일성을 가정하지 않는다.
5 본문을 물질 5% → 초기 초점 흐림 → 진입 → 접힘에 따른 복귀 차단 → 잔존
→ 최종 렌더러 → 하류 물리 판독으로 정리했다.
본문의 부록에는 초기 위상·누적 진입·대조 분포·WRRA의 구조·구성비 유도만 남겼다.
기존 끈이론·진공·뒤틀림·관측 비교·DNA·입자와 물리 시계의 논의는
별도 원고 WRRA의 확장 가능성과 접속 조건으로 보존했다.
그 확장 원고의 q = −0.523과 유한 진공 결과는 기존 계산을 그대로 유지한다.
Jeongin 필터의 짧은 흔적과 참고문헌은 유지했다.

검증 입력
활성 주소 2~1,000,000, 기존 α ≈ 1.8996876951, 검증된 낮은 차수의 제타 영점,
K = 8, J = 4, 기존 h ≈ 1.4476731704 및 공개된 5%·26.8% 보정 목표.
WRRA 고유 변환
동일한 주소 가중치·누적 진입·접힘 보존·미짝 포트 판독을 유지하고 위상 구동만 바꾼다.
공통 h의 총량 응답과 같은 5%로 보정한 뒤의 주소별 상태·최소 인수 가족·분포 거리를 읽는다.
산출값
기존 α = 2 결과 4.876893353%와 공동 보정의 세 부문 분할을 보존했다.
정지·등간격·일정 진입의 주소 9 진입률은 각각 80.386717%, 88.580085%, 86.545701%다.
기준 제타 구동의 주소 9 진입률은 85.681301%다.
이번 비교의 구현 검사 {controls['total']}개가 통과했다.
기준 모형의 새 보정 변수는 0개다. 대조 세 구성의 h는 각각 같은 목표로 재보정했다.
반증조건
확률 범위·장부 완전성·보정 재현·기록된 기준 계산·주소 분포 정규화의 실패다.
주소별 값은 산술 모형의 계산 상태이며 관측 입자 확률로 읽으려면 하류 사상이 필요하다.
미짝 포트 판독은 손실 없는 주소 사상을 사용한다. 주소 n을 비트 수나 질량으로 동일시하지 않는다.

재현
rebuild_source/requirements.txt의 패키지를 설치한 뒤 review_r8에서
python phase_control_comparison.py를 실행한다.
입력·변환·산출값·반증조건·36개 검사 내역은 phase_control_comparison_results.json에 있다.
이 스크립트는 제공된 rebuild_source의 기존 프레임 구현과 검증 영점을 사용한다.
renderer_coupling_check.py를 실행하면 기존 20개 렌더러 결합 검사를 재현할 수 있다.
기존 상류는 rebuild_source에서 python reproduce_all.py --contracts로 재실행한다.
상류 178개 검사 기록과 수치 결과 SHA256, 진공 33개·균일 연결 12개·중간 유도 6개·
위상 장부 38개·영점과 프레임 14개·렌더러 20개 검사 기록을 보존했다.
이번 r8에서는 새 대조 비교 36개 검사를 실행했다. 기존 수치 코드는 변경하지 않았다.

문서
기존 수식 35개와 새 주소 분포 거리 정의를 두 원고에 나누어 보존했다.
주 원고에는 native Word 수식 25개, 표 12개, 그림 2개, 참고문헌 9개가 있다.
확장 원고에는 native Word 수식 11개와 표 4개가 있다.
주 원고 {pages}쪽과 확장 원고 {extension_pages}쪽을 각각 렌더링하여 검토했다.
번호 이동은 revision_map_r8.json과 scope_map_r8.json에 기록했다.
review_r8에서 python build_documents.py로 Word를 생성한다.
별도 확장 원고는 python build_extensions.py로 생성한다.
pandoc, python-docx, lxml, matplotlib 및 한글·수학 글꼴이 필요하다.
편집 가능한 주 원본은 manuscript_KO.json이며 manuscript.py가 이를 읽는다.
별도 확장 원본은 extensions_KO.json이다.
Word, PDF, 계산 코드·결과·편집 소스와 SHA256 manifest를 함께 제공한다.

선행 자료
https://doi.org/10.5281/zenodo.23092499
https://github.com/Wonsik-Choi-janefather/wrra-m-0.1
'''
(SRC / 'README_KO.txt').write_text(readme)
sources = [docx, pdf, ext_docx, ext_pdf]
sources += [SRC / name for name in (
    'manuscript.py','build_documents.py','package_deliverables.py','manuscript_KO.json',
    'revision_map_r8.json','scope_map_r8.json','extensions_KO.json','build_extensions.py',
    'phase_control_comparison.py','phase_control_comparison_results.json',
    'renderer_coupling_check.py','renderer_coupling_results.json',
    'vacuum_reference_check.py','vacuum_reference_results.json',
    'twist_bridge_check.py','twist_bridge_results.json','benchmark_derivation.py',
    'benchmark_derivation_results.json','frame_recheck_results.json',
    'phase_ledger_check.py','phase_ledger_results.json','README_KO.txt')]
sources += [p for p in (SRC / 'downstream_reference_0_6').rglob('*') if p.is_file() and '__pycache__' not in p.parts]
sources += [SRC / 'assets/whole_flow_KO.png', SRC / 'assets/phase_controls_KO.png', SRC / 'assets/equations.txt']
sources += [SRC / 'extension_assets/equations.txt']
base = ROOT / 'rebuild_source'
sources += [base / n for n in ('reproduce_all.py','requirements.txt','study_metadata.json','reproduction_results.json')]
sources += list((base / 'baseline').glob('*.json'))
sources += list((base / 'tests').glob('*.py')) + list((base / 'tests').glob('*.json'))
for code in (base / 'work').glob('*/code'):
    for pattern in ('*.py','*.json','*.txt'):
        sources += list(code.glob(pattern))
blocks = json.loads((SRC / 'manuscript_KO.json').read_text())['blocks']
extension_blocks = json.loads((SRC / 'extensions_KO.json').read_text())['blocks']
manifest = {
    'edition':'r8-KO-calibration-controls','date':'2026-10-02','pages_reviewed':pages,
    'authors':['Wonsik Choi','Jeongin Choi'],
    'original_numerical_code_changed':False,'new_control_checks_passed':controls['total'],
    'preserved_renderer_coupling_checks_passed':coupling['total'],
    'baseline_new_fit_parameters':0,'control_thresholds_refitted':3,
    'particle_mass_map_derived':False,'control_address_values_are_observed_particle_probabilities':False,
    'original_equations_preserved_across_main_and_extension_with_label_changes':35,
    'equations':sum(b['kind']=='eq' for b in blocks),
    'tables':sum(b['kind']=='table' for b in blocks),'figures':sum(b['kind']=='fig' for b in blocks),
    'references':sum(b['kind']=='ref' for b in blocks),
    'independent_extension_pages_reviewed':extension_pages,
    'extension_equations':sum(b['kind']=='eq' for b in extension_blocks),
    'extension_tables':sum(b['kind']=='table' for b in extension_blocks),
    'scope':'Main question and supporting appendices; independent extensions in a separate manuscript',
    'previous_upstream_checks_passed':178,'preserved_implementation_records':preserved,
    'unchanged_upstream_result_files':unchanged,
    'files':[{'path':str(p.relative_to(ROOT)),'bytes':p.stat().st_size,
              'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(set(sources))]
}
mp = SRC / 'manifest_r8_KO.json'
mp.write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
sources.append(mp)
archive = OUT / 'WRRA_M_보정대조보강_r8_원고및계산자료.zip'
with ZipFile(archive,'w',ZIP_DEFLATED) as z:
    for p in sorted(set(sources)):
        z.write(p,str(p.relative_to(ROOT)))
    assert z.testzip() is None
print(json.dumps({'pages':pages,'equations':manifest['equations'],'new_control_checks':controls['total'],'zip_files':len(sources)},ensure_ascii=False))
for p in (docx,pdf,ext_docx,ext_pdf,archive):
    print(str(p),p.stat().st_size)
