"""Build the independent expansion manuscript without altering the main paper."""
from pathlib import Path
import json
import build_documents as builder

ROOT=Path(__file__).resolve().parent
source=json.loads((ROOT/'extensions_KO.json').read_text())
builder.TITLES={'KO':source['title']}
builder.SUBTITLES={'KO':source['subtitle']}
builder.BLOCKS={'KO':source['blocks']}
builder.ASSETS=ROOT/'extension_assets'
builder.ASSETS.mkdir(exist_ok=True)
builder.build('KO',stem='WRRA_M_확장가능성과접속조건_한글_r8',source_filename='extensions_KO.json')
