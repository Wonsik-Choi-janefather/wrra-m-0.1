"""Two comparison protocols for the recorded WRRA phase admission rule."""
from pathlib import Path
import importlib.util,json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.font_manager import FontProperties

ROOT=Path(__file__).resolve().parent
UP=ROOT.parent/'rebuild_source/work/zeta_frame_v0_1/code'
spec=importlib.util.spec_from_file_location('wrra_phase_source',UP/'compute.py')
model=importlib.util.module_from_spec(spec);spec.loader.exec_module(model)
record=json.loads((UP/'results.json').read_text())


def main():
    N=record['inputs']['N'];K=record['inputs']['K'];J=record['inputs']['J'];xi=record['inputs']['xi']
    alpha=record['calibration']['alpha'];h0=record['calibration']['sigmoid_threshold_h']
    gamma=np.array([v['gamma_used_double'] for v in record['zeta_zero_validation']])[:J]
    n=np.arange(2,N+1);prime=model.prime_mask(N)[2:]
    weights=n.astype(float)**(-alpha);weights/=weights.sum()
    even=(~prime)&(n%2==0);odd=(~prime)&(n%2==1)
    odd_n=n[odd];odd_w=weights[odd];odd_log=np.log(odd_n)
    dark=float(weights[even].sum());prime_mass=float(weights[prime].sum());available=float(odd_w.sum())
    dbase=model.drive(odd_log,gamma,K,xi);tbase=model.cumulative(dbase,h0)
    base_phi=float(odd_w@tbase);base_dist=odd_w*tbase/base_phi
    cases=[('zeta_dynamic','제타 위상 진입',gamma,xi),
           ('zeta_static','정지 제타 위상',gamma,0.),
           ('equal_frequency','등간격 주파수',np.array([14.,21.,28.,35.]),xi),
           ('constant_admission','일정 진입 장부',None,None)]
    sample_addresses=np.array([9,15,21,25,27,35,49,77,119,161])
    sample_positions=np.searchsorted(odd_n,sample_addresses)
    assert np.array_equal(odd_n[sample_positions],sample_addresses)
    family_masks=[];remaining=np.ones(len(odd_n),bool)
    for p in (3,5,7):
        m=remaining&(odd_n%p==0);family_masks.append((str(p),m));remaining[m]=False
    family_masks.append(('other',remaining))
    checks=[]
    def check(name,passed,value=None):checks.append({'name':name,'passed':bool(passed),'value':value})
    rows=[];samples={}
    for key,label,freq,step in cases:
        delta=np.zeros_like(dbase) if freq is None else model.drive(odd_log,freq,K,step)
        frozen=model.fractions(delta,h0,odd_w,dark,prime_mass)
        h=h0 if key=='zeta_dynamic' else model.fit_threshold(delta,odd_w,.05)
        t=model.cumulative(delta,h);phi=float(odd_w@t)
        dist=odd_w*t/phi
        l1=float(odd_w@np.abs(t-tbase)/available)
        tv=float(np.abs(dist-base_dist).sum()/2)
        family={p:float(odd_w[m]@t[m]) for p,m in family_masks}
        row={'case':key,'label':label,'frequencies':None if freq is None else freq.tolist(),'xi':step,
             'shared_threshold':h0,'shared_threshold_outputs':frozen,
             'refitted_threshold':h,'refitted_outputs':model.fractions(delta,h,odd_w,dark,prime_mass),
             'weighted_admission_L1_difference':l1,'retained_address_total_variation':tv,
             'address_9_admission':float(t[sample_positions[0]]),'family_phi_contributions':family}
        rows.append(row);samples[key]=t[sample_positions].tolist()
        check(key+'_address_admission_probability_range',bool(np.all(t>=0) and np.all(t<=1)))
        check(key+'_shared_threshold_partition_complete',abs(frozen['phenotype']+dark+frozen['return']-1)<1e-12)
        check(key+'_same_target_refit',abs(phi-.05)<1e-12)
        check(key+'_retained_distribution_normalized',abs(float(dist.sum())-1)<1e-12)
        check(key+'_family_partition_complete',abs(sum(family.values())-phi)<1e-12)
        check(key+'_distance_bounds',0<=tv<=1 and 0<=l1<=1)
    lookup={r['case']:r for r in rows}
    original={r['case']:r for r in record['same_aggregate_different_address_controls']}
    for key,old_key in [('zeta_static','static_zeta_phase'),('equal_frequency','equally_spaced_control')]:
        a=lookup[key];b=original[old_key]
        check(key+'_archived_threshold_reproduced',abs(a['refitted_threshold']-b['threshold_refitted_to_5_percent'])<1e-12)
        check(key+'_archived_address9_reproduced',abs(a['address_9_admission']-b['address_9_cumulative_admission'])<1e-12)
        check(key+'_archived_weighted_difference_reproduced',abs(a['weighted_admission_L1_difference']-b['weighted_address_admission_absolute_difference'])<1e-12)
    for key,old_key in [('zeta_static','static_phase'),('constant_admission','zero_drive')]:
        archived=next(r for r in record['frozen_threshold_sensitivity'] if r['case']==old_key)
        check(key+'_archived_shared_threshold_output_reproduced',abs(lookup[key]['shared_threshold_outputs']['phenotype']-archived['phenotype'])<1e-12)
    check('baseline_archived_address_samples_reproduced',all(abs(float(tbase[np.searchsorted(odd_n,r['address'])])-r['cumulative_admission'])<1e-12 for r in record['address_samples']))
    check('constant_admission_matches_beta_summary',np.allclose(samples['constant_admission'],record['terminal']['weighted_effective_beta'],atol=1e-12,rtol=0))
    check('all_refitted_aggregate_partitions_match',all(abs(r['refitted_outputs']['return']-.682)<1e-12 and abs(r['refitted_outputs']['nonphenotypic_Actual']-.268)<1e-12 for r in rows))
    check('refitted_controls_have_distinct_address_states',all(r['retained_address_total_variation']>1e-4 for r in rows[1:]))

    result={'inputs':{'N':N,'alpha':alpha,'J':J,'K':K,'xi_baseline':xi,'verified_zeta_frequencies':gamma.tolist(),
                     'phi_target':.05,'D_target':.268,'shared_threshold':h0},
            'WRRA_transform':'Use the same weights, fold retention, depletion rule and unpaired-port renderer. Compare changed phase drives first with h held fixed, then with each h fitted to the same 5% target. Read address probabilities, disjoint factor families and normalized retained-state distances.',
            'outputs':rows,'sample_addresses':sample_addresses.tolist(),'sample_admissions':samples,
            'falsification_conditions':['The finite reproduction fails normalization, archived outputs or threshold equations.',
                                       'Under a specified carrier-to-particle map, a frozen drive yields incompatible address-family readouts.',
                                       'The declared phase mechanism fails its fixed-parameter closure or coupling conditions.'],
            'scope':'Aggregate reproduction is an explanatory result for each configured WRRA rule. The address distributions distinguish these configurations; these are model state readouts, not observed particle probabilities. The comparison does not establish uniqueness of a zeta drive or derive a microscopic mass map.',
            'checks':checks,'passed':sum(c['passed'] for c in checks),'total':len(checks),
            'all_passed':all(c['passed'] for c in checks)}
    (ROOT/'phase_control_comparison_results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
    font=FontProperties(fname='/usr/local/share/fonts/wrra/NotoSansCJKkr-Regular.otf')
    fig,ax=plt.subplots(figsize=(7.6,3.65),dpi=250)
    pos=np.arange(len(sample_addresses));width=.25
    colors=['#222222','#777777','#B7B7B7']
    for i,(key,label,_,_) in enumerate(cases[1:]):
        diff=(np.array(samples[key])-np.array(samples['zeta_dynamic']))*100
        ax.bar(pos+(i-1)*width,diff,width,label=label,color=colors[i],edgecolor='black',linewidth=.4)
    ax.axhline(0,color='black',linewidth=.7)
    ax.set_xticks(pos);ax.set_xticklabels(sample_addresses)
    ax.set_xlabel('잔존 후보 주소',fontproperties=font,fontsize=10)
    ax.set_ylabel('기준 제타 진입과의 차이  퍼센트포인트',fontproperties=font,fontsize=9)
    ax.legend(prop=font,fontsize=9,frameon=False,ncol=3,loc='upper center',bbox_to_anchor=(.5,1.16))
    ax.spines[['top','right']].set_visible(False)
    ax.grid(axis='y',alpha=.22);ax.set_axisbelow(True)
    fig.tight_layout();(ROOT/'assets').mkdir(exist_ok=True)
    fig.savefig(ROOT/'assets/phase_controls_KO.png',bbox_inches='tight',pad_inches=.08);plt.close(fig)
    print(json.dumps({'passed':result['passed'],'total':result['total'],'all_passed':result['all_passed'],
                      'cases':[{'case':r['case'],'shared_h_phi_percent':r['shared_threshold_outputs']['phenotype']*100,
                                'refit_h':r['refitted_threshold'],'T9':r['address_9_admission'],
                                'TV':r['retained_address_total_variation']} for r in rows]},ensure_ascii=False))
    if not result['all_passed']:raise SystemExit('phase comparison failed')


if __name__=='__main__':main()
