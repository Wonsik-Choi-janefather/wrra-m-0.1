"""Lossless binary address ports and retained-state renderer effects.

This finite implementation verifies the declared port interface; it does not
derive a physical bit count or particle masses from the address label.
"""
from pathlib import Path
import json
import numpy as np

ROOT = Path(__file__).resolve().parent
UP = ROOT.parent / 'rebuild_source/work/two_stage_filter_v1_0/code/results_26_8.json'


def primes_through(N):
    prime = np.ones(N + 1, dtype=bool)
    prime[:2] = False
    for p in range(2, int(N ** .5) + 1):
        if prime[p]:
            prime[p*p::p] = False
    return prime


def finite_port_model(N, beta):
    n = np.arange(2, N + 1)
    prime = primes_through(N)[2:]
    r = n - 2 * (n // 2)
    size = len(n)
    V = np.zeros((2 * (N // 2 + 1), size))
    V[2 * (n // 2) + r, np.arange(size)] = 1
    port_one = np.diag(np.tile([0., 1.], N // 2 + 1))
    Pi = V.T @ port_one @ V
    PC = np.diag((~prime).astype(float))
    eye = np.eye(size)
    A = np.diag(np.where((~prime) & (r == 1), np.sqrt(beta), 1.))
    B = np.diag(prime.astype(float))
    Qphi = PC @ Pi
    Qdark = PC @ (eye - Pi)
    Ephi = A.T @ Qphi @ A
    Edark = A.T @ Qdark @ A
    Ereturn = eye - A.T @ PC @ A
    return locals()


def main():
    base = json.loads(UP.read_text())
    joint = base['joint_output']
    beta = joint['initial_odd_relation_admission']
    checks = []

    def check(name, passed, value=None):
        checks.append({'name': name, 'passed': bool(passed), 'value': value})

    small = finite_port_model(16, beta)
    V, Pi, PC, eye = [small[k] for k in ('V', 'Pi', 'PC', 'eye')]
    Qp, Qd = small['Qphi'], small['Qdark']
    effects = [small[k] for k in ('Ephi', 'Edark', 'Ereturn')]
    close = lambda a, b: np.allclose(a, b, atol=1e-12, rtol=0)
    check('address_isometry', close(V.T @ V, eye))
    encoded_rows = np.argmax(V, axis=0)
    check('address_reconstruction', np.array_equal(2 * (encoded_rows // 2) + encoded_rows % 2, small['n']))
    check('unpaired_port_matches_remainder', close(Pi, np.diag(small['r'])))
    check('composite_projector_matches_return_complement', close(PC, eye-small['B'].T@small['B']))
    check('renderer_projectors_orthogonal_and_complete', close(Qp@Qp,Qp) and close(Qd@Qd,Qd) and close(Qp@Qd,0) and close(Qp+Qd,PC))
    check('all_sector_effects_positive', all(np.linalg.eigvalsh(e).min() >= -1e-12 for e in effects))
    check('all_sector_effects_complete', close(sum(effects),eye))
    expected = [beta*(~small['prime'])*small['r'], (~small['prime'])*(1-small['r']), small['prime']+(1-beta)*(~small['prime'])*small['r']]
    check('effects_equal_original_address_partition', all(close(e,np.diag(v)) for e,v in zip(effects,expected)))
    psi = np.sqrt(np.arange(1, len(small['n'])+1,dtype=float)) * np.exp(1j*small['n']*.37)
    psi /= np.linalg.norm(psi)
    check('coherent_state_norm_preserved', abs(np.linalg.norm(V@psi)-1) < 1e-12)
    probabilities = [float(np.vdot(psi,e@psi).real) for e in effects]
    check('coherent_state_probabilities_complete', min(probabilities)>=-1e-12 and abs(sum(probabilities)-1)<1e-12, probabilities)
    via_port = float(np.vdot(V@small['A']@psi, np.diag(np.tile([0.,1.],9)) @ V @ PC @ small['A'] @ psi).real)
    check('coherent_state_port_and_effect_readout_agree', abs(via_port-probabilities[0])<1e-12)
    ix = {int(n):i for i,n in enumerate(small['n'])}
    check('odd_prime_7_returns_without_expression', effects[0][ix[7],ix[7]]==0 and effects[2][ix[7],ix[7]]==1)
    check('even_composite_8_is_unexpressed', effects[0][ix[8],ix[8]]==0 and effects[1][ix[8],ix[8]]==1)
    check('odd_composite_9_has_admission_weighted_expression', abs(effects[0][ix[9],ix[9]]-beta)<1e-12 and effects[1][ix[9],ix[9]]==0)
    check('renderer_projectors_do_not_open_prime_return_channel', close(small['B']@Qp,0) and close(small['B']@Qd,0))
    bad = np.zeros((9,len(small['n'])))
    bad[small['n']//2,np.arange(len(small['n']))]=1
    check('negative_control_dropped_remainder_detected', not close(bad.T@bad,eye))
    wrong_phi = small['A'].T@Qd@small['A']
    check('negative_control_even_port_expression_detected', wrong_phi[ix[8],ix[8]]>0 and not close(wrong_phi,effects[0]))

    N = joint['N']
    n = np.arange(2,N+1)
    prime = primes_through(N)[2:]
    comp = (~prime).astype(float)
    r = n - 2*(n//2)
    phi = beta*comp*r
    dark = comp*(1-r)
    ret = 1-phi-dark
    w = n.astype(float)**(-joint['alpha']); w /= w.sum()
    fractions = [float(w@e) for e in (phi,dark,ret)]
    original = [joint[k] for k in ('phenotype_fraction','unexpressed_Actual_fraction','source_return_fraction')]
    check('joint_baseline_fractions_preserved', close(fractions,original), fractions)
    w2 = n.astype(float)**(-2); w2 /= w2.sum()
    fixed_phi = float(w2@(comp*r))
    fixed_original = base['old_alpha2_full_composite_limit']['phenotype_fraction']
    check('fixed_alpha2_odd_composite_residue_preserved', abs(fixed_phi-fixed_original)<1e-12, fixed_phi)
    check('all_active_addresses_partitioned', bool(np.all(phi>=0) and np.all(dark>=0) and np.all(ret>=-1e-15) and np.allclose(phi+dark+ret,1,atol=1e-15,rtol=0)))

    result = {
        'inputs': {'N':N,'alpha':joint['alpha'],'initial_admission_beta':beta,'finite_operator_N':16,'active_addresses_start_at':2},
        'WRRA_transform': 'Retain factor relations; losslessly encode n as (floor(n/2), n mod 2); couple the final renderer to the unpaired port on composite residue; pull effects back through initial admission A.',
        'outputs': {'phi_D_R':fractions,'alpha2_odd_composite_residue':fixed_phi,'new_fit_parameters':0},
        'falsification_conditions': [
            'The address encoder loses recoverability or state normalization.',
            'The declared retained-state effects lose positivity, exclusivity or completeness.',
            'A microscopic carrier realization expresses an even retained state without the required unpaired port, or fails the specified coupling on an admitted odd state.',
            'A declared fold-preserving update opens the forbidden normal-return channel.'
        ],
        'scope': 'Finite operator consistency and numerical reproduction under a declared carrier port rule. No physical bit count, microscopic particle masses or unconditional Riemann Hypothesis result is derived.',
        'checks':checks,'passed':sum(c['passed'] for c in checks),'total':len(checks),
        'all_passed':all(c['passed'] for c in checks),
    }
    (ROOT/'renderer_coupling_results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
    print(json.dumps({k:result[k] for k in ('outputs','passed','total','all_passed')},ensure_ascii=False))
    if not result['all_passed']:
        raise SystemExit('Renderer coupling checks failed')


if __name__ == '__main__':
    main()
