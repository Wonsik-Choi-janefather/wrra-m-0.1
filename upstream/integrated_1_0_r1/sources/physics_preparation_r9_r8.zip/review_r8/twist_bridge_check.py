"""Connect upstream fractions to the published WRRA 0.6 uniform load readout."""
from pathlib import Path
import copy
import hashlib
import importlib.util
import json
import math
import numpy as np

ROOT = Path(__file__).resolve().parent
DOWN = ROOT / "downstream_reference_0_6"
spec = importlib.util.spec_from_file_location("wrra_downstream_06", DOWN / "compute.py")
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
p = json.loads((DOWN / "parameters.json").read_text())
b = json.loads((DOWN / "baseline_0_5/parameters.json").read_text())
original_b = copy.deepcopy(b)
old = json.loads((DOWN / "results/summary.json").read_text())
joint = json.loads((ROOT.parent / "rebuild_source/work/two_stage_filter_v1_0/code/results_26_8.json").read_text())["joint_output"]
values = [joint[k] for k in ("phenotype_fraction","unexpressed_Actual_fraction","source_return_fraction")]
trace = sum(values)
fractions = [v / trace for v in values]
mapped = copy.deepcopy(b)
mapped["fraction_phenotype"] = fractions[0]
mapped["fraction_twist_clustering"] = fractions[1]
m.validate(p, mapped)
carrier = m.Carrier(p["lattice_N"], 0)
rho = np.eye(carrier.N) / carrier.N
jc = float(np.trace(rho @ carrier.Kc).real)
jb = float(np.trace(rho @ carrier.Kb).real)
cal = m.calibration(mapped)
old_cal = m.calibration(b)
old_snapshot = m.snapshot(1., jc, jb, p, old_cal)
old_local = m.local_readout(old_snapshot, p, b, old_cal)
present_old = next(x for x in old["present_information_state_outputs"] if x["state"] == "uniform")
checks = {
    "original_parameter_dictionary_preserved": b == original_b,
    "uniform_state_trace_and_positive_spectrum": math.isclose(np.trace(rho).real,1.) and np.linalg.eigvalsh(rho).min() >= 0,
    "published_q_reproduced": math.isclose(old_snapshot["deceleration_q"],present_old["snapshot"]["deceleration_q"],abs_tol=1e-14),
    "published_rotation_reproduced": math.isclose(old_local["v_total_km_s"],present_old["v_total_km_s"],rel_tol=1e-14),
    "published_lensing_reproduced": math.isclose(old_local["finite_patch_lensing"]["alpha_patch_arcsec"],present_old["finite_patch_lensing"]["alpha_patch_arcsec"],rel_tol=1e-14),
    "mapped_R_matches_upstream": math.isclose(cal["fb"],fractions[2],abs_tol=5e-15),
}
rows = []
vac = json.loads((ROOT / "vacuum_reference_results.json").read_text())["inputs"]["trace_normalized_phi_D_R"]
vphi, vd, vr = map(float, vac)
for a in (.5,1.,2.):
    s = m.snapshot(a,jc,jb,p,cal)
    volume = a**3
    # Compare the independently implemented vacuum energy-volume map to the downstream state readout.
    expected_density = ((vphi+vd) + vr*volume) / volume
    checks[f"a{a}_same_energy_density_as_vacuum_map"] = math.isclose(s["density_total_over_ucrit"],expected_density,abs_tol=5e-14)
    checks[f"a{a}_same_pressure_as_vacuum_map"] = math.isclose(s["pressure_over_ucrit"],-vr,abs_tol=5e-14)
    rows.append({"a":a,"snapshot":s,"local_readout":m.local_readout(s,p,mapped,cal)})
present = next(x for x in rows if x["a"] == 1.)
checks = {k:bool(v) for k,v in checks.items()}
result = {
    "title":"Upstream fraction to WRRA 0.6 uniform twist load bridge",
    "status":"executed conditional uniform mapping; original 0.6 calibration preserved",
    "inputs":{"upstream_joint_output":joint,"normalized_phi_D_R":fractions,
              "published_baseline_parameters":b,"mapped_private_parameters":mapped,
              "carrier_grid":carrier.N,"uniform_state_assignment":"rho=I_N/N",
              "computed_uniform_loads":{"Jc":jc,"Jb":jb},
              "downstream_code_sha256":hashlib.sha256((DOWN/"compute.py").read_bytes()).hexdigest()},
    "transformation":"address shares -> common uniform carrier readout -> same energy density and pressure -> twist and local matching",
    "calibration":cal,"published_reference":{"snapshot":old_snapshot,"local_readout":old_local},
    "outputs":rows,"present":present,"checks":checks,"passed":sum(checks.values()),
    "total":len(checks),"all_passed":all(checks.values()),
    "falsification_and_scope":[
        "vacuum energy-volume map must match downstream density and pressure",
        "mapped sectors must preserve the same total normalization",
        "original published readout must be reproduced without changing source parameters",
        "uniform information state and D-to-clustering assignment are declared mappings",
        "local response and Phi=Psi lens condition are inherited calibrated inputs",
        "no new observed galaxy fit or microscopic particle-state mapping is performed",
        "photon twist-redshift kernel and actual spatial topology remain unspecified"]
}
assert result["all_passed"], [k for k,v in checks.items() if not v]
(ROOT/"twist_bridge_results.json").write_text(json.dumps(result,ensure_ascii=False,indent=2))
print(json.dumps({"passed":result["passed"],"total":result["total"],"present":present},ensure_ascii=False,indent=2))
