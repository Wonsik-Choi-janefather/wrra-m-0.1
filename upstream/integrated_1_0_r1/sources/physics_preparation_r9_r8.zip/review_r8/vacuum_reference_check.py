"""Finite WRRA candidate load map; this is not a Standard Model loop calculation."""
from decimal import Decimal, localcontext
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parent
INPUT = ROOT.parent / "rebuild_source/work/two_stage_filter_v1_0/code/results_26_8.json"
D = Decimal

def run():
    with localcontext() as ctx:
        ctx.prec = 200
        joint = json.loads(INPUT.read_text())["joint_output"]
        raw = [D(str(joint[k])) for k in
               ("phenotype_fraction", "unexpressed_Actual_fraction", "source_return_fraction")]
        total = sum(raw)
        unit = D("1e-50")
        phi, dark = [(x / total).quantize(unit) for x in raw[:2]]
        returned = 1 - phi - dark
        probs = [D(0), phi, dark, returned]
        u_star, volume0 = D(1), D(1)
        tolerance = D("1e-65")

        def energy(volume, offset, physical_delta=D(0), reference_only_delta=D(0)):
            ref = offset * volume
            levels = [ref,
                      ref + u_star * volume0 + physical_delta * volume,
                      ref + u_star * volume0 + physical_delta * volume,
                      ref + physical_delta * volume]
            current_trace = sum(p * h for p, h in zip(probs, levels))
            reference_trace = levels[0] + reference_only_delta * volume
            relative = current_trace - reference_trace
            background = returned * u_star * volume
            return relative + background, relative, background

        def pressure(volume, offset, delta=D(0)):
            step = D("1e-8")
            hi = energy(volume + step, offset, delta)[0]
            lo = energy(volume - step, offset, delta)[0]
            return -(hi - lo) / (2 * step)

        def close(a, b):
            return abs(a - b) <= tolerance

        offsets = [D(0), D(1), D("1e40"), D("1e120")]
        volumes = [D("0.25"), D(1), D(4)]
        checks, rows = {}, []
        baseline_pressure = -returned * u_star
        matter = (phi + dark) * u_star * volume0
        for offset in offsets:
            for volume in volumes:
                tag = f"C{offset}_V{volume}"
                total_energy, relative, background = energy(volume, offset)
                expected = matter + returned * u_star * volume
                p = pressure(volume, offset)
                checks[tag + "_energy_common_offset_invariant"] = close(total_energy, expected)
                checks[tag + "_pressure_from_same_energy_function"] = close(p, baseline_pressure)
                rows.append({"reference_density_C_over_u_star": str(offset),
                             "V_over_V0": str(volume),
                             "relative_matter_energy_over_u_star_V0": str(relative),
                             "background_energy_over_u_star_V0": str(background),
                             "total_energy_over_u_star_V0": str(total_energy),
                             "pressure_over_u_star": str(p)})
        checks["normalized_trace"] = sum(probs) == 1
        checks["three_input_shares_preserved_to_float_accuracy"] = all(
            abs(p - r) < D("1e-14") for p, r in zip(probs[1:], raw))
        checks["background_w_equals_minus_one"] = close(
            baseline_pressure / (returned * u_star), D(-1))
        checks["matter_energy_constant_with_volume"] = close(
            energy(D("0.25"), D("1e120"))[1], energy(D(4), D("1e120"))[1])
        delta = D("0.125")
        v = D("1.75")
        added = energy(v, D("1e120"), delta)[0] - energy(v, D("1e120"))[0]
        checks["physical_state_energy_change_survives_subtraction"] = close(added, delta * v)
        checks["physical_state_pressure_change_survives_subtraction"] = close(
            pressure(v, D("1e120"), delta) - baseline_pressure, -delta)
        wrong = energy(D(1), D(1), reference_only_delta=D("0.5"))[0]
        checks["inconsistent_reference_change_detected"] = not close(wrong, energy(D(1), D(1))[0])
        def omega_at(volume):
            es = [phi * volume0, dark * volume0, returned * volume]
            return [x / sum(es) for x in es]
        checks["expanded_background_share_increases"] = omega_at(D(4))[2] > omega_at(D(1))[2]
        checks["contracted_background_share_decreases"] = omega_at(D("0.25"))[2] < omega_at(D(1))[2]
        result = {
            "title": "WRRA finite vacuum reference and background load check",
            "status": "proposed finite energy map executed; not a Standard Model vacuum derivation",
            "input_sha256": hashlib.sha256(INPUT.read_bytes()).hexdigest(),
            "inputs": {"upstream_joint_output": joint,
                       "raw_trace": str(total),
                       "trace_normalized_phi_D_R": [str(x) for x in probs[1:]],
                       "u_star": "1 in energy density units",
                       "V0": "1 in volume units",
                       "precision_decimal_digits": ctx.prec,
                       "offsets_C_over_u_star": [str(x) for x in offsets]},
            "transformation": {
                "reference_state": "rho0=diag(1,0,0,0)",
                "retained_and_returned_state": "rhohat=diag(0,f_phi,f_D,f_R)",
                "micro_H": "diag(CV,CV+u_star*V0,CV+u_star*V0,CV)",
                "gravitating_energy": "Tr[(rhohat-rho0)H]+f_R*u_star*V",
                "physical_delta_control": "add delta*V only to active-state levels",
                "scope": "a four-state homogeneous compression of the address ledger"}
            ,
            "outputs": {"rows": rows, "V1_shares": [str(x) for x in omega_at(D(1))],
                        "V025_shares": [str(x) for x in omega_at(D("0.25"))],
                        "V4_shares": [str(x) for x in omega_at(D(4))],
                        "background_w": "-1",
                        "physical_delta_energy_survives": str(added),
                        "physical_delta_pressure_survives": str(-delta)},
            "checks": checks,
            "passed": sum(checks.values()),
            "total": len(checks),
            "all_passed": all(checks.values()),
            "falsification_and_open_conditions": [
                "common offset must leave energy and pressure unchanged",
                "physical state-dependent energy changes must remain in the gravitational ledger",
                "same energy function must yield the declared volume pressure",
                "covariant stress tensor and conservation have not been calculated",
                "Standard Model radiative corrections and phase transitions have not been calculated",
                "background density remains calibrated by u_star and the upstream R fraction",
                "no protection of this background scale against non-common radiative terms is demonstrated"]
        }
        (ROOT / "vacuum_reference_results.json").write_text(json.dumps(result, ensure_ascii=False, indent=2))
        assert result["all_passed"], [k for k, v in checks.items() if not v]
        print(json.dumps({"passed": result["passed"], "total": result["total"],
                          "all_passed": result["all_passed"], "offset_max": "1e120",
                          "E_total_V1_over_u_star_V0": str(energy(D(1), D("1e120"))[0]),
                          "p_over_u_star": str(baseline_pressure)}, indent=2))

if __name__ == "__main__":
    run()
