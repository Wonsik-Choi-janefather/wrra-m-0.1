"""Connect recorded phase closure outputs to the finite and uniform WRRA load.

This is a coarse sector map. It does not derive particle masses, physical time,
or the input exponent and threshold from zeta zeros.
"""
from pathlib import Path
from decimal import Decimal, localcontext
import copy
import hashlib
import importlib.util
import json
import math
import numpy as np

ROOT = Path(__file__).resolve().parent
FRAME = ROOT.parent / 'rebuild_source/work/zeta_frame_v0_1/code/results.json'
UP = ROOT.parent / 'rebuild_source/work/two_stage_filter_v1_0/code/results_26_8.json'
DOWN = ROOT / 'downstream_reference_0_6'
spec = importlib.util.spec_from_file_location('phase_downstream', DOWN / 'compute.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)

def finite_energy(fractions, volume, offset):
    with localcontext() as ctx:
        ctx.prec = 200
        raw = list(map(lambda x: Decimal(str(x)), fractions))
        total = sum(raw)
        phi, dark = [x / total for x in raw[:2]]
        returned = 1 - phi - dark
        v, c = Decimal(str(volume)), Decimal(str(offset))
        reference = c * v
        levels = [reference, reference + 1, reference + 1, reference]
        current = sum(p * h for p, h in zip([0, phi, dark, returned], levels))
        return current - reference + returned * v

frame = json.loads(FRAME.read_text())
recheck = json.loads((ROOT / 'frame_recheck_results.json').read_text())
joint = json.loads(UP.read_text())['joint_output']
parameters = json.loads((DOWN / 'parameters.json').read_text())
baseline = json.loads((DOWN / 'baseline_0_5/parameters.json').read_text())
unchanged_baseline = copy.deepcopy(baseline)
carrier = m.Carrier(parameters['lattice_N'], 0)
rho = np.eye(carrier.N) / carrier.N
jc = float(np.trace(rho @ carrier.Kc).real)
jb = float(np.trace(rho @ carrier.Kb).real)
cases = [(4, next(r for r in frame['frozen_threshold_sensitivity'] if r['case'] == 'recovery_after_4_frames')),
         (8, frame['terminal']),
         (16, next(r for r in frame['frozen_threshold_sensitivity'] if r['case'] == 'recovery_after_16_frames'))]
checks = {'recomputed_phase_checks_pass': recheck['verification']['all_passed'],
          'recomputed_phase_terminal_matches_record': recheck['terminal'] == frame['terminal'],
          'phase_beta_summary_matches_static_beta': abs(frame['terminal']['weighted_effective_beta'] - joint['initial_odd_relation_admission']) < 1e-12}
rows = []
for k, row in cases:
    raw = [row[name] for name in ('phenotype', 'nonphenotypic_Actual', 'return')]
    total = sum(raw)
    shares = [x / total for x in raw]
    checks[f'K{k}_normalized_positive_sectors'] = all(x >= 0 for x in shares) and math.isclose(sum(shares), 1, abs_tol=1e-14)
    mapped = copy.deepcopy(baseline)
    mapped['fraction_phenotype'], mapped['fraction_twist_clustering'] = shares[:2]
    m.validate(parameters, mapped)
    calibration = m.calibration(mapped)
    snapshots = []
    for a in (.5, 1., 2.):
        v = a**3
        snapshot = m.snapshot(a, jc, jb, parameters, calibration)
        e0 = finite_energy(shares, v, 0)
        eh = finite_energy(shares, v, '1e120')
        with localcontext() as ctx:
            ctx.prec = 200
            step = Decimal('1e-8')
            pressure = -(finite_energy(shares, Decimal(str(v)) + step, '1e120') - finite_energy(shares, Decimal(str(v)) - step, '1e120')) / (2 * step)
        checks[f'K{k}_a{a}_common_offset_invariant'] = abs(e0 - eh) < Decimal('1e-65')
        checks[f'K{k}_a{a}_same_density'] = math.isclose(snapshot['density_total_over_ucrit'], float(e0) / v, abs_tol=5e-14)
        checks[f'K{k}_a{a}_same_pressure'] = math.isclose(snapshot['pressure_over_ucrit'], float(pressure), abs_tol=5e-14)
        snapshots.append({'a': a, 'snapshot': snapshot})
    present = next(r['snapshot'] for r in snapshots if r['a'] == 1.)
    checks[f'K{k}_uniform_q_from_same_load'] = math.isclose(present['deceleration_q'], .5 * (1 - 3 * shares[2]), abs_tol=1e-13)
    rows.append({'K': k, 'normalized_phi_D_R': shares, 'effective_beta': row['weighted_effective_beta'],
                 'present_q0': present['deceleration_q'], 'outputs': snapshots})
checks['baseline_parameters_preserved'] = baseline == unchanged_baseline
qphi = np.diag([0., 1., 0., 0.])
rho_dark = np.diag([0., 0., 1., 0.])
unexpressed_readout = float(np.trace(rho_dark @ qphi))
unexpressed_energy = finite_energy([0, 1, 0], 1, '1e120')
checks['zero_phenotype_readout_keeps_positive_load'] = unexpressed_readout == 0 and unexpressed_energy == 1
checks = {key: bool(value) for key, value in checks.items()}
result = {'title': 'WRRA phase closure to common sector load check',
          'inputs': {'frame_file_sha256': hashlib.sha256(FRAME.read_bytes()).hexdigest(),
                     'frame_inputs': frame['inputs'], 'calibration': frame['calibration'],
                     'uniform_carrier_Jc_Jb': [jc, jb]},
          'transformation': 'phase cumulative admission -> normalized sectors -> relative energy with R background -> uniform downstream pressure and geometry',
          'outputs': rows, 'unexpressed_control': {'phenotype_effect_expectation': unexpressed_readout,
                                                  'positive_relative_energy': str(unexpressed_energy)},
          'checks': checks, 'passed': sum(checks.values()), 'total': len(checks), 'all_passed': all(checks.values()),
          'scope': ['aggregate sector mapping, not an address-by-address particle mass map',
                    'initial exponent and threshold remain calibrated inputs',
                    'phase frames and closure times are dimensionless',
                    'same inherited finite energy and uniform geometry rules are used',
                    'zero phenotype effect is not a measurement of inertial mass'],
          'falsification': ['per-frame normalization or reproduced inputs fail',
                            'relative energy or pressure depends on common offset',
                            'uniform downstream load disagrees with the same finite energy function',
                            'a specified physical mass map or clock conflicts with shared-state outputs']}
assert result['all_passed'], [k for k, v in checks.items() if not v]
(ROOT / 'phase_ledger_results.json').write_text(json.dumps(result, ensure_ascii=False, indent=2))
print(json.dumps({'passed': result['passed'], 'total': result['total'],
                  'K_q0': [[r['K'], r['present_q0']] for r in rows]}, ensure_ascii=False))
