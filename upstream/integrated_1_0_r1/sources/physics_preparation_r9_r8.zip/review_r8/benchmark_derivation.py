"""Reader-facing derivation and conditional cosmology benchmark.

The upstream model and its recorded outputs are preserved. This script checks
the finite-sum identities used in Appendix D and converts published flat-LCDM
matter-density constraints to q0. It performs no observational likelihood fit.
"""
from pathlib import Path
import importlib.util
import json
import math
import numpy as np
from scipy.optimize import brentq

ROOT = Path(__file__).resolve().parent
UP = ROOT.parent / 'rebuild_source/work/two_stage_filter_v1_0/code'
spec = importlib.util.spec_from_file_location('recorded_upstream_compute', UP / 'compute.py')
up = importlib.util.module_from_spec(spec)
spec.loader.exec_module(up)
recorded = json.loads((UP / 'results_26_8.json').read_text())
limit = recorded['joint_output']['N']
numbers = np.arange(2, limit + 1, dtype=float)
logs = np.log(numbers)
half_count = limit // 2 - 1
is_prime = up.prime_mask(limit)[2:]

def sums(alpha):
    weight = np.exp(-alpha * logs)
    denominator = float(weight.sum())
    half = float(weight[:half_count].sum())
    prime = float(weight[is_prime].sum())
    even = 2**(-alpha) * half / denominator
    odd = 1 - even - prime / denominator
    return {'alpha': alpha, 'Z_N': denominator, 'Z_half': half,
            'P_N': prime, 'even_composite_share': even,
            'odd_composite_share': odd, 'prime_share': prime / denominator}

alpha = float(brentq(lambda a: sums(a)['even_composite_share'] - .268,
                     1.8, 2., xtol=1e-12))
calibrated = sums(alpha)
beta = .05 / calibrated['odd_composite_share']
fractions = [beta * calibrated['odd_composite_share'],
             calibrated['even_composite_share']]
fractions.append(1 - sum(fractions))
fixed = sums(2.)
q_wrra = .5 * (1 - 3 * fractions[2])
bridge = json.loads((ROOT / 'twist_bridge_results.json').read_text())
q_recorded_bridge = bridge['present']['snapshot']['deceleration_q']
benchmarks = []
for name, mean, error, source in [
    ('Planck 2018 TT,TE,EE+lowE+lensing', .3153, .0073,
     'https://doi.org/10.1051/0004-6361/201833910'),
    ('Pantheon+ SNe Ia alone', .334, .018,
     'https://doi.org/10.3847/1538-4357/ac8e04'),
]:
    q = 1.5 * mean - 1
    benchmarks.append({'name': name, 'source': source,
                       'flat_LCDM_Omega_m_mean': mean,
                       'Omega_m_68_percent_error': error,
                       'q0_converted': q, 'q0_converted_error': 1.5 * error,
                       'WRRA_minus_benchmark_central_q0': q_wrra - q})

checks = {
    'finite_even_identity_matches_recorded_share': abs(
        calibrated['even_composite_share'] - recorded['joint_output']['unexpressed_Actual_fraction']) < 1e-12,
    'finite_complement_identity_matches_recorded_odd_share': abs(
        calibrated['odd_composite_share'] - recorded['joint_output']['odd_composite_available_fraction']) < 1e-12,
    'root_matches_recorded_alpha': abs(alpha - recorded['calibration']['alpha_fitted_to_26_8_percent']) < 1e-12,
    'beta_matches_recorded_beta': abs(beta - recorded['calibration']['beta_fitted_to_5_percent']) < 1e-12,
    'fixed_alpha2_matches_recorded_odd_share': abs(
        fixed['odd_composite_share'] - recorded['old_alpha2_full_composite_limit']['phenotype_fraction']) < 1e-12,
    'partition_and_q_match_uniform_bridge': max(abs(x-y) for x,y in zip(
        fractions, bridge['inputs']['normalized_phi_D_R'])) < 1e-12 and abs(q_wrra - q_recorded_bridge) < 1e-12,
}
report = {
    'status': 'finite identities and conditional benchmark; no new data fit',
    'inputs': {'N': limit, 'declared_targets': {'D': .268, 'phi': .05},
               'alpha_root_bracket': [1.8, 2.], 'root_xtol': 1e-12,
               'prime_classification': 'existing verified upstream prime mask'},
    'transformation': 'factor-2 finite sum and prime complement -> alpha root -> beta -> completeness -> uniform q0',
    'fixed_alpha2': fixed, 'calibrated': calibrated, 'beta': beta,
    'phi_D_R': fractions, 'q0_WRRA_uniform': q_wrra,
    'Planck_baryon_central_conversion': .02237 / .6736**2,
    'benchmarks': benchmarks, 'checks': checks, 'all_passed': all(checks.values()),
    'scope': ['q0 conversion assumes flat LCDM and negligible current radiation',
              'observational errors describe published model-dependent constraints',
              'WRRA fractions are calibrated outputs, not independent fitted cosmological estimates',
              'no supernova distance-modulus or CMB likelihood is fitted'],
    'falsification': ['finite identities or root must reproduce recorded upstream values',
                      'the same pressure and energy assignment must reproduce q0',
                      'future direct observational tests require the photon and redshift map and data covariance']
}
assert report['all_passed'], checks
(ROOT / 'benchmark_derivation_results.json').write_text(
    json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps({k: report[k] for k in ['fixed_alpha2','calibrated','beta','phi_D_R','q0_WRRA_uniform','all_passed']}, indent=2))
