"""Editable Korean manuscript source for r8; equations are retained as LaTeX."""
from pathlib import Path
import json
ROOT=Path(__file__).resolve().parent
SOURCE=json.loads((ROOT/'manuscript_KO.json').read_text())
TITLES={'KO':SOURCE['title']}
SUBTITLES={'KO':SOURCE['subtitle']}
BLOCKS={'KO':SOURCE['blocks']}
