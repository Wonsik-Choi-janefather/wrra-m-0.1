WRRA-M 입자 잔존 주소와 접힘 붕괴 탐색 0.1
최원식 2026-10-01

재현
python -m pip install -r requirements.txt
python compute.py
python channel_readout.py

입자 질량·자기모멘트·중성자 수명은 보정 입력이다. 주소 9·45·75는 구성 선택이다.
강력·약력·전자기력·스핀은 각각의 판독과 검사를 갖는다. 힘의 세기와 미시 전환율은 후속 연결이다.
보정 입력, 후보 목록, 보존 장부와 검증은 results.json 및 channel_results.json에 기록했다.
제타 입력의 원본 커밋과 SHA256은 results.json에 포함된다.

원고 재생성
python build_doc.py
python-docx, lxml, matplotlib, Pandoc 및 Noto Sans CJK KR와 Latin Modern Math 글꼴 필요.
