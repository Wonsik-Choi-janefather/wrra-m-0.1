WRRA-M 내부 접힘 혼합과 핵자 전류 0.3
최원식 2026-10-02

python -m pip install -r requirements.txt
python compute.py

두 경로의 입력 역할과 구성 규칙은 inputs.json과 results.json에 기록했다.
자기모멘트만으로 보정한 단순 경로는 관측 축벡터와 맞지 않는다.
공동 경로는 관측 축벡터로 내부 혼합을 보정하고 정적 집단 전자기 성분을 정한다.
38개 구현 검사. 부모 코드는 함께 고정했고 계산은 인터넷을 사용하지 않는다.

Word 재생성: python build_doc.py
python-docx, lxml, matplotlib, Pandoc 및 Noto Sans CJK KR와 Latin Modern Math 필요.
