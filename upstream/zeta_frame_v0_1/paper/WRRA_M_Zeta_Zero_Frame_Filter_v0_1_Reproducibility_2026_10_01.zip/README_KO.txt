WRRA-M 제타 영점 프레임 필터 계산 부록 0.1
최원식 2026-10-01

실행
python -m pip install -r requirements.txt
python compute.py --output results.json

필터 규칙, 보정 출처 및 모든 민감도와 검증은 results.json에 포함되어 있다.
α는 26.8%에, sigmoid 임계값 h는 5%에 보정했다. K=8, J=4, ξ=0.1은 고정 구성값이다.
프레임은 무차원이며 산술 가중치의 에너지 판독은 상위 구조 가설 1.0의 후속 과제다.

논문 생성
python build_doc.py
python-docx, matplotlib, lxml, Pandoc, Noto Sans CJK KR, Latin Modern Math 필요.
