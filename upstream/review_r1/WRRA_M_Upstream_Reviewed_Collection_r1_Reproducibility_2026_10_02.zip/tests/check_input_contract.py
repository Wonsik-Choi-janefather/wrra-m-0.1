#!/usr/bin/env python3
"""Independent controls of published input handling and baseline preservation."""
from pathlib import Path
import copy,importlib.util,json,math,subprocess,sys,tempfile,shutil
import numpy as np
from scipy.integrate import quad
ROOT=Path(__file__).resolve().parents[1]
CODE=ROOT/'work/internal_mixing_v0_3/code'
sys.path.insert(0,str(CODE))
import compute as child
old=json.loads((ROOT/'baseline/internal_mixing_v0_3__results.json').read_text())
base=json.loads((CODE/'inputs.json').read_text())
checks={};rows=[]
for p in (3,5,7,11):
 for N in (11,31,100,1000000):
  total=0.;k=1
  while p**k<=N:total+=(p**k)**(-base['inherited']['alpha']);k+=1
  checks[f'direct_sum_p{p}_N{N}']=math.isclose(child.euler_activity(p,base['inherited']['alpha'],N),total,rel_tol=3e-15,abs_tol=1e-18)
Q=base['masses']['neutron']-base['masses']['proton']-base['masses']['electron'];me=base['masses']['electron'];W0=1+Q/me
for em in (0.,base['weak_constants']['alpha_em']/2,base['weak_constants']['alpha_em']):
 def independent(W):
  momentum=math.sqrt(W*W-1)
  F=1 if em==0 else (2*math.pi*em*W/momentum)/(-math.expm1(-2*math.pi*em*W/momentum))
  return momentum*F*W*(W0-W)**2
 ref=quad(independent,1,W0,epsabs=1e-12,epsrel=1e-11)[0]
 checks[f'independent_phase_EM{em}']=math.isclose(child.phase(Q,me,em),ref,rel_tol=2e-10)
cases=[('baseline',None,None),('N100',('inherited','N'),100),('alpha1.7',('inherited','alpha'),1.7),('half_EM',('weak_constants','alpha_em'),base['weak_constants']['alpha_em']/2),('zero_EM',('weak_constants','alpha_em'),0.),('GF_plus5pct',('weak_constants','GF_GeV_minus2'),base['weak_constants']['GF_GeV_minus2']*1.05),('Vud_minus1pct',('weak_constants','Vud'),base['weak_constants']['Vud']*.99),('hbar_plus2pct',('weak_constants','hbar_MeV_s'),base['weak_constants']['hbar_MeV_s']*1.02),('kappa_minus10pct',('inherited','kappa'),base['inherited']['kappa']*.9),('axial1.3',('axial_comparison','signed_lambda'),-1.3)]
with tempfile.TemporaryDirectory() as tmp:
 path=Path(tmp)
 for f in CODE.glob('*.py'):shutil.copy2(f,path/f.name)
 for name,keys,value in cases:
  inp=copy.deepcopy(base)
  if keys:inp[keys[0]][keys[1]]=value
  (path/'inputs.json').write_text(json.dumps(inp))
  proc=subprocess.run([sys.executable,str(path/'compute.py')],capture_output=True,text=True)
  if proc.returncode:raise RuntimeError(name+'\n'+proc.stderr)
  r=json.loads((path/'results.json').read_text())
  mass=inp['masses'];phys=inp['weak_constants'];ri=inp['inherited'];g=r['principal_magnetic_fit']['axial_magnitude']
  activities=[]
  for p in (3,5):
   vals=[];k=1
   while p**k<=ri['N']:vals.append((p**k)**(-ri['alpha']));k+=1
   activities.append(sum(vals))
  rp=activities[0]*activities[1]
  independent_rate=ri['kappa']**2*rp*(phys['GF_GeV_minus2']*1e-6)**2*phys['Vud']**2*mass['electron']**5/(2*math.pi**3*phys['hbar_MeV_s'])*(1+3*g*g)*child.phase(mass['neutron']-mass['proton']-mass['electron'],mass['electron'],phys['alpha_em'])
  checks[name+'_end_to_end_declared_inputs']=math.isclose(1/r['rate_transfer']['fixed_parent_kappa_mean_life_s'],independent_rate,rel_tol=3e-14)
  checks[name+'_frozen_reference_unchanged']=r['inputs']['parent_calibration_reference']==base['parent_calibration_reference']
  rows.append({'case':name,'N_used':r['input_transfer']['N_used'],'alpha_em_used':r['input_transfer']['alpha_em_used'],'activity_product':rp,'mean_life_s':r['rate_transfer']['fixed_parent_kappa_mean_life_s'],'joint_mean_life_s':r['joint_calibrated_internal_state']['mean_life_with_inherited_kappa_s']})
  if name=='baseline':
   for key in ('finite_state_construction','effective_mass_current_choice','principal_magnetic_fit','binding_ansatz','axial_comparison','magnetic_identifiability_family','rate_transfer','joint_calibrated_internal_state','joint_prime_family_cases','prime_family_cases','transport'):
    checks['baseline_preserved_'+key]=r[key]==old[key]
 for section,key,value in [('inherited','N',10),('inherited','N',100.5),('inherited','alpha',0),('weak_constants','alpha_em',-.1),('masses','neutron',938.3)]:
  inp=copy.deepcopy(base);inp[section][key]=value
  try:child.validate_inputs(inp);passed=False
  except ValueError:passed=True
  checks['reject_invalid_'+section+'_'+key+'_'+str(value)]=passed
checks['frozen_parent_kernel_hash']=__import__('hashlib').sha256((CODE/'parent_kernel.py').read_bytes()).hexdigest()==base['provenance']['parent_kernel_sha256']
result={'checks':checks,'passed':sum(checks.values()),'total':len(checks),'all_passed':all(checks.values()),'cases':rows}
(ROOT/'tests/input_contract_results.json').write_text(json.dumps(result,indent=2))
assert result['all_passed'],{k:v for k,v in checks.items() if not v}
print(json.dumps(result,indent=2))
