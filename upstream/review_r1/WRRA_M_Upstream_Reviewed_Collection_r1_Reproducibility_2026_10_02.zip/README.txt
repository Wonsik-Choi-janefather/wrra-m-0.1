WRRA M Upstream Studies Reviewed Collection r1
Wonsik Choi / 최원식, Independent Researcher, Seoul
ORCID 0009-0001-4263-9772
Date: 2026-10-02. Collection version: 1.0-r1.
Collection DOI: 10.5281/zenodo.23092499.

This collection contains reviewed versions of five upstream studies:
1. Two-stage filter hypothesis 1.0-r1
2. Zeta-zero frame appendix 0.1-r1
3. Particle residue and decay trial 0.1-r1
4. Fold-current and beta-rate bridge 0.2-r1
5. Internal mixing and shared nucleon currents 0.3-r1

Evaluation order: verified inputs -> WRRA transformations -> outputs ->
falsification conditions. Known-observable reproduction is an explanatory
and reality-consistency accomplishment. Calibration roles are explicit.

Reproduce all calculations after extracting this archive:
  python -m pip install -r requirements.txt
  python reproduce_all.py --contracts
Expected: 122 implementation checks plus 56 added controls = 178 passed.
The baseline/ directory preserves the original results and 121-check audit.

Revision r1 corrections:
- internal 0.3 now uses declared N and electromagnetic alpha in inputs.json;
- parent_calibration_reference freezes the inherited 0.2 calibration inputs;
- changed-input lifetime checks use explicit reference-transfer ratios;
- the original parent_kernel.py SHA256 is preserved;
- zeta source/appendix.py reads code/results.json in the public layout;
- particle Trial A separates 142527 raw candidates and 141790 valid pairs;
- all five papers begin with the review ledger and a corrected r1 label.

The fundamental integer prime labels remain declared encodings. The joint
internal nucleon calibration returns magnetic moments and axial coupling
in one shared state. The c1=0 response discrepancy and free-c1 family are
retained as constraints. Core 1.0, MCC 2.3.2 and downstream 0.9-r1 are
separate preserved references; downstream DOI: 10.5281/zenodo.23091892.

Each work/<study>/code/ contains the numerical code and results. Manuscript
sources and builders are in code/ for the three particle studies and in
source/ for the upper hypothesis and zeta appendix. Regenerate a Word file
by running python build_doc.py in its builder directory. Pandoc must be
installed. PDF rendering additionally requires LibreOffice. Figures require an installed Noto Sans CJK KR font (for example, the
fonts-noto-cjk system package). The builders use an explicit font file when present, otherwise discover the
font by family name. Set WRRA_CJK_FONT to a Korean Noto .otf file if needed.
Missing fonts produce an error instead of a silent Korean-glyph fallback. All published Word equations are editable.

papers/ contains all six final PDFs and Word documents. report/ contains
the consolidated report source. SHA256SUMS lists every payload except itself.
CC BY 4.0: https://creativecommons.org/licenses/by/4.0/
Original repository baseline: e9dc4be98c095152cf94d9eb631b921da3ab51e7.
