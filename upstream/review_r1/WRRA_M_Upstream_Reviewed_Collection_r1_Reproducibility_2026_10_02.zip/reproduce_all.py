#!/usr/bin/env python3
"""Reproduce the five reviewed studies and verify their result ledgers."""
from pathlib import Path
import argparse,json,subprocess,sys,hashlib
ROOT=Path(__file__).resolve().parent
JOBS={
 'two_stage_filter_v1_0':[('compute.py',['--max-N','1000000','--out','results.json'],'results.json'),('partition_26_8.py',[],'results_26_8.json'),('analytic_limit.py',[],'analytic_limit.json')],
 'zeta_frame_v0_1':[('compute.py',[],'results.json')],
 'particle_residue_decay_v0_1':[('compute.py',[],'results.json'),('channel_readout.py',[],'channel_results.json')],
 'fold_decay_v0_2':[('compute.py',[],'results.json')],
 'internal_mixing_v0_3':[('compute.py',[],'results.json')]}
def bool_checks(obj):
 ledger=obj.get('verification',obj.get('checks',{}))
 ledger=ledger.get('checks',ledger)
 return [(k,v) for k,v in ledger.items() if isinstance(v,bool) and k!='all_passed']

def main():
 parser=argparse.ArgumentParser();parser.add_argument('--contracts',action='store_true',help='also run independent input-contract controls');args=parser.parse_args()
 rows=[]
 for name,jobs in JOBS.items():
  code=ROOT/'work'/name/'code'
  for script,argv,result in jobs:
   old=(code/result).read_bytes()
   proc=subprocess.run([sys.executable,str(code/script),*argv],cwd=code,capture_output=True,text=True)
   if proc.returncode:raise RuntimeError(f'{name}/{script}\n{proc.stderr}')
   new=(code/result).read_bytes();obj=json.loads(new);checks=bool_checks(obj)
   if old!=new:raise AssertionError(f'result drift: {name}/{result}')
   if not all(v for _,v in checks):raise AssertionError(checks)
   rows.append({'study':name,'script':script,'result':result,'checks':len(checks),'all_passed':True,'result_sha256':hashlib.sha256(new).hexdigest(),'matches_reviewed_result_byte_for_byte':True})
 summary={'rows':rows,'implementation_checks':sum(x['checks'] for x in rows),'all_passed':True}
 if args.contracts:
  p=subprocess.run([sys.executable,str(ROOT/'tests/check_input_contract.py')],capture_output=True,text=True)
  if p.returncode:raise RuntimeError(p.stderr)
  controls=json.loads((ROOT/'tests/input_contract_results.json').read_text())
  summary['additional_checks']=controls['total'];summary['all_checks']=summary['implementation_checks']+controls['total'];summary['all_passed'] &= controls['all_passed']
 (ROOT/'reproduction_results.json').write_text(json.dumps(summary,indent=2))
 print(json.dumps(summary,indent=2))
if __name__=='__main__':main()
