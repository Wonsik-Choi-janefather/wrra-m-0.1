Reviewed study: internal_mixing_v0_3
Collection DOI: 10.5281/zenodo.23092499
See the collection README and r1 paper in papers/.
Historical release files remain preserved in GitHub.
