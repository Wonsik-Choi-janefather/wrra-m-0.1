"""Korean SOURCE manuscript assembled from executed results and audit."""
from pathlib import Path
import json
ROOT=Path(__file__).resolve().parent.parent
R=json.loads((ROOT/'code/results.json').read_text())
V=json.loads((ROOT/'verification/independent_audit.json').read_text())
C=json.loads((ROOT/'code/inputs.json').read_text())
TITLE='WRRA M SOURCE 상태와 두 단계 필터의 생성 장부'
SUBTITLE='상류 연구 0.7 · 소수 방출 진폭의 변화와 진입 잔존 복귀의 조건부 연결'
B=[]
def p(t):B.append({'kind':'p','text':t})
def h(t):B.append({'kind':'h','text':t})
def eq(n,t):B.append({'kind':'eq','label':str(n),'tex':t})
def table(cap,headers,rows,widths):B.append({'kind':'table','caption':cap,'headers':headers,'rows':rows,'widths':widths})
def page():B.append({'kind':'break'})
def fig(name,cap):B.append({'kind':'fig','name':name,'caption':cap,'width':6.7})

h('초록')
p('상류 0.7은 소수 주소의 SOURCE 방출 변수를 합성 관계 주소의 진폭으로 전달하고, 그 상태를 두 단계 필터의 진입·잔존·복귀 장부에 연결한다. 이전 두 단계 필터의 공동 보정값 α와 β를 그대로 계승하며, 소수별 로그 세기와 위상을 바꾸는 동안 이 값을 다시 맞추지 않는다. 소인수 지수의 곱으로 관계 진폭을 생성하고, 네 개의 양성 분기를 포함하는 순서 있는 필터 작용을 구현한다.')
p('기준 SOURCE와 N=1,000,000에서 표현 잔존 φ=5%, 비표현 잔존 D=26.8%, 복귀 R=68.2%가 재현된다. 소수 2의 로그 세기를 −0.15에서 +0.15로 바꾸면 전체 잔존 Actual은 28.705298%에서 35.496549%로 변한다. 이 변화는 고정된 필터에 SOURCE 입력만 바꾼 산출이다. 위상만 바꾸는 대각 판독은 출력에 반응하지 않으며, 위상 반응을 보이는 예는 명시적으로 추가한 관계 혼합 작용과 결맞음에 의존한다.')
p(f'유한 SOURCE stock을 반복 방출하면 잔존량이 누적된다. 방출률 u=0.2, 잔존 누출 0에서 32회 뒤 Actual은 {100*R["transport"]["forced_recycling"][-1]["Actual_stock"]:.6f}%이다. 따라서 31.8%는 무제한 재방출의 자동 고정점이 아니다. 본 단계는 생성 창의 닫힘 또는 별도 균형 제어가 필요하다는 조건을 남긴다. 구현 검증 {V["compute_checks"]}개와 독립 감사 {V["independent_checks"]}개가 통과한다.')
h('계승 범위와 남기는 결과')
table('표 1. 이번 단계의 입력 가정과 산출',['구분','내용'],[
['계승 입력','MCC의 소수 SOURCE·합성 관계 주소, 두 단계 1.0-r1의 α·β'],
['새 명시 가정','소수 진폭의 곱, SOURCE 상태 준비, 복귀 stock의 재준비 규칙'],
['계산 산출','진폭 변화의 세 분기 반응, 양성 필터 장부, 반복 방출의 잔존 조건'],
['이어갈 항목','시간 단위와 양자화, 공통 운반자의 물리 대응, 입자 판독과 에너지 사상']],[1.3,5.6])
p('여기서 가중치는 합이 1인 정보 stock이다. 우주론 에너지 비율이나 실제 SOURCE의 동역학으로 동일시하지 않는다. 상류 0.4–0.6의 내부 공간·전류·붕괴 결과는 변경하지 않고 SHA-256으로 동결한다. 0.7은 그 결과에 새 입자 계수를 곱하는 단계가 아니라 생성 입력의 계약을 마련하는 단계이다 [1, 2].')

page();h('SOURCE 변수와 합성 관계 상태')
p('공통 운반자 인터페이스를 유한 주소 공간 H_N=span{|n⟩: 2≤n≤N}로 둔다. n=1의 항등 주소는 이번 정규화에서 제외한다. 소수 p는 독립 방출 주소이고, 합성수 n의 소인수 지수 v_p(n)는 관계 주소의 구성 기록이다. 주소의 독립성은 모든 소수의 물리 에너지나 방출 세기가 같다는 뜻이 아니다.')
eq(1,r'z_p=p^{-\alpha/2}\exp(\epsilon_p/2+i\theta_p),\qquad g_n=\prod_{p\mid n}z_p^{v_p(n)}')
eq(2,r'Z_N=\sum_{n=2}^{N}|g_n|^2,\qquad \psi_n=g_n/\sqrt{Z_N},\qquad w_n=|\psi_n|^2')
eq(3,r'|g_n|^2=n^{-\alpha}\exp\!\left(\sum_{p\mid n}\epsilon_p v_p(n)\right)')
p('ε_p는 로그 세기 변화, θ_p는 위상이다. 지정하지 않은 소수의 ε_p와 θ_p는 0이다. 예를 들어 g_9=z_3², g_15=z_3z_5이므로 소수 3의 방출 변화는 그 소수를 포함하는 관계 주소들에 전달된다. 정규화 때문에 영향을 직접 받지 않는 주소의 상대 가중치도 변한다. 이는 식 (1)을 선택한 조건부 생성 규칙이며, MCC의 주소 정의만으로 진폭 법칙이 유일하게 도출됐다는 주장이 아니다.')
table('표 2. 동결된 기준 설정',['항목','값'],[
['주소 상한 N','1,000,000'],['α',f'{C["alpha"]:.16f}'],['β',f'{C["beta"]:.16f}'],
['기준 SOURCE','모든 ε_p=0 및 θ_p=0'],['진폭 대조 제어','p=2, 3, 5의 ε_p를 −0.15부터 +0.15까지'],
['위상 대조 공간','N=161 및 관계 주소 3↔9']],[2.0,4.9])
p('유한 N에서는 모든 유한 제어값에 대해 직접 합으로 정규화한다. 무한 주소로 확장할 때는 α>1만으로 충분하다고 단정할 수 없다. 유한 개의 제어 소수에 대해서도 ε_p<α log p가 필요하다. 유한 상한의 합은 무한 Euler 곱과 같지 않다. 소인수 곱과 무한 급수의 수렴 구분은 표준 산술 함수의 Euler 곱 관례를 따른다 [3].')

page();h('순서 있는 두 단계 필터와 네 분기의 보존')
p('A는 최초 진입 작용, B는 진입 뒤의 정상 복귀 작용이다. 두 작용은 수축 연산자이고 Q_φ는 0≤Q_φ≤I인 표현 잔존 효과이다. B 뒤에 살아남는 작용 C와 진입 실패 작용 L을 함께 둔다. 최초 반사도 SOURCE 복귀 장부에 넣어 누락과 중복을 피한다.')
eq(4,r'L=(I-A^\dagger A)^{1/2},\qquad C=(I-B^\dagger B)^{1/2}')
eq(5,r'K_L=L,\quad K_R=BA,\quad K_\phi=Q_\phi^{1/2}CA,\quad K_D=(I-Q_\phi)^{1/2}CA')
eq(6,r'\rho_j=K_j\rho K_j^\dagger,\qquad f_j=\mathrm{Tr}(\rho_j),\qquad \sum_jK_j^\dagger K_j=I')
p('완전성은 L†L+A†[B†B+C(Q_φ+I−Q_φ)C]A=I에서 따른다. 따라서 각 분기 상태는 양성이고 입력 trace가 1이면 전체 분기 합도 1이다. Kraus 형식 자체는 표준 양자 작용의 수학을 따른다. 이를 사용했다는 사실만으로 이 SOURCE가 실재 양자계이거나 필터가 물리 장치라는 결론을 내리지 않는다 [4].')
p('기준 A는 소수와 짝수 합성수에서 1, 홀수 합성수에서 √β인 대각 작용이다. B는 소수 투영, Q_φ는 홀수 합성수 투영이다. K=ker B의 합성 잔존에서 φ와 D를 나눈다. φ는 Actual 내부의 표현 잔존이며 Actual=φ+D이다. R=f_L+f_R는 최초 반사와 정상 복귀의 합이다.')
table('표 3. 기준 SOURCE의 공통 분모 장부',['분기','주소별 효과','계산 비율'],[
['φ','β × 홀수 합성수',f'{100*R["baseline"]["phenotype"]:.9f}%'],
['D','짝수 합성수',f'{100*R["baseline"]["dark"]:.9f}%'],
['R','소수 + (1−β) × 홀수 합성수',f'{100*R["baseline"]["return"]:.9f}%'],
['Actual','φ + D',f'{100*R["baseline"]["Actual"]:.9f}%']],[1.0,3.5,2.4])
p('5%와 26.8%는 이전의 공동 보정 목표이며 이번 단계의 새 독립 예측이 아니다. α=2에서의 약 4.8769%와 α≈1.9에서의 약 26.7942%를 섞어 합하지 않는다. 기준 출력과 모든 SOURCE 변화는 동일 N·α·β·정규화에서 계산한다.')

page();h('SOURCE 방출 세기 변화의 계산')
eq(7,r'\frac{\partial w_n}{\partial\epsilon_p}=w_n\left(v_p(n)-\langle v_p\rangle_w\right),\qquad \frac{\partial f_j}{\partial\epsilon_p}=\mathrm{Cov}_w(e_j,v_p)')
p('e_j는 표 3의 주소별 효과이다. 세 분기 미분의 합은 0이며, 다른 소수의 위상은 이 대각 장부에 들어오지 않는다. 중앙 차분 간격 10⁻⁵으로 공분산 식을 검증한다. 세 소수의 최대 차이는 1.1×10⁻¹¹ 이하이다. 표 4는 한 소수의 ε만 바꾸고 나머지 SOURCE·필터 설정을 고정한 산출이다.')
table('표 4. SOURCE 세기 변화의 출력 비율',['소수','ε','φ %','D %','R %'],[
[str(row['prime']),f'{row["epsilon"]:+.2f}',f'{100*row["phenotype"]:.6f}',f'{100*row["dark"]:.6f}',f'{100*row["return"]:.6f}']
for row in R['source_intensity_controls'] if abs(row['epsilon'])==.15],[.7,.65,1.85,1.85,1.85])
fig('source_controls','그림 1. 고정 α·β에서 SOURCE 세기만 바꾼 잔존 비율. 선은 계산 지점을 연결한 것이며 관측 자료나 오차구간이 아니다.')
p('소수 2의 방출 증가는 짝수 관계의 잔존 D를 크게 바꾼다. 소수 3·5의 방출 변화는 φ를 바꾸며 D의 작은 차이도 그대로 저장한다. 이를 정확한 불변량으로 처리하지 않는다. 민감도의 수치 크기는 선택한 주소 규칙과 필터에 대한 응답이다.')

page();h('위상 반응과 관계 혼합의 조건')
eq(8,r'\rho_\gamma=\gamma|\psi\rangle\langle\psi|+(1-\gamma)\operatorname{diag}(w),\qquad 0\leq\gamma\leq1')
p('N=161에서 주소 3과 9를 각도 χ=0.25 rad로 섞는 실수 회전 U를 추가하고 A=D_AU로 둔다. 이 χ는 명시적 시험 제어이며 미시 동역학에서 도출하거나 5%에 다시 맞춘 값이 아니다. 밀도 상태의 γ는 결맞음 제어이다. 대각 A에서는 γ=1이어도 위상만 바꾼 출력이 같고, 혼합 A라도 γ=0이면 위상 반응이 사라진다.')
eq(9,r'\psi^{\prime}_9=\sin\chi\,\psi_3+\cos\chi\,\psi_9')
eq(10,r'f_\phi=\beta\left[W_{\mathrm{odd}}+\sin^2\chi(w_3-w_9)+2\gamma\sin\chi\cos\chi\sqrt{w_3w_9}\cos\theta_3\right]')
p('W_odd는 회전 전 홀수 합성수의 가중치이다. ψ_3의 위상은 θ_3, ψ_9의 위상은 2θ_3이므로 교차항은 cos θ_3이다. 독립 감사는 γ=0·0.37·1 및 다른 위상에서도 식 (10)을 대조한다. 이 작은 공간의 결과를 N=1,000,000의 보정된 우주론 비율로 해석하지 않는다.')
table('표 5. 위상 θ_3에 따른 φ 비율 N=161',['설정','0 rad','π/2 rad','π rad'],[
[label]+[f'{100*x["phenotype"]:.6f}%' for x in R['phase_controls'] if x['case']==key]
for key,label in [('diagonal_coherent','대각 A 결맞음'),('mixed_dephased','혼합 A 비결맞음'),('mixed_coherent','혼합 A 결맞음')]],[2.25,1.55,1.55,1.55])
p('순서 검증은 A 진입 뒤 B 복귀라는 계약을 따른다. A와 B를 교환한 별도 계산의 Actual은 0.138310%이고, 원래 순서는 34.298282%이다. 이 교환은 작용의 위치뿐 아니라 진입·복귀 역할도 바꾸므로 차이만으로 비가환성을 판정하지 않는다. 혼합 각도가 0인 가환 대각 작용에서도 역할을 바꾸면 잔존이 0이 된다. 교환자 norm과 출력 차이는 별도로 기록한다.')

page();h('유한 SOURCE stock의 생성과 복귀 규칙')
p('SOURCE stock S_k, 표현 잔존 P_k, 비표현 잔존 D_k를 두고 S_0=1, P_0=D_0=0에서 시작한다. k는 순서 있는 계산 사건의 번호이며 물리 시간이나 최소 시간 단위가 아니다. 각 사건은 기존 잔존의 누출, SOURCE 방출, 필터 분기, 복귀의 순서로 처리한다. ν는 잔존이 SOURCE로 되돌아가는 stock 누출률이다.')
eq(11,r'\widetilde S_k=S_k+\nu(P_k+D_k),\quad \widetilde P_k=(1-\nu)P_k,\quad \widetilde D_k=(1-\nu)D_k')
eq(12,r'J_k=u_k\widetilde S_k,\qquad S_{k+1}=\widetilde S_k-J_k+J_kf_R')
eq(13,r'P_{k+1}=\widetilde P_k+J_kf_\phi,\quad D_{k+1}=\widetilde D_k+J_kf_D,\quad S_{k+1}+P_{k+1}+D_{k+1}=1')
p('복귀 stock은 다음 방출 때 같은 선언된 SOURCE 상태로 다시 준비한다고 가정한다. 따라서 복귀의 위상 기억, 관계별 선택적 회수, 누적 SOURCE 변화는 이번 scalar stock 장부에 포함하지 않는다. SOURCE 진폭·위상 제어를 고정한 동안 세 분기 f도 고정된다. 실제 물리 SOURCE의 동역학을 대체한 것처럼 해석하지 않는다.')
p('기준 생성 창은 첫 사건에서 u_0=1, 뒤에는 u_k=0이며 ν=0이다. 한 번 방출한 뒤 창을 닫으므로 S=68.2%, P=5%, D=26.8%가 유지된다. stock의 합 1은 입력·잔존·복귀의 회계 보존이며, 에너지의 차원과 운반자별 에너지 대응이 정해지기 전까지 물리 에너지 보존의 증명으로 사용하지 않는다.')
h('반복 방출의 닫힌 식')
eq(14,r'a_{k+1}=ur+(1-\nu)(1-ur)a_k,\qquad r=f_\phi+f_D,\quad a_k=P_k+D_k')
eq(15,r'\nu=0:\quad a_k=1-(1-ur)^k;\qquad \nu>0:\quad a_*=\frac{ur}{\nu+(1-\nu)ur}')
p('식 (14)는 일정 u와 같은 SOURCE 재준비 규칙에서 따른다. 초기 a_0=0이면 ν>0의 유한 사건 산출은 a_k=a_*[1−((1−ν)(1−ur))^k]이다. 누출이 없는 한 0<ur<1에서 무제한 재방출의 Actual은 1로 간다. 따라서 기존의 31.8%를 일반적인 재방출 고정점으로 주장할 수 없다.')

page();h('생성 창 닫힘과 별도 균형 제어의 비교')
table('표 6. 고정 SOURCE에서의 생성 프로토콜',['프로토콜','32회 뒤 Actual','극한 또는 유지값'],[
['한 번 전량 방출 뒤 닫힘','31.800000%','31.800000% 유지'],
['u=0.2 매회 재방출 ν=0',f'{100*R["transport"]["forced_recycling"][-1]["Actual_stock"]:.6f}%','100% 극한'],
['u=0.2 매회 재방출 ν=0.1',f'{100*R["transport"]["recycling_with_leakage"][-1]["Actual_stock"]:.6f}%',f'{100*R["recycling_analysis"]["stationary_Actual"]:.6f}% 극한']],[3.05,1.75,2.1])
fig('stock_protocols','그림 2. 생성 프로토콜에 따른 잔존 stock. 사건 수는 물리 시간이 아니다. 최초 상태는 동일하며 모든 사건에서 전체 stock의 합은 1이다.')
eq(16,r'\nu_{\mathrm{target}}=\frac{ur(1-a_{\mathrm{target}})}{a_{\mathrm{target}}(1-ur)}')
p(f'u=0.2, r=0.318에서 목표 a_target=0.318을 고정점으로 반환하는 별도 ν는 {R["recycling_analysis"]["epsilon_needed_for_target"]:.12f}이다. 이는 목표값을 식 (15)에 넣어 역으로 구한 제어값이며, 누출률의 독립 예측이나 우주론 측정값이 아니다. 0≤ν≤1인 균형 제어의 가능 조건은 a_target≥ur이다. 다른 목표를 허용할 때도 이 조건을 별도로 기록한다.')
p('N=10,000·100,000·1,000,000에서는 α·β를 다시 맞추지 않고 절단 민감도를 계산한다. N=10,000의 φ·D·R은 4.989044%·26.791475%·68.219480%, N=100,000은 4.998716%·26.799046%·68.202237%이다. 이는 수치 상한에 따른 변화이며 관측 오차나 모형 불확실성 전체를 뜻하지 않는다.')

page();h('다음 단계로 전달하는 공통 계약')
table('표 7. 상류 0.8 이후에 전달할 명세',['필드','0.7의 확정 상태'],[
['주소와 SOURCE','n=2…N 소인수 지수, z_p와 관계 진폭 g_n, 정규화 상태'],
['필터와 읽기','A 진입 B 복귀 순서, 최초 반사와 정상 복귀 분리, φ⊂Actual'],
['stock 프로토콜','창 닫힘 또는 u_k·ν·복귀 재준비 규칙을 명시'],
['검증 기준','양성 trace 보존, 공분산 민감도, 독립 stock 반복식'],
['물리 시간 단위','미정 null 사건 번호를 시간으로 동일시하지 않음'],
['에너지 사상','미정 null 정보 stock을 곧바로 에너지 분율로 쓰지 않음'],
['입자 판독 연결','0.6 결과를 동결하며 SOURCE에서 입자 상태로 가는 사상은 후속 과제']],[1.5,5.4])
p('code/handoff.json은 이 계약과 기준 출력을 기계가 읽을 수 있게 저장한다. 부모 0.6의 결과 파일 hash는 동일성 확인용이며 새로운 물리 결합을 뜻하지 않는다. 공통 운반자는 현재 유한 주소 공간의 형식적 인터페이스이고, 그 물리적 표현·에너지 운반·관측 시간 대응은 아직 정하지 않았다.')
h('상류의 마무리 경로')
table('표 8. 현재의 종료 계획',['단계','마무리 조건'],[
['0.7 SOURCE','상태·변화량을 두 필터와 보존 장부로 연결 본 자료'],
['0.8 시간과 양자화','셔터 갱신의 순서·프레임·최소 판독 단위와 norm 계약'],
['0.9 입자와 전류','생성 잔존을 내부 상태와 입자 판독에 연결하고 남은 오차 명시'],
['0.10 생성기 통합','단계별 장부와 하류 입력 계약을 하나의 실행 경로로 묶기'],
['1.0 동결 공개','조건부 생성 모형 원고 코드 증거 전달 명세의 일관성 확인']],[1.5,5.4])
p('1.0의 종료 기준은 SOURCE에서 필터·잔존·복귀·시간 판독·입자 판독으로 이어지는 조건부 계산 경로와 입력·가정·보정·산출의 구분이다. 각 단계의 빈 물리 대응을 결과로 꾸미지 않고 명시적으로 남긴다. 0.7의 실제 새 결과는 SOURCE 변수를 바꾸는 재현 가능한 응답과, 기준 비율을 유지하는 생성 프로토콜의 조건이다.')

page();h('독립 검증과 재현')
p(f'code/compute.py의 {V["compute_checks"]}개 검증과 verify_release.py의 {V["independent_checks"]}개 독립 검증, 합계 {V["total_checks"]}개가 통과한다. 검증은 유한 모형 안의 계산·보존·구현 일관성을 확인한다. 물리 SOURCE의 실험 검증이나 우주론 비율의 독립 도출을 뜻하지 않는다. NumPy 2.3.5와 BLAS thread 수 2로 실행하였다.')
table('표 9. 검증에서 별도로 대조한 근거',['대상','독립 대조 방법'],[
['SOURCE 상태','시험 나눗셈 소인수분해와 복소 진폭의 직접 곱'],
['잔존과 미분','math.fsum의 공통 분모 합 및 다른 간격의 중앙 차분'],
['위상 반응','주소 3↔9 회전의 닫힌 식 γ=0·0.37·1'],
['필터 작용','작은 일반 비가환 예의 Choi 양성·부분 trace·분기 확률'],
['stock','독립 scalar 반복식 고정점 1,000회 수렴 끝점 제어'],
['재현과 입력','새 복사본의 JSON 바이트 일치 축소·재배열 입력 NaN·위법 입력 거부']],[1.45,5.45])
p('재현은 requirements.txt의 의존성을 설치한 뒤 reproduce_all.py를 실행한다. 계산 결과 results.json, 다음 단계 계약 handoff.json, 독립 감사 independent_audit.json과 SHA256SUMS를 함께 남긴다. 문서 작성 환경은 별도로 기록하며 재현 계산 자체는 Word·PDF 렌더러를 요구하지 않는다. 원고 표와 그림은 저장된 JSON에서 생성한다.')
h('참고자료')
p('[1] Choi, Wonsik. WRRA M 상류 0.3까지의 계승 자료집 및 상위 두 단계 필터 1.0. DOI 10.5281/zenodo.23092499. https://zenodo.org/records/23092499. 이번 단계는 수정된 1.0-r1의 공동 보정 JSON을 동결 입력으로 사용한다.')
p('[2] Choi, Wonsik. WRRA M 상류 0.4–0.6 교정 자료집 0.4-0.6-r1. DOI 10.5281/zenodo.23112253. https://zenodo.org/records/23112253. 0.6-r1의 결과·입력·provenance를 변경 없이 계승한다.')
p('[3] NIST Digital Library of Mathematical Functions. §27.4 Euler Products and Dirichlet Series, 식 27.4.1 및 27.4.3. https://dlmf.nist.gov/27.4. 열람 2026-10-03. 소인수 곱과 무한 급수의 수렴에 대한 표준 수학 자료이다.')
p('[4] Preskill, John. Lecture Notes for Ph219/CS219 Quantum Information, Chapter 3 Foundations II Measurement and Evolution, 갱신 October 2018, §3.1–3.3. https://www.preskill.caltech.edu/ph219/chap3_15.pdf. 열람 2026-10-03. Kraus 완전성과 완전 양성의 표준 형식에 사용한다.')
p('공개 저장소 https://github.com/Wonsik-Choi-janefather/wrra-m-0.1/tree/main/upstream/source_filter_v0_7. 본 0.7의 DOI는 아직 발급하지 않았다. 기존 DOI는 계승 자료에 대한 인용이다.')
